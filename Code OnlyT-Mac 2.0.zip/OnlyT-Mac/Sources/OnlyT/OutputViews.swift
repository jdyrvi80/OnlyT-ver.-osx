import AppKit
import SwiftUI
import OnlyTCore

/// Background of the clock / timer panels.
private struct PanelBackground: View {
    let gradient: Bool
    let frame: Bool

    var body: some View {
        let shape = RoundedRectangle(cornerRadius: 20, style: .continuous)
        ZStack {
            if gradient {
                shape.fill(LinearGradient(colors: [Palette.gradientTop, .black], startPoint: .top, endPoint: .bottom))
            } else {
                shape.fill(Color.black)
            }
            if frame {
                shape.strokeBorder(Palette.beige, lineWidth: 3)
            }
        }
    }
}

/// The timer output window (port of TimerOutputWindow.xaml): a clock panel that
/// fills the screen between talks, and a split layout (clock + timer) while timing.
@MainActor
struct TimerOutputView: View {
    @ObservedObject var model: TimerDisplayModel

    var body: some View {
        GeometryReader { geo in
            let o = model.options
            let w = geo.size.width
            let h = geo.size.height
            let clockColWidth = w * CGFloat(o.analogueClockWidthPercent) / 100
            let split = model.layout == .split
            let clockWidth = max(0, (split ? clockColWidth : w) - 5)
            let timerWidth = max(0, w - clockColWidth - 5)

            ZStack(alignment: .topLeading) {
                Color.black

                clockPanel(options: o, split: split)
                    .frame(width: clockWidth, height: h)
                    .opacity(model.clockOpacity)

                if timerWidth > 1 {
                    timerPanel(options: o)
                        .frame(width: timerWidth, height: h)
                        .offset(x: clockColWidth + 5)
                        .opacity(model.timerOpacity)
                }
            }
        }
        .background(Color.black)
        .ignoresSafeArea()
    }

    private func clockPanel(options o: Options, split: Bool) -> some View {
        let windowed = model.windowed
        // row heights: analogue / digital
        var analogueWeight: CGFloat = 75
        var digitalWeight: CGFloat = 25
        if !split {
            switch o.fullScreenClockMode {
            case .analogue:
                analogueWeight = 100
                digitalWeight = 0
            case .digital:
                analogueWeight = 0
                digitalWeight = 100
            case .analogueAndDigital:
                break
            }
        }
        return ZStack {
            PanelBackground(gradient: !windowed && o.showBackgroundOnClock, frame: !windowed && o.timerFrame)
            GeometryReader { g in
                let total = analogueWeight + digitalWeight
                let aH = g.size.height * analogueWeight / max(total, 1)
                let dH = g.size.height * digitalWeight / max(total, 1)
                VStack(spacing: 0) {
                    if aH > 1 {
                        AnalogueClockView(now: model.now,
                                          isFlat: windowed || o.clockIsFlat,
                                          sector: model.sector,
                                          sectorRevealDate: model.sectorRevealDate,
                                          appearDate: model.clockAppearDate)
                            .padding(15)
                            .frame(height: aH)
                    }
                    if dH > 1 {
                        DigitalTimeView(now: model.now, format: o.clockHourFormat, showSeconds: o.showDigitalSeconds)
                            .padding(.horizontal, 5)
                            .frame(height: dH)
                    }
                }
            }
            .padding(10)
        }
    }

    private func timerPanel(options o: Options) -> some View {
        let windowed = model.windowed
        return ZStack {
            PanelBackground(gradient: !windowed && o.showBackgroundOnTimer, frame: !windowed && o.clockTimerFrame)
            VStack(spacing: 0) {
                GeometryReader { g in
                    if o.showTimeOfDayUnderTimer {
                        VStack(spacing: 0) {
                            FittedText(text: model.timeString, baseSize: 40, color: Palette.timer(model.textColour))
                                .frame(height: g.size.height * 0.6)
                            TimeOfDayText(now: model.now, format: o.clockHourFormat)
                                .frame(height: g.size.height * 0.4)
                        }
                    } else {
                        // pinned to the top of the panel, as in the original
                        FittedText(text: model.timeString, baseSize: 40, color: Palette.timer(model.textColour), alignment: .top)
                    }
                }
                if let start = model.persistBarStart {
                    PersistBar(start: start, duration: model.persistBarDuration)
                        .frame(height: 36)
                        .padding(.top, 10)
                        .padding(.bottom, 50)
                }
            }
            .padding(EdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 20))
        }
    }
}

private struct TimeOfDayText: View {
    let now: () -> Date
    let format: ClockHourFormat

    var body: some View {
        TimelineView(.periodic(from: Date(), by: 0.5)) { _ in
            FittedText(text: format.formatHoursMinutes(now()), baseSize: 28, color: .white)
        }
    }
}

/// The bar that empties while the final timer value is persisted on screen.
private struct PersistBar: View {
    let start: Date
    let duration: TimeInterval

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 20)) { timeline in
            let fraction = max(0, min(1, 1 - timeline.date.timeIntervalSince(start) / max(duration, 0.1)))
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color(hex: 0x444444))
                    Capsule().fill(Color.white).frame(width: max(0, g.size.width * fraction))
                }
                .clipShape(Capsule())
            }
        }
    }
}

/// The countdown window content (port of CountdownWindow.xaml).
@MainActor
struct CountdownOutputView: View {
    @ObservedObject var model: CountdownModel

    var body: some View {
        GeometryReader { geo in
            let o = model.options
            let windowed = model.windowed
            let zoom = windowed ? 1.0 : CGFloat(o.countdownZoomPercent) / 100
            let panelW = geo.size.width * zoom
            let panelH = geo.size.height * zoom
            let showFrame = !windowed && o.countdownFrame
            let transparent = !windowed && o.isCountdownWindowTransparent

            ZStack(alignment: alignment(o.countdownScreenLocation)) {
                (transparent ? Color.clear : Color.black)
                ZStack {
                    let shape = RoundedRectangle(cornerRadius: 20 * zoom, style: .continuous)
                    if showFrame {
                        shape.fill(LinearGradient(colors: [Palette.gradientTop, .black], startPoint: .top, endPoint: .bottom))
                        shape.strokeBorder(Palette.beige, lineWidth: 3)
                    }
                    CountdownDialView(model: model)
                        .padding(20 * zoom)
                }
                .frame(width: panelW, height: panelH)
                .opacity(model.opacity)
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
        .ignoresSafeArea()
    }

    private func alignment(_ location: ScreenLocation) -> Alignment {
        switch (location.horizontal, location.vertical) {
        case (-1, -1): return .topLeading
        case (0, -1): return .top
        case (1, -1): return .topTrailing
        case (-1, 0): return .leading
        case (1, 0): return .trailing
        case (-1, 1): return .bottomLeading
        case (0, 1): return .bottom
        case (1, 1): return .bottomTrailing
        default: return .center
        }
    }
}
