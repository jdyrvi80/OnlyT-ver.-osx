import AppKit
import OnlyTCore

private let pdfPageSize = CGSize(width: 595, height: 842) // A4

/// Generates the PDF timing report (port of OnlyT.Report PdfTimingReport).
@MainActor
enum PdfTimingReport {
    private static let largestDeviationMins: Double = 10
    private static let minChartSeries = 5

    private struct Fonts {
        let title = Fonts.font(22, bold: true)
        let subTitle = Fonts.font(16, bold: true)
        let itemTitle = Fonts.font(11, bold: true)
        let item = Fonts.font(10, bold: false)
        let stdTime = Fonts.font(10, bold: false)
        let duration = Fonts.font(10, bold: true)
        let smallTime = Fonts.font(8.5, bold: false)

        static func font(_ size: CGFloat, bold: Bool) -> NSFont {
            let name = bold ? "Verdana-Bold" : "Verdana"
            return NSFont(name: name, size: size) ?? (bold ? NSFont.boldSystemFont(ofSize: size) : NSFont.systemFont(ofSize: size))
        }

        static func height(_ f: NSFont) -> CGFloat {
            ceil(f.ascender - f.descender + f.leading)
        }
    }

    private final class Page {
        let ctx: CGContext
        let fonts = Fonts()
        var y: CGFloat = 0
        var leftMargin: CGFloat = 0
        var leftIndent: CGFloat = 0
        var rightX: CGFloat = 0
        var rightXIndent: CGFloat = 0

        init(ctx: CGContext) {
            self.ctx = ctx
            let titleH = Fonts.height(fonts.title)
            let indentDelta = titleH / 3
            leftMargin = 2 * titleH
            leftIndent = leftMargin + indentDelta
            y = 2 * titleH
            rightX = pdfPageSize.width - leftMargin
            rightXIndent = rightX - indentDelta
        }

        func h(_ f: NSFont) -> CGFloat { Fonts.height(f) }

        func width(_ s: String, _ f: NSFont) -> CGFloat {
            (s as NSString).size(withAttributes: [.font: f]).width
        }

        /// Draws text with its baseline at `baseline` (like PdfSharp's DrawString).
        func text(_ s: String, _ f: NSFont, _ color: NSColor, x: CGFloat, baseline: CGFloat) {
            (s as NSString).draw(at: NSPoint(x: x, y: baseline - f.ascender), withAttributes: [.font: f, .foregroundColor: color])
        }

        func line(_ x1: CGFloat, _ y1: CGFloat, _ x2: CGFloat, _ y2: CGFloat, _ color: NSColor, _ width: CGFloat = 0.75) {
            ctx.setStrokeColor(color.cgColor)
            ctx.setLineWidth(width)
            ctx.move(to: CGPoint(x: x1, y: y1))
            ctx.addLine(to: CGPoint(x: x2, y: y2))
            ctx.strokePath()
        }

        func rect(_ r: CGRect, _ color: NSColor) {
            ctx.setFillColor(color.cgColor)
            ctx.fill(r)
        }
    }

    /// Returns the path of the generated PDF, or nil.
    static func generate(data: MeetingTimes, historical: [MeetingTimeSummary], weekendIncludesFriday: Bool,
                         reportsFolder: URL, now: Date) -> URL? {
        let cal = Calendar.current
        let year = cal.component(.year, from: now)
        let month = cal.component(.month, from: now)
        let day = cal.component(.day, from: now)
        let folder = reportsFolder
            .appendingPathComponent("\(year)", isDirectory: true)
            .appendingPathComponent(String(format: "%d-%02d", year, month), isDirectory: true)
        AppFolders.ensure(folder)

        let base = String(format: "%d-%02d-%02d", year, month, day)
        var url = folder.appendingPathComponent("\(base).pdf")
        var counter = 1
        while FileManager.default.fileExists(atPath: url.path) {
            url = folder.appendingPathComponent("\(base) (\(counter)).pdf")
            counter += 1
        }

        var mediaBox = CGRect(origin: .zero, size: pdfPageSize)
        guard let ctx = CGContext(url as CFURL, mediaBox: &mediaBox, nil) else {
            return nil
        }

        drawMainPage(ctx: ctx, data: data)
        drawHistoricalPage(ctx: ctx, data: data, historical: historical, weekendIncludesFriday: weekendIncludesFriday)
        ctx.closePDF()
        return url
    }

    private static func beginPage(_ ctx: CGContext) -> Page {
        ctx.beginPDFPage(nil)
        ctx.saveGState()
        ctx.translateBy(x: 0, y: pdfPageSize.height)
        ctx.scaleBy(x: 1, y: -1)
        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = NSGraphicsContext(cgContext: ctx, flipped: true)
        return Page(ctx: ctx)
    }

    private static func endPage(_ ctx: CGContext) {
        NSGraphicsContext.restoreGraphicsState()
        ctx.restoreGState()
        ctx.endPDFPage()
    }

    private static func longDate(_ date: Date?) -> String {
        guard let date = date else {
            return ""
        }
        let f = DateFormatter()
        f.locale = Locale(identifier: L10n.shared.languageCode)
        f.dateStyle = .full
        f.timeStyle = .none
        return f.string(from: date)
    }

    private static func drawTitle(_ p: Page, _ title: String, _ date: Date?) {
        let titleH = p.h(p.fonts.title)
        p.text(title, p.fonts.title, .black, x: p.leftMargin, baseline: p.y)
        p.y += 5 * titleH / 6
        p.text(longDate(date), p.fonts.subTitle, .black, x: p.leftMargin, baseline: p.y)
        p.y += titleH
    }

    private static func drawMainPage(ctx: CGContext, data: MeetingTimes) {
        let p = beginPage(ctx)
        defer { endPage(ctx) }

        drawTitle(p, L10n.t("REPORT_TITLE"), data.meetingDate)

        let items = data.items.filter { item in
            guard let end = item.end, let start = data.meetingStart, let actualEnd = data.meetingActualEnd else {
                return false
            }
            return end - item.start > 20 && item.start >= start && end <= actualEnd
        }

        for (n, item) in items.enumerated() {
            drawItem(p, item)
            if item.isStudentTalk && n != items.count - 1 {
                let next = items[n + 1]
                let counsel = max(0, next.start - (item.end ?? next.start))
                drawCounsel(p, TimeInterval(counsel))
            }
        }

        if let planned = data.meetingPlannedEnd, let actual = data.meetingActualEnd {
            drawSummary(p, plannedEnd: planned, actualEnd: actual)
        }
    }

    private static func drawItem(_ p: Page, _ item: MeetingTimedItem) {
        let f = p.fonts
        let titleH = p.h(f.itemTitle)
        if item.isSongSegment {
            p.rect(CGRect(x: p.leftMargin, y: p.y - titleH, width: p.rightX - p.leftMargin, height: titleH * 2.5),
                   NSColor(white: 0.83, alpha: 1))
        }
        var x = p.leftIndent
        p.text(item.description, f.itemTitle, .black, x: x, baseline: p.y)
        p.y += titleH

        let duration = (item.end ?? item.start) - item.start
        let durStr = String(format: "%02d:%02d", duration / 60, duration % 60)
        p.text(durStr, f.duration, .black, x: x, baseline: p.y)
        x += p.width(durStr, f.duration)

        x = drawTimes(p, item, x)
        let allowed = item.adaptedDuration == 0 ? item.plannedDuration : item.adaptedDuration
        drawOvertime(p, x, duration: TimeInterval(duration), allowed: TimeInterval(allowed))
        p.y += 3 * titleH / 2
    }

    private static func hms(_ secs: Int) -> (Int, Int, Int) {
        (secs / 3600, (secs % 3600) / 60, secs % 60)
    }

    private static func drawTimes(_ p: Page, _ item: MeetingTimedItem, _ startX: CGFloat) -> CGFloat {
        let f = p.fonts
        var x = startX
        let s = hms(item.start)
        let e = hms(item.end ?? item.start)
        let parts: [(String, NSFont)] = [
            (String(format: "  (%02d:%02d", s.0, s.1), f.stdTime),
            (String(format: ":%02d", s.2), f.smallTime),
            (" - ", f.stdTime),
            (String(format: "%02d:%02d", e.0, e.1), f.stdTime),
            (String(format: ":%02d", e.2), f.smallTime),
            (")", f.stdTime),
        ]
        for (str, font) in parts {
            p.text(str, font, .black, x: x, baseline: p.y)
            x += p.width(str, font)
        }
        if item.adaptedDuration != item.plannedDuration {
            let a = hms(item.adaptedDuration)
            let adapted = " " + L10n.f("ADAPTED_DURATION", String(format: "%02d:%02d:%02d", a.0, a.1, a.2))
            x += p.width(" ", f.stdTime)
            p.text(adapted, f.smallTime, NSColor(white: 0.7, alpha: 1), x: x, baseline: p.y)
            x += p.width(adapted, f.smallTime)
        }
        return x
    }

    private static func drawOvertime(_ p: Page, _ curX: CGFloat, duration: TimeInterval, allowed: TimeInterval) {
        let f = p.fonts
        let overtime = Int(allowed - duration)
        let inTheGreen = overtime >= 0
        let spotOn = overtime == 0
        let prefix = spotOn ? "" : (inTheGreen ? "-" : "+")
        let a = abs(overtime)
        let s = "\(prefix) " + String(format: "%02d:%02d", (a / 60) % 60, a % 60)
        let w = p.width(s, f.duration)
        let startX = p.rightXIndent - w
        let stdH = p.h(f.stdTime)
        let dotsLength = startX - stdH - (curX + stdH)
        var dots = "."
        while p.width(dots, f.smallTime) < dotsLength {
            dots += "."
        }
        if dotsLength > 0 {
            let dotsX = startX - stdH - p.width(dots, f.smallTime)
            p.text(dots, f.smallTime, NSColor(white: 0.83, alpha: 1), x: dotsX, baseline: p.y)
        }
        p.text(s, f.duration, inTheGreen ? NSColor(srgbRed: 0, green: 0.5, blue: 0, alpha: 1) : .red, x: startX, baseline: p.y)
    }

    private static func normaliseCounsel(_ counsel: TimeInterval) -> TimeInterval {
        var result = counsel - 20
        if result <= 5 {
            result = counsel
        }
        var guardCount = 0
        while Int(result) % 5 != 0 && guardCount < 20 {
            result += 0.5
            guardCount += 1
        }
        return result
    }

    private static func drawCounsel(_ p: Page, _ counsel: TimeInterval) {
        let f = p.fonts
        p.y -= 2 * p.h(f.item) / 5
        let title = L10n.t("COUNSEL")
        let x = p.leftIndent + 2 * p.h(f.itemTitle)
        p.text(title, f.item, .gray, x: x, baseline: p.y)
        drawOvertime(p, x + p.width(title, f.item), duration: normaliseCounsel(counsel), allowed: 60)
        p.y += 3 * p.h(f.itemTitle) / 2
    }

    private static func drawSummary(_ p: Page, plannedEnd: Int, actualEnd: Int) {
        let f = p.fonts
        p.y += 2 * p.h(f.itemTitle)
        p.line(p.leftMargin, p.y, p.rightX, p.y, .gray)
        p.y += p.h(f.subTitle)
        p.text(L10n.t("OVERALL_STATUS"), f.subTitle, .black, x: p.leftMargin, baseline: p.y)
        p.y += p.h(f.subTitle)

        let minsOvertime = Double(actualEnd - plannedEnd) / 60
        let green = NSColor(srgbRed: 0, green: 0.5, blue: 0, alpha: 1)
        if minsOvertime > 1 {
            let mins = Int(minsOvertime.rounded())
            let msg = mins == 1 ? L10n.t("OVERTIME_BY_1") : L10n.f("OVERTIME_BY", mins)
            p.text(msg, f.itemTitle, .red, x: p.leftMargin, baseline: p.y)
        } else if minsOvertime < -1 {
            let mins = abs(Int(minsOvertime.rounded()))
            let msg = mins == 1 ? L10n.t("UNDERTIME_BY_1") : L10n.f("UNDERTIME_BY", mins)
            p.text(msg, f.itemTitle, green, x: p.leftMargin, baseline: p.y)
        } else {
            p.text(L10n.t("ON_TIME"), f.itemTitle, green, x: p.leftMargin, baseline: p.y)
        }
        p.y += p.h(f.item) / 2
        p.line(p.leftMargin, p.y, p.rightX, p.y, .gray)
    }

    // MARK: historical charts

    private enum ChartType {
        case midweek, weekend, both
    }

    private static func usable(_ s: MeetingTimeSummary, _ type: ChartType, _ includesFriday: Bool) -> Bool {
        let weekend = DateUtils.isWeekend(s.meetingDate, includesFriday: includesFriday)
        let matches = type == .both || (type == .weekend && weekend) || (type == .midweek && !weekend)
        return matches && abs(s.overtime / 60) < 30
    }

    private static func drawHistoricalPage(ctx: CGContext, data: MeetingTimes, historical: [MeetingTimeSummary], weekendIncludesFriday: Bool) {
        guard historical.filter({ usable($0, .both, weekendIncludesFriday) }).count > minChartSeries else {
            return
        }
        let p = beginPage(ctx)
        defer { endPage(ctx) }
        drawTitle(p, L10n.t("TIMING_SUMMARY"), data.meetingDate)
        for type in [ChartType.midweek, .weekend, .both] {
            let series = historical.filter { usable($0, type, weekendIncludesFriday) }
            if series.count > minChartSeries {
                drawChart(p, series, type)
            }
        }
    }

    private static func drawChart(_ p: Page, _ series: [MeetingTimeSummary], _ type: ChartType) {
        let f = p.fonts
        let chartHeight = p.h(f.item) * 15
        let frame = CGRect(x: p.leftMargin, y: p.y, width: p.rightX - p.leftMargin, height: chartHeight)
        let plot = CGRect(x: frame.minX + 40, y: frame.minY + 6, width: frame.width - 46, height: frame.height - 40)
        let maxV = largestDeviationMins

        func yFor(_ v: Double) -> CGFloat {
            plot.midY - CGFloat(v / maxV) * plot.height / 2
        }

        // gridlines and y labels
        for v in stride(from: -maxV, through: maxV, by: 5) {
            let y = yFor(v)
            p.line(plot.minX, y, plot.maxX, y, NSColor(white: 0.8, alpha: 1), 0.5)
            let label = String(format: "%.0f", v)
            p.text(label, f.smallTime, .black, x: plot.minX - 6 - p.width(label, f.smallTime), baseline: y + 3)
        }
        p.line(plot.minX, plot.minY, plot.minX, plot.maxY, .black, 0.75)
        p.ctx.stroke(plot)

        // y axis title (rotated)
        let yTitle = L10n.t("OVERTIME_MINS")
        p.ctx.saveGState()
        p.ctx.translateBy(x: frame.minX + 8, y: plot.midY + p.width(yTitle, f.smallTime) / 2)
        p.ctx.rotate(by: -.pi / 2)
        p.text(yTitle, f.smallTime, .black, x: 0, baseline: 0)
        p.ctx.restoreGState()

        // bars
        let slot = plot.width / CGFloat(max(series.count, 1))
        let barWidth = max(2, slot * 0.6)
        let cal = Calendar.current
        let monthFormatter = DateFormatter()
        monthFormatter.locale = Locale(identifier: L10n.shared.languageCode)
        monthFormatter.dateFormat = "MMM"
        var lastMonth: (Int, Int)?
        for (i, s) in series.enumerated() {
            let v = max(-maxV, min(maxV, s.overtime / 60))
            let x = plot.minX + slot * CGFloat(i) + (slot - barWidth) / 2
            let y0 = yFor(0)
            let y1 = yFor(v)
            p.rect(CGRect(x: x, y: min(y0, y1), width: barWidth, height: abs(y1 - y0)), v > 0 ? .red : NSColor(srgbRed: 0, green: 0.6, blue: 0, alpha: 1))
            let ym = (cal.component(.year, from: s.meetingDate), cal.component(.month, from: s.meetingDate))
            if lastMonth == nil || lastMonth! != ym {
                lastMonth = ym
                p.text(monthFormatter.string(from: s.meetingDate), f.smallTime, .black, x: x, baseline: plot.maxY + 12)
            }
        }

        // x axis title
        let xTitle: String
        switch type {
        case .midweek: xTitle = L10n.t("MIDWEEK_MTGS")
        case .weekend: xTitle = L10n.t("WEEKEND_MTGS")
        case .both: xTitle = L10n.t("MIDWEEK_AND_WEEKEND_MTGS")
        }
        p.text(xTitle, f.item, .black, x: plot.midX - p.width(xTitle, f.item) / 2, baseline: plot.maxY + 28)

        p.y += chartHeight + p.h(f.item) * 2
    }
}
