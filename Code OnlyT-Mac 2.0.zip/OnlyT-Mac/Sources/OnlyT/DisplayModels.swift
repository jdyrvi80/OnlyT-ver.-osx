import AppKit
import SwiftUI
import OnlyTCore

/// The coloured "duration sector" drawn on the analogue clock while a talk is timed.
struct DurationSector: Equatable {
    var startAngle: Double
    var endAngle: Double
    var currentAngle: Double
    var isOvertime: Bool
    var showElapsedSector: Bool
}

/// State of the timer output window (port of TimerOutputWindowViewModel + the
/// animations of TimerOutputWindow).
@MainActor
final class TimerDisplayModel: ObservableObject {
    enum Layout {
        case fullScreenClock
        case split
    }

    static let secsPerHour = 3600

    @Published var options: Options
    @Published var timeString = "00:00"
    @Published var textColour: TimerColour = .green
    @Published private(set) var isRunning = false
    @Published private(set) var layout: Layout = .fullScreenClock
    @Published private(set) var clockOpacity: Double = 1
    @Published private(set) var timerOpacity: Double = 0
    @Published private(set) var sector: DurationSector?
    /// The sector is first drawn one second after it is created (as in the original).
    @Published private(set) var sectorRevealDate = Date.distantPast
    @Published private(set) var persistBarStart: Date?
    @Published private(set) var persistBarDuration: TimeInterval = 90
    @Published var windowed = false
    /// When the clock appeared (its hands sweep from 12 o'clock for ~1 second).
    @Published var clockAppearDate = Date()

    let now: () -> Date
    private(set) var persisting = false
    private var persistToken = 0
    private var transitionToken = 0

    init(options: Options, now: @escaping () -> Date) {
        self.options = options
        self.now = now
    }

    var splitAndFullScreenIdentical: Bool {
        options.analogueClockWidthPercent == 100
    }

    // MARK: timer events

    func timerStarted(targetSeconds: Int, countUp: Bool) {
        textColour = .green
        timeString = TimeFormatter.formatTimer(countUp ? 0 : targetSeconds)
        isRunning = true
        sector = nil
        initSector(elapsed: 0, remaining: targetSeconds)

        if persisting {
            persisting = false
            persistToken += 1
            persistBarStart = nil
            withAnimation(.easeInOut(duration: 0.3)) {
                timerOpacity = 1
            }
        } else if !splitAndFullScreenIdentical {
            displaySplitScreen()
        }
    }

    func timerChanged(remaining: Int, elapsed: Int, isRunning running: Bool, closingSecs: Int, countUp: Bool) {
        guard running else {
            return
        }
        textColour = TimerColour.forTimeRemaining(remaining, closingSecs: closingSecs)
        timeString = TimeFormatter.formatTimer(countUp ? elapsed : remaining)

        // talks longer than 1 hr only show the sector when less than an hour remains
        initSector(elapsed: elapsed, remaining: remaining)

        if var s = sector {
            let current = DateUtils.minuteHandAngle(now())
            if abs(current - s.currentAngle) > 0.15 {
                s.currentAngle = current
                s.isOvertime = remaining < 0
                s.showElapsedSector = (elapsed + remaining) <= TimerDisplayModel.secsPerHour
                sector = s
            }
        }
    }

    func timerStopped(persistFinalValue: Bool, isPaused: Bool) {
        sector = nil
        if !isPaused {
            isRunning = false
        }

        if persistFinalValue {
            persisting = true
            persistToken += 1
            let token = persistToken
            let duration = TimeInterval(options.persistDurationSecs)
            persistBarDuration = duration
            persistBarStart = options.showPersistCountdown ? Date() : nil
            after(duration) { [weak self] in
                guard let self = self, self.persisting, self.persistToken == token else {
                    return
                }
                self.persisting = false
                self.persistBarStart = nil
                self.adjustDisplayOnTimerStop()
            }
        } else {
            persistBarStart = nil
            adjustDisplayOnTimerStop()
        }
    }

    /// Settings shown: split the display so the split position can be adjusted.
    func settingsOpened(timerActive: Bool) {
        guard !persisting && !timerActive else {
            return
        }
        timeString = TimeFormatter.formatTimer(0)
        displaySplitScreen()
    }

    func settingsClosed(timerActive: Bool) {
        guard !persisting && !timerActive else {
            return
        }
        displayFullScreenTimeOfDay()
    }

    // MARK: layout animations

    private func adjustDisplayOnTimerStop() {
        if !splitAndFullScreenIdentical {
            displayFullScreenTimeOfDay()
        }
    }

    func displayFullScreenTimeOfDay() {
        transitionToken += 1
        let token = transitionToken
        withAnimation(.linear(duration: 0.4)) {
            timerOpacity = 0
            clockOpacity = 0
        }
        after(0.5) { [weak self] in
            guard let self = self, self.transitionToken == token else { return }
            self.layout = .fullScreenClock
        }
        after(1.0) { [weak self] in
            guard let self = self, self.transitionToken == token else { return }
            withAnimation(.linear(duration: 0.4)) {
                self.clockOpacity = 1
            }
        }
    }

    func displaySplitScreen() {
        transitionToken += 1
        let token = transitionToken
        withAnimation(.linear(duration: 0.4)) {
            clockOpacity = 0
        }
        after(0.5) { [weak self] in
            guard let self = self, self.transitionToken == token else { return }
            self.layout = .split
        }
        after(1.0) { [weak self] in
            guard let self = self, self.transitionToken == token else { return }
            withAnimation(.linear(duration: 0.4)) {
                self.clockOpacity = 1
                self.timerOpacity = 1
            }
        }
    }

    private func initSector(elapsed: Int, remaining: Int) {
        guard sector == nil, options.showDurationSector, remaining < TimerDisplayModel.secsPerHour else {
            return
        }
        let n = now()
        let start = DateUtils.minuteHandAngle(n)
        let end = DateUtils.minuteHandAngle(n.addingTimeInterval(TimeInterval(remaining)))
        sector = DurationSector(startAngle: start, endAngle: end, currentAngle: start, isOvertime: false,
                                showElapsedSector: (elapsed + remaining) < TimerDisplayModel.secsPerHour)
        sectorRevealDate = Date().addingTimeInterval(1)
    }
}

/// State of the pre-meeting countdown window.
@MainActor
final class CountdownModel: ObservableObject {
    @Published var options: Options
    @Published private(set) var startDate: Date?
    @Published private(set) var opacity: Double = 0
    @Published var windowed = false

    let now: () -> Date
    private(set) var isCountingDown = false
    private(set) var isDone = false

    init(options: Options, now: @escaping () -> Date) {
        self.options = options
        self.now = now
    }

    var durationMins: Int {
        options.countdownDurationMins
    }

    func start(offsetSeconds: Int) {
        startDate = now().addingTimeInterval(TimeInterval(-offsetSeconds))
        isCountingDown = true
        opacity = 0
        after(0.1) { [weak self] in
            withAnimation(.easeIn(duration: 1.0)) {
                self?.opacity = 1
            }
        }
    }

    /// Seconds left (fractional), nil when not counting down.
    func secondsLeft(at date: Date) -> Double? {
        guard let s = startDate else {
            return nil
        }
        return Double(durationMins * 60) - date.timeIntervalSince(s)
    }

    var isTimeUp: Bool {
        guard isCountingDown, let left = secondsLeft(at: now()) else {
            return false
        }
        return left < 0
    }

    func markStopped() {
        isDone = true
        isCountingDown = false
        withAnimation(.easeOut(duration: 0.8)) {
            opacity = 0
        }
    }

    func resetDone() {
        isDone = false
    }

    func clear() {
        startDate = nil
    }
}
