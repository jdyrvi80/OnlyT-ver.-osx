import AppKit
import SwiftUI
import OnlyTCore

// MARK: - Buttons in the style of the original (Material Design, Blue Grey)

struct MaterialButtonStyle: ButtonStyle {
    var fill: Color
    var foreground: Color = .white
    var cornerRadius: CGFloat = 4

    func makeBody(configuration: Configuration) -> some View {
        MaterialButton(configuration: configuration, fill: fill, foreground: foreground, cornerRadius: cornerRadius)
    }

    private struct MaterialButton: View {
        let configuration: ButtonStyleConfiguration
        let fill: Color
        let foreground: Color
        let cornerRadius: CGFloat
        @Environment(\.isEnabled) private var isEnabled

        var body: some View {
            configuration.label
                .foregroundColor(foreground.opacity(isEnabled ? 1 : 0.55))
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(
                    RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                        .fill(isEnabled ? fill : Color.gray.opacity(0.35))
                        .shadow(color: .black.opacity(isEnabled ? (configuration.isPressed ? 0.15 : 0.3) : 0), radius: configuration.isPressed ? 1 : 2, y: 1)
                )
                .brightness(configuration.isPressed ? -0.08 : 0)
                .contentShape(Rectangle())
        }
    }
}

struct RoundIconButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        RoundIcon(configuration: configuration)
    }

    private struct RoundIcon: View {
        let configuration: ButtonStyleConfiguration
        @Environment(\.isEnabled) private var isEnabled

        var body: some View {
            configuration.label
                .foregroundColor(Palette.primaryDark.opacity(isEnabled ? 1 : 0.4))
                .frame(width: 40, height: 40)
                .background(Circle().fill(Color(hex: 0xCFD8DC)).shadow(color: .black.opacity(0.25), radius: 2, y: 1))
                .brightness(configuration.isPressed ? -0.1 : 0)
                .contentShape(Circle())
        }
    }
}

// MARK: - Scroll wheel catcher (mouse wheel adjusts the timer)

private final class ScrollCatcherView: NSView {
    var onScroll: ((Bool, NSEvent.ModifierFlags) -> Void)?
    private var accumulated: CGFloat = 0

    override func hitTest(_ point: NSPoint) -> NSView? {
        // only intercept scroll events; clicks go to the SwiftUI content underneath
        if let e = NSApp.currentEvent, e.type == .scrollWheel {
            return super.hitTest(point)
        }
        return nil
    }

    override func scrollWheel(with event: NSEvent) {
        // with Shift macOS turns vertical scrolling into horizontal scrolling
        let delta = abs(event.scrollingDeltaY) >= abs(event.scrollingDeltaX) ? event.scrollingDeltaY : event.scrollingDeltaX
        if event.hasPreciseScrollingDeltas {
            accumulated += delta
            if abs(accumulated) >= 12 {
                onScroll?(accumulated > 0, event.modifierFlags)
                accumulated = 0
            }
        } else if delta != 0 {
            onScroll?(delta > 0, event.modifierFlags)
        }
    }
}

@MainActor
private struct ScrollCatcher: NSViewRepresentable {
    let onScroll: (Bool, NSEvent.ModifierFlags) -> Void

    func makeNSView(context: Context) -> ScrollCatcherView {
        let v = ScrollCatcherView()
        v.onScroll = onScroll
        return v
    }

    func updateNSView(_ nsView: ScrollCatcherView, context: Context) {
        nsView.onScroll = onScroll
    }
}

// MARK: - Operator page

@MainActor
struct OperatorView: View {
    @ObservedObject var model: AppModel

    var body: some View {
        ZStack(alignment: .bottom) {
            if model.isShrunk {
                CompactOperatorView(model: model)
            } else {
                fullLayout
            }
            if let s = model.snackbar {
                SnackbarView(message: s) {
                    model.snackbar = nil
                }
                .padding(10)
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .animation(.easeInOut(duration: 0.25), value: model.snackbar)
        .frame(minWidth: 143, minHeight: 118)
        .background(Color(nsColor: .windowBackgroundColor))
    }

    private var fullLayout: some View {
        VStack(spacing: 10) {
            if model.isManualMode && model.talks.count <= 1 {
                Text(L10n.t("MANUAL_MODE"))
                    .font(.system(size: 14))
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, minHeight: 30, alignment: .leading)
            } else {
                TalkSelector(model: model)
                    .frame(height: 30)
            }

            HStack(spacing: 8) {
                TimerBox(model: model, compact: false)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                AdjustButtons(model: model)
                    .frame(width: 40)
            }
            .frame(minHeight: 90)
            .layoutPriority(1)

            HStack(spacing: 8) {
                StartStopButton(model: model)
                if model.options.showPauseButton {
                    Button(action: { model.pauseTimer() }) {
                        Image(systemName: "pause.fill").font(.system(size: 18, weight: .semibold))
                    }
                    .buttonStyle(MaterialButtonStyle(fill: Palette.primary))
                    .disabled(!model.canPause)
                    .help(L10n.t("PAUSE_TIMER"))
                    .frame(width: 40)
                }
            }
            .frame(height: 54)

            HStack(spacing: 10) {
                if model.isCountdownActive {
                    Button {
                        model.stopCountdown()
                    } label: {
                        Text(L10n.t("CLOSE_COUNTDOWN"))
                            .font(.system(size: 13, weight: .semibold))
                            .padding(.horizontal, 14)
                    }
                    .buttonStyle(MaterialButtonStyle(fill: Palette.primary))
                    .frame(height: 34)
                    .fixedSize(horizontal: true, vertical: false)
                    .help(L10n.t("CLOSE_COUNTDOWN_TOOLTIP"))
                } else if model.shouldShowCircuitVisitToggle {
                    Toggle(L10n.t("CIRCUIT_VISIT"), isOn: Binding(
                        get: { model.options.isCircuitVisit },
                        set: { model.setCircuitVisit($0) }))
                        .toggleStyle(.switch)
                        .disabled(model.isRunning)
                }
                Spacer(minLength: 0)
                Button(action: { model.openScheduleEditor() }) {
                    Image(systemName: "list.bullet.rectangle").font(.system(size: 16, weight: .semibold))
                }
                .buttonStyle(RoundIconButtonStyle())
                .help(L10n.t("MAC_EDIT_SCHEDULE"))

                Button(action: { model.openHelp() }) {
                    Image(systemName: "questionmark").font(.system(size: 17, weight: .bold))
                }
                .buttonStyle(RoundIconButtonStyle())
                .help(L10n.t("HELP"))

                Button(action: { model.openSettings() }) {
                    Image(systemName: "gearshape.fill").font(.system(size: 18))
                }
                .buttonStyle(RoundIconButtonStyle())
                .disabled(!model.canOpenSettings)
                .help(model.settingsHint)
            }
            .frame(height: 40)
        }
        .padding(12)
    }
}

// MARK: - Talk selector (combo box with durations and overtime)

@MainActor
private struct TalkSelector: View {
    @ObservedObject var model: AppModel

    var body: some View {
        Button {
            model.talkListShown.toggle()
        } label: {
            HStack(spacing: 8) {
                if let t = model.currentTalk {
                    Text(t.originalOrModifiedDurationString)
                        .monospacedDigit()
                        .foregroundColor(.secondary)
                    Text(t.name)
                        .lineLimit(1)
                        .truncationMode(.tail)
                } else {
                    Text(L10n.t("TALK_SELECTOR")).foregroundColor(.secondary)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.down")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(.secondary)
            }
            .font(.system(size: 14))
            .padding(.horizontal, 8)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(
                VStack {
                    Spacer()
                    Rectangle().fill(Color.secondary.opacity(0.5)).frame(height: 1)
                }
            )
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .disabled(model.isRunning)
        .help(L10n.t("TALK_SELECTOR"))
        .popover(isPresented: $model.talkListShown, arrowEdge: .bottom) {
            TalkList(model: model) { id in
                model.selectTalk(id)
                model.talkListShown = false
            }
        }
    }
}

@MainActor
private struct TalkList: View {
    @ObservedObject var model: AppModel
    let onSelect: (Int) -> Void

    var body: some View {
        VStack(spacing: 0) {
            list
            Divider()
            HStack(spacing: 8) {
                if model.isScheduleCustomised {
                    Label(L10n.t("MAC_SCHEDULE_CUSTOMISED"), systemImage: "pencil")
                        .font(.system(size: 11))
                        .foregroundColor(.secondary)
                }
                Spacer(minLength: 0)
                Button(L10n.t("MAC_EDIT_SCHEDULE")) {
                    model.openScheduleEditor()
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
        }
        .frame(width: 380)
    }

    private var list: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                ForEach(model.talks) { t in
                    Button {
                        onSelect(t.id)
                    } label: {
                        HStack(spacing: 10) {
                            Text(t.originalOrModifiedDurationString)
                                .monospacedDigit()
                                .foregroundColor(.secondary)
                                .frame(width: 46, alignment: .leading)
                            Text(t.name)
                                .lineLimit(1)
                            Spacer(minLength: 12)
                            if let o = t.overtimeString {
                                Text(o)
                                    .monospacedDigit()
                                    .fontWeight(.semibold)
                                    .foregroundColor(t.finishedOvertime ? Palette.overtimeRed : Palette.overtimeGreen)
                            }
                        }
                        .font(.system(size: 14))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(t.id == model.talkId ? Palette.primary.opacity(0.18) : Color.clear)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.vertical, 6)
        }
        .frame(width: 380)
        .frame(maxHeight: 600)
        .fixedSize(horizontal: false, vertical: true)
    }
}

// MARK: - The black timer box

@MainActor
struct TimerBox: View {
    @ObservedObject var model: AppModel
    let compact: Bool
    @FocusState private var editFocused: Bool

    var body: some View {
        GeometryReader { geo in
            ZStack {
                RoundedRectangle(cornerRadius: 6, style: .continuous).fill(Color.black)

                if model.isEditingDuration {
                    TextField("", text: $model.editableDuration)
                        .textFieldStyle(.plain)
                        .font(.system(size: min(64, geo.size.height * 0.55), weight: .bold))
                        .monospacedDigit()
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white)
                        .focused($editFocused)
                        .onSubmit { model.acceptDurationEdit() }
                        .onExitCommand { model.cancelDurationEdit() }
                        .onAppear {
                            DispatchQueue.main.async {
                                editFocused = true
                            }
                        }
                        .padding(.horizontal, 10)
                } else {
                    FittedText(text: model.currentTimerValueString, baseSize: 80, color: Palette.timer(model.textColour))
                        .animation(.easeIn(duration: 0.4), value: model.textColour)
                        .padding(.horizontal, compact ? 4 : 18)
                        .padding(.vertical, compact ? 2 : 14)
                        .offset(y: model.flashProgress * min(100, geo.size.height * 0.6))
                }

                if !compact {
                    overlays
                }

                ScrollCatcher { up, flags in
                    model.scrollAdjust(up: up, flags: flags)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
            .contentShape(Rectangle())
            .onTapGesture(count: 2) {
                model.startDurationEdit()
            }
        }
    }

    private var overlays: some View {
        VStack(spacing: 0) {
            HStack(alignment: .top) {
                if model.options.allowCountUpToggle && model.isValidTalk {
                    Button(action: { model.countUpToggle() }) {
                        Image(systemName: model.countUp ? "arrow.up" : "arrow.down")
                            .font(.system(size: 13, weight: .heavy))
                            .foregroundColor(Palette.cream)
                            .frame(width: 18, height: 18)
                    }
                    .buttonStyle(.plain)
                    .help(model.countUp ? L10n.t("COUNTING_UP") : L10n.t("COUNTING_DOWN"))
                }
                Spacer(minLength: 0)
                if model.isCircuitVisitShown {
                    Text(L10n.t("CIRCUIT_VISIT_BRACKETS"))
                        .font(.system(size: 12))
                        .foregroundColor(Palette.cream)
                }
            }
            .padding(.horizontal, 6)
            .padding(.top, 4)

            Spacer(minLength: 0)

            HStack(alignment: .bottom, spacing: 0) {
                DurationsLine(d: model.durations)
                Spacer(minLength: 0)
                if model.isBellVisible {
                    Button(action: { model.bellToggle() }) {
                        Image(systemName: "bell.fill")
                            .font(.system(size: 15))
                            .foregroundColor(model.bellColour)
                            .frame(width: 22, height: 22)
                    }
                    .buttonStyle(.plain)
                    .help(model.bellTooltip)
                }
            }
            .padding(.horizontal, 6)
            .padding(.bottom, 4)
        }
    }
}

private struct DurationsLine: View {
    let d: DurationStrings

    var body: some View {
        HStack(spacing: 3) {
            item(d.duration1, d.tooltip1, active: d.activeIndex == 1)
            if !d.duration2.isEmpty {
                arrow
                item(d.duration2, d.tooltip2, active: d.activeIndex == 2)
            }
            if !d.duration3.isEmpty {
                arrow
                item(d.duration3, d.tooltip3, active: d.activeIndex == 3)
            }
        }
        .font(.system(size: 12))
        .monospacedDigit()
    }

    private var arrow: some View {
        Text("→").foregroundColor(Palette.creamDim)
    }

    private func item(_ s: String, _ tip: String, active: Bool) -> some View {
        Text(s)
            .foregroundColor(active ? Palette.cream : Palette.creamDim)
            .help(tip)
    }
}

// MARK: - +/- and edit buttons

@MainActor
private struct AdjustButtons: View {
    @ObservedObject var model: AppModel

    var body: some View {
        VStack(spacing: 4) {
            Button {
                model.incrementFromClick(up: true)
            } label: {
                Image(systemName: "plus").font(.system(size: 17, weight: .bold))
            }
            .buttonStyle(MaterialButtonStyle(fill: Color(hex: 0xCFD8DC), foreground: Palette.primaryDark))
            .frame(height: 32)
            .disabled(!model.canIncrease)
            .help(L10n.t("TIME_INCREASE"))

            Button {
                model.incrementFromClick(up: false)
            } label: {
                Image(systemName: "minus").font(.system(size: 17, weight: .bold))
            }
            .buttonStyle(MaterialButtonStyle(fill: Color(hex: 0xCFD8DC), foreground: Palette.primaryDark))
            .frame(height: 32)
            .disabled(!model.canDecrease)
            .help(L10n.t("TIME_DECREASE"))

            Spacer(minLength: 0)

            if model.isEditingDuration {
                Button(action: { model.acceptDurationEdit() }) {
                    Image(systemName: "checkmark").font(.system(size: 16, weight: .bold))
                }
                .buttonStyle(MaterialButtonStyle(fill: Color(hex: 0xCFD8DC), foreground: Palette.primaryDark))
                .frame(height: 32)
                .help(L10n.t("ACCEPT_DURATION"))
            } else {
                Button(action: { model.startDurationEdit() }) {
                    Image(systemName: "pencil").font(.system(size: 16, weight: .bold))
                }
                .buttonStyle(MaterialButtonStyle(fill: Color(hex: 0xCFD8DC), foreground: Palette.primaryDark))
                .frame(height: 32)
                .disabled(!model.canEditDuration)
                .help(L10n.t("EDIT_DURATION"))
            }
        }
    }
}

// MARK: - Start / stop

@MainActor
private struct StartStopButton: View {
    @ObservedObject var model: AppModel

    var body: some View {
        Group {
            if model.isRunning {
                Button(action: { model.stopTimer() }) {
                    Image(systemName: "stop.fill").font(.system(size: 26, weight: .bold))
                }
                .buttonStyle(MaterialButtonStyle(fill: Palette.primary))
                .help(L10n.t("STOP_TIMER"))
            } else {
                Button(action: { model.startTimer() }) {
                    Image(systemName: "play.fill").font(.system(size: 26, weight: .bold))
                }
                .buttonStyle(MaterialButtonStyle(fill: Palette.primaryDark))
                .disabled(!model.canStart)
                .help(L10n.t("START_TIMER"))
            }
        }
    }
}

// MARK: - Compact ("shrunk") layout

@MainActor
private struct CompactOperatorView: View {
    @ObservedObject var model: AppModel

    var body: some View {
        VStack(spacing: 4) {
            HStack(spacing: 2) {
                Spacer(minLength: 0)
                smallButton("gearshape", L10n.t("SETTINGS"), enabled: model.canOpenSettings) {
                    model.openSettings()
                }
                smallButton("arrow.up.left.and.arrow.down.right", L10n.t("EXPAND_WINDOW"), enabled: true) {
                    model.expandHandler?()
                }
                smallButton("xmark.square", L10n.t("CLOSE_APP"), enabled: !model.isRunning) {
                    NSApp.terminate(nil)
                }
            }
            .frame(height: 20)

            TimerBox(model: model, compact: true)
                .frame(maxWidth: .infinity, maxHeight: .infinity)

            StartStopButton(model: model)
                .frame(height: 30)
        }
        .padding(6)
    }

    private func smallButton(_ symbol: String, _ tip: String, enabled: Bool, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 13))
                .foregroundColor(.secondary)
                .frame(width: 22, height: 20)
        }
        .buttonStyle(.plain)
        .disabled(!enabled)
        .help(tip)
    }
}

// MARK: - Snackbar

private struct SnackbarView: View {
    let message: SnackbarMessage
    let onDismiss: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Text(message.text)
                .font(.system(size: 13))
                .foregroundColor(.white)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
            if let title = message.actionTitle {
                Button(title) {
                    message.action?()
                    onDismiss()
                }
                .buttonStyle(.plain)
                .font(.system(size: 13, weight: .bold))
                .foregroundColor(Palette.accent)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(RoundedRectangle(cornerRadius: 6, style: .continuous).fill(Color(hex: 0x323232)))
        .onTapGesture {
            onDismiss()
        }
    }
}
