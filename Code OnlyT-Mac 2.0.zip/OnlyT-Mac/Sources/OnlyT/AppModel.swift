import AppKit
import SwiftUI
import UniformTypeIdentifiers
import OnlyTCore

/// Message shown at the bottom of the operator window (Material "snackbar").
struct SnackbarMessage: Identifiable, Equatable {
    let id = UUID()
    let text: String
    let actionTitle: String?
    let action: (() -> Void)?

    static func == (lhs: SnackbarMessage, rhs: SnackbarMessage) -> Bool {
        lhs.id == rhs.id
    }
}

/// Shared, always up-to-date copy of the options for non-UI services.
final class OptionsBox {
    var value: Options

    init(_ value: Options) {
        self.value = value
    }
}

/// The heart of the app: port of OperatorPageViewModel + MainViewModel.
@MainActor
final class AppModel: ObservableObject {
    static let maxTimerMins = 99
    static let maxTimerSecs = maxTimerMins * 60
    static let helpURL = URL(string: "https://github.com/AntonyCorbett/OnlyT/wiki")!

    // MARK: services

    let optionsStore: OptionsStore
    let optionsBox: OptionsBox
    let dateTime: SystemDateTimeProvider
    let schedule: TalkScheduleService
    let adaptive: AdaptiveTimerService
    let engine = TalkTimerEngine()
    let bell = BellPlayer()
    let timing: TimingDataStore
    let reminders = ReminderLogic()
    let toasts = ToastCenter()
    let display: TimerDisplayModel
    let countdownModel: CountdownModel
    let outputController: TimerOutputController
    let countdownController: CountdownController
    let router: WebRouter
    let webServer: WebServer
    private var webBridge: WebBridge?
    let sessionId = UUID().uuidString

    weak var mainWindow: NSWindow?
    var openSettingsHandler: (() -> Void)?
    var rebuildMenusHandler: (() -> Void)?
    var expandHandler: (() -> Void)?
    var shrinkHandler: (() -> Void)?
    var openScheduleEditorHandler: (() -> Void)?

    // MARK: published state

    @Published var options: Options {
        didSet {
            optionsChanged(from: oldValue)
        }
    }

    @Published private(set) var talkId = 0
    @Published private(set) var targetSeconds = 0
    @Published private(set) var secondsElapsed = 0
    @Published private(set) var secondsRemaining = 0
    @Published private(set) var countUp = false
    @Published private(set) var isRunning = false
    @Published private(set) var isPaused = false
    @Published private(set) var isOvertime = false
    @Published private(set) var textColour: TimerColour = .white
    @Published private(set) var durations = DurationStrings()
    @Published private(set) var isCountdownActive = false
    /// 0 → 1 → 0 "flash" of the operator timer when a timer starts.
    @Published private(set) var flashProgress: CGFloat = 0

    // UI state kept here instead of SwiftUI @State: in recent SDKs @State is a macro
    // whose plugin ships only with full Xcode, not with the Command Line Tools.
    @Published var talkListShown = false
    @Published var startTimesDraft = ""
    @Published var apiCodeDraft = ""
    @Published private(set) var bellIsPlaying = false
    @Published var isEditingDuration = false
    @Published var editableDuration = ""
    @Published var snackbar: SnackbarMessage?
    @Published var isShrunk = false
    @Published private(set) var settingsOpen = false
    @Published private(set) var webServerError: String?
    @Published private(set) var localIP: String?
    @Published private(set) var scheduleFiles: [String] = []
    @Published private(set) var screens: [ScreenInfo] = []

    // MARK: private state

    private var isStarting = false
    private var flashToken = 0
    private var pausedElapsedSecs = 0
    private var startToken = 0
    private var meetingStartTimeFromCountdown: Date?
    private var tickTimer: RepeatingTimer?
    private var heartbeatTimer: RepeatingTimer?
    private var reminderTimer: RepeatingTimer?
    private var lastScheduleCheck = Date.distantPast
    private var lastFeedAttempt = Date.distantPast
    private var feedLoading = false
    private var saveToken = 0
    private var persistUntil = Date.distantPast
    private var persistElapsedSecs = 0
    private var persistTargetSecs = 0
    private var persistClosingSecs = TalkScheduleItem.defaultClosingSecs
    private var persistCountUp = false
    private var screenObserver: NSObjectProtocol?

    // MARK: init

    init() {
        AppFolders.ensure(AppFolders.appSupport)
        AppFolders.ensure(AppFolders.documents)
        AppFolders.ensure(AppFolders.schedules)

        let store = OptionsStore(fileURL: AppFolders.optionsFile)
        let dt = SystemDateTimeProvider(offset: AppModel.dateTimeOffsetFromArguments())
        var opts = store.options
        opts.midWeekOrWeekend = DateUtils.isWeekend(dt.now(), includesFriday: opts.weekendIncludesFriday) ? .weekend : .midWeek
        // as in the original, the circuit visit flag is not remembered (command line: --covisit)
        let args = CommandLine.arguments.map { $0.lowercased() }
        opts.isCircuitVisit = args.contains("--covisit")
        if let i = args.firstIndex(of: "--feed"), i + 1 < CommandLine.arguments.count,
           let url = URL(string: CommandLine.arguments[i + 1]), url.scheme != nil {
            opts.feedUri = url.absoluteString
        }
        L10n.shared.setLanguage(opts.culture)

        let box = OptionsBox(opts)
        let sched = TalkScheduleService(optionsProvider: { box.value },
                                        schedulesFolder: AppFolders.schedules,
                                        legacyScheduleFile: AppFolders.legacySchedule)
        sched.customStore = CustomScheduleStore(fileURL: AppFolders.customSchedules)
        sched.dateProvider = { dt.now() }
        let adapt = AdaptiveTimerService(optionsProvider: { box.value }, itemsProvider: { sched.items }, dateTime: dt)

        optionsStore = store
        optionsBox = box
        dateTime = dt
        schedule = sched
        adaptive = adapt
        timing = TimingDataStore(fileURL: AppFolders.timingDatabase)
        display = TimerDisplayModel(options: opts, now: { dt.now() })
        countdownModel = CountdownModel(options: opts, now: { dt.now() })
        outputController = TimerOutputController(model: display)
        countdownController = CountdownController(model: countdownModel)
        router = WebRouter(host: nil)
        webServer = WebServer(router: router)
        _options = Published(initialValue: opts)

        // wiring that needs self
        let bridge = WebBridge(model: self)
        webBridge = bridge
        router.host = bridge

        outputController.optionsProvider = { [unowned self] in self.options }
        outputController.onFrameSaved = { [weak self] frame in
            if self?.options.timerWindowFrame != frame {
                self?.options.timerWindowFrame = frame
            }
        }
        outputController.onVisibilityChanged = { [weak self] in
            self?.updateMainWindowLevel()
        }
        countdownController.optionsProvider = { [unowned self] in self.options }
        countdownController.onFrameSaved = { [weak self] frame in
            if self?.options.countdownWindowFrame != frame {
                self?.options.countdownWindowFrame = frame
            }
        }
        bell.onStatusChange = { [weak self] playing in
            self?.bellIsPlaying = playing
        }
        webServer.onError = { [weak self] message in
            DispatchQueue.main.async {
                MainActor.assumeIsolated {
                    self?.serverFailed(message)
                }
            }
        }
        schedule.onScheduleFileNotFound = { [weak self] in
            MainActor.assumeIsolated {
                self?.scheduleFileNotFound()
            }
        }
        schedule.onScheduleFileAutoSelected = { [weak self] name in
            MainActor.assumeIsolated {
                if self?.options.scheduleFile != name {
                    self?.options.scheduleFile = name
                }
            }
        }
    }

    /// `--datetime "yyyy-MM-dd HH:mm"` simulates another date/time (as in the original).
    private static func dateTimeOffsetFromArguments() -> TimeInterval {
        let args = CommandLine.arguments
        guard let i = args.firstIndex(where: { $0.lowercased() == "--datetime" }), i + 1 < args.count else {
            return 0
        }
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        for format in ["yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd"] {
            f.dateFormat = format
            if let d = f.date(from: args[i + 1]) {
                return d.timeIntervalSinceNow
            }
        }
        return 0
    }

    // MARK: lifecycle

    func start() {
        refreshScreens()
        refreshScheduleFiles()
        applyAppearance()

        if let cached = TimesFeed.load(feedURL: feedURL, cacheURL: AppFolders.feedCache, today: dateTime.now(), allowDownload: false) {
            schedule.feedMeeting = cached
            schedule.feedSucceeded = true
        }
        schedule.reset()
        selectFirstTalk()

        restartWebServer()

        tickTimer = RepeatingTimer(interval: 0.1) { [weak self] in self?.tick() }
        heartbeatTimer = RepeatingTimer(interval: 1.0) { [weak self] in self?.heartbeat() }
        reminderTimer = RepeatingTimer(interval: 5.0) { [weak self] in self?.reminderTick() }

        screenObserver = NotificationCenter.default.addObserver(
            forName: NSApplication.didChangeScreenParametersNotification, object: nil, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated {
                self?.screensChanged()
            }
        }

        // on launch, display the timer window after a short delay (as the original does)
        after(1.0) { [weak self] in
            guard let self = self, self.options.canDisplayTimerWindow else { return }
            self.outputController.open()
            self.updateMainWindowLevel()
        }

        loadFeedAsync()
    }

    func shutdown() {
        tickTimer?.invalidate()
        heartbeatTimer?.invalidate()
        reminderTimer?.invalidate()
        outputController.close()
        countdownController.close()
        toasts.clearAll()
        webServer.stop()
        if let o = screenObserver {
            NotificationCenter.default.removeObserver(o)
        }
        optionsStore.update(options)
    }

    // MARK: computed state for the views

    var talks: [TalkScheduleItem] {
        schedule.items
    }

    var currentTalk: TalkScheduleItem? {
        schedule.item(talkId)
    }

    var currentTimerValueString: String {
        TimeFormatter.formatTimer(countUp ? secondsElapsed : secondsRemaining)
    }

    var isValidTalk: Bool {
        currentTalk != nil
    }

    var isAutoMode: Bool { options.operatingMode == .automatic }
    var isManualMode: Bool { options.operatingMode == .manual }

    var isCircuitVisitShown: Bool {
        options.isCircuitVisit && isAutoMode
    }

    var shouldShowCircuitVisitToggle: Bool {
        isAutoMode && options.showCircuitVisitToggle
    }

    var isBellVisible: Bool {
        guard let t = currentTalk else { return false }
        return t.bellApplicable && options.isBellEnabled && !isShrunk
    }

    var bellColour: Color {
        guard let t = currentTalk else { return Palette.bellInactive }
        if isOvertime { return .red }
        return t.autoBell ? Palette.bellActive : Palette.bellInactive
    }

    var bellTooltip: String {
        guard let t = currentTalk else { return "" }
        if isOvertime { return L10n.t("SOUND_BELL") }
        return t.autoBell ? L10n.t("ACTIVE_BELL") : L10n.t("INACTIVE_BELL")
    }

    var canStart: Bool {
        (!isRunning || isPaused) && isValidTalk && !isEditingDuration
    }

    var canStop: Bool { isRunning }
    var canPause: Bool { isRunning }

    var canOpenSettings: Bool {
        !isRunning || isPaused
    }

    var settingsHint: String {
        isRunning ? L10n.t("NOT_AVAIL_TIMER_RUNNING") : L10n.t("SETTINGS")
    }

    private var currentTalkEditable: Bool {
        currentTalk?.editable == true
    }

    var canIncrease: Bool {
        !isRunning && !isEditingDuration && targetSeconds < AppModel.maxTimerSecs && currentTalkEditable
    }

    var canDecrease: Bool {
        !isRunning && !isEditingDuration && targetSeconds > 0 && currentTalkEditable
    }

    var canEditDuration: Bool {
        !isRunning && !isEditingDuration && currentTalkEditable
    }

    var windowTitle: String {
        var title = "OnlyT"
        if options.operatingMode == .scheduleFile, let f = options.scheduleFile, !f.isEmpty {
            title += " - " + (f as NSString).deletingPathExtension
        }
        if schedule.hasCustomSchedule {
            title += " (" + L10n.t("MAC_SCHEDULE_CUSTOMISED_SHORT") + ")"
        }
        return title
    }

    var webClockURL: String? {
        guard let ip = localIP else { return nil }
        return "http://\(ip):\(options.httpServerPort)/index"
    }

    private var feedURL: URL {
        URL(string: options.feedUri) ?? URL(string: Options.defaultFeedUri)!
    }

    // MARK: talk selection

    func selectTalk(_ id: Int) {
        guard !isRunning else { return }
        setTalkId(id)
    }

    func selectNextTalk() {
        guard !isRunning, let i = talks.firstIndex(where: { $0.id == talkId }), i + 1 < talks.count else { return }
        setTalkId(talks[i + 1].id)
    }

    func selectPreviousTalk() {
        guard !isRunning, let i = talks.firstIndex(where: { $0.id == talkId }), i > 0 else { return }
        setTalkId(talks[i - 1].id)
    }

    private func setTalkId(_ id: Int) {
        guard id != talkId else { return }
        cancelDurationEdit()
        talkId = id
        isPaused = false
        pausedElapsedSecs = 0
        secondsElapsed = 0
        engine.isPaused = false

        let talk = currentTalk
        refreshCountUpFlag(talk)
        setTargetSeconds(talk?.plannedDurationSeconds ?? 0)
        secondsRemaining = targetSeconds
        refreshDurations(talk)
        isOvertime = false
        engine.setupTalk(talkId: id, targetSeconds: targetSeconds, closingSecs: talk?.closingSecs ?? TalkScheduleItem.defaultClosingSecs)
        updateRunningState()
    }

    private func selectFirstTalk() {
        if let first = talks.first {
            setTalkId(first.id)
        }
    }

    private func setTargetSeconds(_ value: Int) {
        if targetSeconds != value {
            targetSeconds = value
            secondsRemaining = value
        }
    }

    private func refreshCountUpFlag(_ talk: TalkScheduleItem?) {
        countUp = talk?.countUp ?? options.countUp
    }

    private func refreshDurations(_ talk: TalkScheduleItem?) {
        durations = DurationStrings.make(adaptiveMode: options.effectiveAdaptiveMode, talk: talk)
    }

    private func updateRunningState() {
        let running = (engine.isRunning || isStarting) && !isPaused
        if isRunning != running {
            isRunning = running
        }
    }

    // MARK: start / stop / pause

    func startTimer() {
        guard canStart else { return }
        if isPaused {
            resumeTimer()
        } else {
            startNewTimer()
        }
    }

    func toggleStartStop() {
        if isRunning {
            stopTimer()
        } else {
            startTimer()
        }
    }

    private func delayToNextSecond() -> Double {
        let ms = dateTime.now().timeIntervalSince1970.truncatingRemainder(dividingBy: 1) * 1000
        return ms > 100 ? (1000 - ms) / 1000 : 0
    }

    private func startNewTimer() {
        isStarting = true
        secondsElapsed = 0
        engine.isPaused = false
        runStartFlash()
        updateRunningState()
        adjustForAdaptiveTime()

        let id = talkId
        textColour = TimerColour.forTimeRemaining(targetSeconds, closingSecs: currentTalk?.closingSecs ?? TalkScheduleItem.defaultClosingSecs)
        timerStartedNotification(targetSeconds: targetSeconds)
        storeTimerStartData()

        startToken += 1
        let token = startToken
        // sync to the second, so the clock and timer seconds tick together
        after(delayToNextSecond()) { [weak self] in
            guard let self = self, self.startToken == token, self.isStarting else { return }
            self.engine.start(targetSecs: self.targetSeconds, talkId: id, countUp: self.countUp)
            self.updateRunningState()
        }
    }

    private func resumeTimer() {
        isPaused = false
        isStarting = true
        engine.isPaused = false
        runStartFlash()
        updateRunningState()

        let id = talkId
        let resumedTarget = targetSeconds
        textColour = TimerColour.forTimeRemaining(resumedTarget, closingSecs: currentTalk?.closingSecs ?? TalkScheduleItem.defaultClosingSecs)
        timerStartedNotification(targetSeconds: resumedTarget)

        startToken += 1
        let token = startToken
        after(delayToNextSecond()) { [weak self] in
            guard let self = self, self.startToken == token, self.isStarting else { return }
            self.engine.start(targetSecs: resumedTarget, talkId: id, countUp: self.countUp)
            self.updateRunningState()
        }
    }

    /// The timer digits drop and come back when a timer starts (RunFlashAnimation of the original).
    private func runStartFlash() {
        flashToken += 1
        let token = flashToken
        withAnimation(.easeIn(duration: 0.4)) {
            flashProgress = 1
        }
        after(0.4) { [weak self] in
            guard let self = self, self.flashToken == token else { return }
            withAnimation(.easeOut(duration: 0.4)) {
                self.flashProgress = 0
            }
        }
    }

    /// TimerStartMessage of the original.
    private func timerStartedNotification(targetSeconds target: Int) {
        display.timerStarted(targetSeconds: target, countUp: countUp)
        persistTargetSecs = target
        persistCountUp = countUp
        reminders.timerStarted()
        toasts.clearAll()
    }

    func stopTimer() {
        guard isRunning else { return }
        isOvertime = false
        guard let talk = currentTalk else { return }

        let totalElapsed = pausedElapsedSecs + engine.currentSecondsElapsed
        let persist = options.persistStudentTime && talk.persistFinalTimerValue
        let stoppedId = talkId

        pausedElapsedSecs = 0
        if engine.stop() {
            timerChanged()
        }
        startToken += 1
        isStarting = false
        isPaused = false
        engine.isPaused = false

        storeTimerStopData()
        textColour = .white
        updateRunningState()

        // TimerStopMessage
        schedule.timerStopped(talkId: stoppedId, elapsedSecs: totalElapsed)
        display.timerStopped(persistFinalValue: persist, isPaused: false)
        persistUntil = .distantPast
        if persist {
            persistElapsedSecs = totalElapsed
            persistUntil = dateTime.now().addingTimeInterval(TimeInterval(options.persistDurationSecs))
        }
        let next = schedule.next(after: stoppedId)
        reminders.timerStopped(talk: talk, nextTalkId: next, now: dateTime.now())
        objectWillChange.send()

        // auto-advance
        setTalkId(next)
        if talkId == 0 {
            endOfMeeting()
        } else {
            notifyOfBadTimingIfRequired()
        }
    }

    func pauseTimer() {
        guard isRunning else { return }
        let elapsedSecs = engine.currentSecondsElapsed
        let remainingSecs = max(targetSeconds - elapsedSecs, 0)
        pausedElapsedSecs += elapsedSecs

        if engine.stop() {
            timerChanged()
        }
        startToken += 1
        isStarting = false
        isPaused = true
        engine.isPaused = true
        setTargetSeconds(remainingSecs)
        secondsRemaining = remainingSecs
        isOvertime = false
        textColour = .white
        updateRunningState()

        schedule.timerStopped(talkId: talkId, elapsedSecs: pausedElapsedSecs)
        display.timerStopped(persistFinalValue: false, isPaused: true)
        persistUntil = .distantPast
        objectWillChange.send()
    }

    /// Called whenever the elapsed seconds change (TimerChangedHandler of the original).
    private func timerChanged() {
        isPaused = false
        engine.isPaused = false
        let elapsed = engine.currentSecondsElapsed
        let remaining = engine.targetSecs - elapsed
        textColour = TimerColour.forTimeRemaining(remaining, closingSecs: engine.closingSecs)
        secondsElapsed = pausedElapsedSecs + elapsed
        secondsRemaining = remaining
        persistClosingSecs = engine.closingSecs

        display.timerChanged(remaining: remaining, elapsed: pausedElapsedSecs + elapsed, isRunning: engine.isRunning,
                             closingSecs: engine.closingSecs, countUp: countUp)

        if remaining == 0 && engine.isRunning {
            isOvertime = true
            if let talk = currentTalk, talk.bellApplicable, talk.autoBell {
                bell.play(enabled: options.isBellEnabled, volumePercent: options.bellVolumePercent)
            }
        }
    }

    private func tick() {
        if engine.isRunning && engine.poll() {
            timerChanged()
        }
        if countdownModel.isTimeUp {
            stopCountdown()
        }
    }

    // MARK: adjusting durations

    func increment(_ seconds: Int) {
        if seconds > 0 && !canIncrease { return }
        if seconds < 0 && !canDecrease { return }
        let newSecs = max(targetSeconds + seconds, 0)
        if newSecs <= AppModel.maxTimerSecs {
            setTargetSeconds(newSecs)
            adjustTalkTimeForThisSession()
        }
    }

    /// +/- buttons: Option (or Command) = 15 seconds, Shift = 5 minutes, otherwise 1 minute.
    func incrementFromClick(up: Bool) {
        let flags = NSEvent.modifierFlags
        let step: Int
        if flags.contains(.shift) {
            step = 300
        } else if flags.contains(.option) || flags.contains(.command) || flags.contains(.control) {
            step = 15
        } else {
            step = 60
        }
        increment(up ? step : -step)
    }

    func scrollAdjust(up: Bool, flags: NSEvent.ModifierFlags) {
        guard options.allowMouseWheelTimerAdjust else { return }
        let step: Int
        if flags.contains(.shift) {
            step = 300
        } else if flags.contains(.option) || flags.contains(.command) || flags.contains(.control) {
            step = 15
        } else {
            step = 60
        }
        increment(up ? step : -step)
    }

    private func adjustTalkTimeForThisSession() {
        guard let talk = currentTalk else { return }
        adjustTalkTime(talk, targetSecs: targetSeconds, manualMode: isManualMode)
    }

    private func adjustTalkTime(_ talk: TalkScheduleItem, targetSecs: Int, manualMode: Bool) {
        guard talk.editable else { return }
        let modified = TimeInterval(targetSecs)
        if manualMode {
            talk.originalDuration = modified
        } else {
            talk.modifiedDuration = modified
        }
        if talk.id == talkId {
            setTargetSeconds(targetSecs)
            refreshDurations(talk)
            if !engine.isRunning {
                engine.setupTalk(talkId: talk.id, targetSeconds: targetSecs, closingSecs: talk.closingSecs)
            }
        }
        objectWillChange.send()
    }

    private func adjustForAdaptiveTime() {
        guard talkId > 0, isAutoMode, let newDuration = adaptive.calculateAdaptedDuration(talkId), let talk = currentTalk else {
            return
        }
        talk.adaptedDuration = newDuration
        refreshDurations(talk)
        setTargetSeconds(Int(talk.actualDuration))
        objectWillChange.send()
    }

    // MARK: manual duration editing

    func startDurationEdit() {
        guard canEditDuration else { return }
        editableDuration = TimeFormatter.formatTimer(targetSeconds)
        isEditingDuration = true
    }

    func acceptDurationEdit() {
        guard isEditingDuration else { return }
        guard let secs = AppModel.parseDuration(editableDuration) else {
            showSnackbar(L10n.t("ENTER_VALID_DURATION"))
            return
        }
        setTargetSeconds(secs)
        adjustTalkTimeForThisSession()
        isEditingDuration = false
    }

    func cancelDurationEdit() {
        editableDuration = TimeFormatter.formatTimer(targetSeconds)
        isEditingDuration = false
    }

    static func parseDuration(_ value: String) -> Int? {
        DurationParser.parse(value, maxMinutes: maxTimerMins)
    }

    // MARK: bell / count up / circuit visit

    func bellToggle() {
        guard let talk = currentTalk else { return }
        if isOvertime {
            bell.play(enabled: options.isBellEnabled, volumePercent: options.bellVolumePercent)
        } else {
            talk.autoBell.toggle()
            objectWillChange.send()
        }
    }

    func testBell() {
        bell.play(enabled: true, volumePercent: options.bellVolumePercent)
    }

    func countUpToggle() {
        guard options.allowCountUpToggle, let talk = currentTalk else { return }
        talk.countUp = !countUp
        refreshCountUpFlag(talk)
    }

    func setCircuitVisit(_ value: Bool) {
        if options.isCircuitVisit != value {
            options.isCircuitVisit = value
        }
    }

    // MARK: schedule

    func refreshSchedule() {
        schedule.reset()
        cancelDurationEdit()
        talkId = 0
        isPaused = false
        pausedElapsedSecs = 0
        isOvertime = false
        refreshDurations(nil)
        setTargetSeconds(0)
        selectFirstTalk()
        refreshScheduleFiles()
        objectWillChange.send()
    }

    // MARK: schedule editor (not in the Windows version)

    var isScheduleCustomised: Bool {
        schedule.hasCustomSchedule
    }

    func openScheduleEditor() {
        talkListShown = false
        openScheduleEditorHandler?()
    }

    func makeScheduleEditor() -> ScheduleEditorModel {
        ScheduleEditorModel(talks: talks, title: scheduleContextTitle, isAutoMode: isAutoMode,
                            contextKey: schedule.contextKey(options))
    }

    var scheduleContextTitle: String {
        switch options.operatingMode {
        case .automatic:
            let meeting = options.midWeekOrWeekend == .weekend ? L10n.t("WEEKEND") : L10n.t("MIDWEEK")
            let f = DateFormatter()
            f.locale = Locale(identifier: L10n.shared.languageCode)
            f.dateStyle = .long
            f.timeStyle = .none
            var s = L10n.f("MAC_EDITOR_CONTEXT_AUTO", meeting, f.string(from: DateUtils.mondayOfWeek(dateTime.now())))
            if options.isCircuitVisit {
                s += " " + L10n.t("CIRCUIT_VISIT_BRACKETS")
            }
            return s
        case .scheduleFile:
            return L10n.t("OP_MODE_FILE") + " – " + ((options.scheduleFile ?? "") as NSString).deletingPathExtension
        case .manual:
            return L10n.t("MANUAL_MODE")
        }
    }

    /// Applies the editor's draft to the current schedule. Existing parts keep their id
    /// (so adaptive timing, reminders, reports and remote apps keep working).
    @discardableResult
    func applyScheduleEdit(_ editor: ScheduleEditorModel) -> Bool {
        guard !isRunning && !isPaused else {
            editor.statusText = L10n.t("MAC_STOP_TIMER_TO_APPLY")
            return false
        }
        guard editor.contextKey == schedule.contextKey(options) else {
            // the mode, meeting or week changed while the editor was open
            editor.load(talks)
            editor.statusText = L10n.t("MAC_SCHEDULE_CHANGED")
            return false
        }
        guard editor.isValid else {
            editor.statusText = L10n.t(editor.rows.isEmpty ? "MAC_EMPTY_SCHEDULE" : "MAC_INVALID_PARTS")
            return false
        }

        let previous = talks
        let gaps = ScheduleEditing.gapsAfter(previous)
        let firstOffset = previous.first?.startOffsetIntoMeeting ?? 0
        let byId = Dictionary(previous.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
        var nextId = max(ScheduleEditing.firstCustomId, (previous.map { $0.id }.max() ?? 0) + 1)
        let defaultAutoBell = isAutoMode ? (options.isBellEnabled && options.autoBell) : options.autoBell

        var used = Set<Int>()
        var result: [TalkScheduleItem] = []
        for row in editor.rows {
            let item: TalkScheduleItem
            if let id = row.talkId, let existing = byId[id], !used.contains(id) {
                item = existing
            } else {
                item = TalkScheduleItem(id: nextId, name: row.name, sectionInternal: row.sectionInternal,
                                        sectionLocalised: row.sectionLocalised)
                item.autoBell = defaultAutoBell
                nextId += 1
            }
            used.insert(item.id)
            item.name = row.name.trimmingCharacters(in: .whitespaces)
            item.meetingSectionNameInternal = row.sectionInternal
            item.meetingSectionNameLocalised = row.sectionLocalised
            let secs = TimeInterval(row.durationSecs ?? 0)
            if item.originalDuration != secs {
                item.originalDuration = secs
                item.modifiedDuration = nil
                item.adaptedDuration = nil
            }
            item.editable = row.editable
            item.bellApplicable = row.bell
            item.countUp = row.countUp
            item.persistFinalTimerValue = row.persist
            item.closingSecs = row.closingSecs
            item.isStudentTalk = row.isStudentTalk
            item.allowAdaptive = row.allowAdaptive
            result.append(item)
        }
        ScheduleEditing.layOut(result, gaps: gaps, firstOffset: firstOffset)
        schedule.setCustom(result)
        editor.dirty = false
        scheduleWasEdited()
        showSnackbar(L10n.t("MAC_SCHEDULE_APPLIED"))
        return true
    }

    /// Discards the edits of the current schedule.
    func restoreOriginalSchedule(_ editor: ScheduleEditorModel?) {
        guard !isRunning && !isPaused else { return }
        schedule.setCustom(nil)
        refreshSchedule()
        mainWindow?.title = windowTitle
        editor?.load(talks)
        editor?.statusText = L10n.t("MAC_SCHEDULE_RESTORED")
        showSnackbar(L10n.t("MAC_SCHEDULE_RESTORED"))
    }

    /// After an edit: keep the selected part if it still exists.
    private func scheduleWasEdited() {
        let keep = talkId
        cancelDurationEdit()
        talkId = 0
        isPaused = false
        pausedElapsedSecs = 0
        isOvertime = false
        if schedule.item(keep) != nil {
            setTalkId(keep)
        } else {
            selectFirstTalk()
        }
        mainWindow?.title = windowTitle
        objectWillChange.send()
    }

    /// Saves the editor's draft as a schedule XML file (readable by OnlyT on Windows too).
    func exportSchedule(_ editor: ScheduleEditorModel) {
        guard editor.isValid else { return }
        AppFolders.ensure(AppFolders.schedules)
        let panel = NSSavePanel()
        panel.title = L10n.t("MAC_EXPORT_SCHEDULE")
        panel.directoryURL = AppFolders.schedules
        if options.operatingMode == .scheduleFile, let f = options.scheduleFile, !f.isEmpty {
            panel.nameFieldStringValue = f
        } else {
            panel.nameFieldStringValue = L10n.t("MAC_DEFAULT_SCHEDULE_NAME") + ".xml"
        }
        panel.allowedContentTypes = [.xml]
        panel.canCreateDirectories = true
        guard panel.runModal() == .OK, let url = panel.url else { return }

        do {
            try ScheduleXMLWriter.xml(editor.previewItems()).write(to: url, atomically: true, encoding: .utf8)
        } catch {
            editor.statusText = error.localizedDescription
            return
        }
        refreshScheduleFiles()
        let name = url.lastPathComponent
        editor.statusText = L10n.f("MAC_SCHEDULE_SAVED", name)

        let inSchedulesFolder = url.deletingLastPathComponent().standardizedFileURL.path
            == AppFolders.schedules.standardizedFileURL.path
        guard inSchedulesFolder else { return }
        let isCurrentFile = options.operatingMode == .scheduleFile
            && options.scheduleFile?.caseInsensitiveCompare(name) == .orderedSame
        if isCurrentFile && !isRunning && !isPaused {
            // the file being used now holds the edits: use it directly
            useScheduleFile(name)
            editor.load(talks)
            editor.statusText = L10n.f("MAC_SCHEDULE_SAVED", name)
        } else {
            showSnackbar(L10n.f("MAC_SCHEDULE_SAVED", name), actionTitle: L10n.t("MAC_USE_FILE")) { [weak self] in
                self?.useScheduleFile(name)
            }
        }
    }

    /// Switches to file-based mode with the given schedule file.
    func useScheduleFile(_ name: String) {
        guard !isRunning && !isPaused else {
            showSnackbar(L10n.t("MAC_STOP_TIMER_TO_APPLY"))
            return
        }
        if options.scheduleFile != name {
            options.scheduleFile = name
        }
        if options.operatingMode != .scheduleFile {
            options.operatingMode = .scheduleFile
        }
        // the file holds the parts now: forget older edits of the same file
        schedule.setCustom(nil)
        refreshSchedule()
        mainWindow?.title = windowTitle
    }

    private func scheduleFileNotFound() {
        guard options.operatingMode == .scheduleFile else { return }
        options.operatingMode = .manual
        showSnackbar(L10n.t("SCHEDULE_FILE_NOT_FOUND"))
    }

    func refreshScheduleFiles() {
        scheduleFiles = schedule.scheduleFileNames()
    }

    private func shouldRefreshMidWeekSchedule() -> Bool {
        !isRunning && !isPaused && isAutoMode && options.midWeekOrWeekend == .midWeek
            && (talkId == TalkTypesAutoMode.openingComments.rawValue || talkId == 0)
            && !schedule.feedSucceeded
    }

    private func loadFeedAsync() {
        guard !feedLoading, isAutoMode, options.midWeekOrWeekend == .midWeek else { return }
        feedLoading = true
        lastFeedAttempt = Date()
        let url = feedURL
        let cache = AppFolders.feedCache
        let today = dateTime.now()
        DispatchQueue.global(qos: .utility).async { [weak self] in
            let meeting = TimesFeed.load(feedURL: url, cacheURL: cache, today: today)
            DispatchQueue.main.async {
                MainActor.assumeIsolated {
                    self?.feedLoaded(meeting)
                }
            }
        }
    }

    private func feedLoaded(_ meeting: FeedMeeting?) {
        feedLoading = false
        guard let meeting = meeting else { return }
        schedule.feedSucceeded = true
        if meeting != schedule.feedMeeting {
            schedule.feedMeeting = meeting
            if !isRunning && !isPaused && isAutoMode && options.midWeekOrWeekend == .midWeek
                && (talkId == TalkTypesAutoMode.openingComments.rawValue || talkId == 0) {
                refreshSchedule()
            }
        }
    }

    // MARK: heartbeat / reminders / countdown

    private func heartbeat() {
        manageCountdown()
        let now = Date()
        if now.timeIntervalSince(lastScheduleCheck) > 11 {
            lastScheduleCheck = now
            if shouldRefreshMidWeekSchedule() && now.timeIntervalSince(lastFeedAttempt) > 60 {
                loadFeedAsync()
            }
        }
    }

    private func reminderTick() {
        let now = dateTime.now()
        if reminders.shouldSendReminder(now: now, mode: options.operatingMode) {
            reminders.markShown(now)
            if options.timerReminder {
                toasts.showReminder { [weak self] in
                    self?.reminders.reminderClosedManually()
                }
            }
        }
    }

    private func manageCountdown() {
        guard options.canDisplayCountdownWindow, !countdownModel.isCountingDown, !countdownModel.isDone else { return }
        if let offset = CountdownTrigger.secondsIntoCountdown(now: dateTime.now(), startTimes: options.meetingStartTimes,
                                                             countdownMins: options.countdownDurationMins) {
            startCountdown(offsetSeconds: offset)
        }
    }

    private func startCountdown(offsetSeconds: Int) {
        countdownModel.start(offsetSeconds: offsetSeconds)
        guard countdownController.open() else { return }
        isCountdownActive = true
        adaptive.countdownStatusChanged(showing: true)
        meetingStartTimeFromCountdown = nil
        updateMainWindowLevel()
        after(1.0) { [weak self] in
            guard let self = self, self.countdownModel.isCountingDown else { return }
            if self.countdownAndTimerShareSameMonitor() {
                // the countdown replaces the clock on the same monitor
                self.outputController.hide()
            }
        }
    }

    /// Stops the countdown (manually via the operator window, or when it ends).
    func stopCountdown() {
        guard countdownModel.isCountingDown || isCountdownActive else { return }
        countdownModel.markStopped()
        isCountdownActive = false
        adaptive.countdownStatusChanged(showing: false)
        meetingStartTimeFromCountdown = DateUtils.nearestMinute(dateTime.now())
        reminders.countdownClosed(firstTalkId: talks.first?.id, now: dateTime.now())
        if options.canDisplayTimerWindow {
            outputController.show()
        }
        after(1.0) { [weak self] in
            self?.countdownController.close()
            self?.countdownModel.clear()
            self?.updateMainWindowLevel()
        }
    }

    private func countdownAndTimerShareSameMonitor() -> Bool {
        if options.mainMonitorIsWindowed || options.countdownMonitorIsWindowed {
            return false
        }
        return options.timerMonitorId == options.countdownMonitorId
    }

    private func notifyOfBadTimingIfRequired() {
        guard isAutoMode, options.overrunNotifications, let overrun = adaptive.calculateMeetingOverrun(talkId) else { return }
        toasts.showOverrun(overrun)
    }

    // MARK: timing data & reports

    private func isFirstTalk(_ id: Int) -> Bool {
        talks.first?.id == id
    }

    private func previousTalk(_ id: Int) -> TalkScheduleItem? {
        var prev: TalkScheduleItem?
        for t in talks {
            if t.id == id { break }
            prev = t
        }
        return prev
    }

    private func storeTimerStartData() {
        guard isAutoMode, let talk = currentTalk else { return }
        let now = dateTime.now()
        if isFirstTalk(talk.id) {
            if !timing.current.items.isEmpty {
                timing.startNewSession()
            }
            let start = calculateStartOfMeeting()
            timing.insertMeetingStart(start)
            timing.insertPlannedMeetingEnd(start.addingTimeInterval(105 * 60))
            timing.insertSongSegment(start: start, description: L10n.t("INTRO_SEGMENT"), duration: 5 * 60, now: now)
        }
        if talk.id == TalkTypesAutoMode.livingPart1.rawValue || talk.id == TalkTypesAutoMode.watchtower.rawValue {
            let allowForCounsel = previousTalk(talk.id)?.isStudentTalk ?? false
            let interimStart = timing.lastTimerStop.addingTimeInterval(allowForCounsel ? 75 : 15)
            // 3 mins 20 secs planned for the interim song
            timing.insertSongSegment(start: interimStart, description: L10n.t("INTERIM_SEGMENT"), duration: 200, now: now)
        }
        timing.insertTimerStart(description: talk.name, isSongSegment: false, isStudentTalk: talk.isStudentTalk,
                                plannedDuration: talk.originalDuration, adaptedDuration: talk.actualDuration, now: now)
    }

    private func calculateStartOfMeeting() -> Date {
        let estimated = DateUtils.nearestQuarterOfAnHour(dateTime.now())
        guard let fromCountdown = meetingStartTimeFromCountdown else {
            return estimated
        }
        return abs(estimated.timeIntervalSince(fromCountdown)) < 600 ? fromCountdown : estimated
    }

    private func storeTimerStopData() {
        if isAutoMode {
            timing.insertTimerStop(now: dateTime.now())
        }
    }

    private func endOfMeeting() {
        if isAutoMode {
            let songStart = dateTime.now().addingTimeInterval(5)
            let actualEnd = songStart.addingTimeInterval(5 * 60) // a guess!
            timing.insertConcludingSongSegment(start: songStart, end: actualEnd, description: L10n.t("CONCLUDING_SEGMENT"), duration: 5 * 60)
            timing.insertActualMeetingEnd(actualEnd)
        }
        generateTimingReport()
        countdownModel.resetDone()
        adaptive.resetMeetingStart()
    }

    private func generateTimingReport() {
        guard isAutoMode, options.generateTimingReports else {
            timing.startNewSession()
            return
        }
        showSnackbar(L10n.t("ANALYSING_REPORT_DATA"))
        timing.save()

        let valid = timing.validCurrentMeetingTimes()
        let data = timing.current
        let historical = timing.historicalSummaries(upTo: dateTime.now())
        let weekendIncludesFriday = options.weekendIncludesFriday
        let now = dateTime.now()
        timing.startNewSession()

        after(0.5) { [weak self] in
            guard let self = self else { return }
            guard valid, let url = PdfTimingReport.generate(data: data, historical: historical,
                                                            weekendIncludesFriday: weekendIncludesFriday,
                                                            reportsFolder: AppFolders.reports, now: now) else {
                self.showSnackbar(L10n.t("NO_REPORT"))
                return
            }
            self.showSnackbar(L10n.t("GENERATING_REPORT"), actionTitle: L10n.t("VIEW_REPORT")) {
                NSWorkspace.shared.open(url)
            }
        }
    }

    func deleteTimingData() {
        timing.deleteAll()
        showSnackbar(L10n.t("MAC_TIMING_DATA_DELETED"))
    }

    // MARK: snackbar

    func showSnackbar(_ text: String, actionTitle: String? = nil, action: (() -> Void)? = nil) {
        let msg = SnackbarMessage(text: text, actionTitle: actionTitle, action: action)
        snackbar = msg
        let id = msg.id
        after(actionTitle == nil ? 4 : 10) { [weak self] in
            if self?.snackbar?.id == id {
                self?.snackbar = nil
            }
        }
    }

    // MARK: settings window

    func openSettings() {
        guard canOpenSettings else { return }
        if !settingsOpen {
            startTimesDraft = meetingStartTimesText
            apiCodeDraft = options.apiCode ?? ""
        }
        refreshScreens()
        refreshScheduleFiles()
        localIP = NetworkInfo.localIPv4()
        openSettingsHandler?()
    }

    func settingsWindowOpened() {
        settingsOpen = true
        display.settingsOpened(timerActive: isRunning)
    }

    func settingsWindowClosed() {
        settingsOpen = false
        display.settingsClosed(timerActive: isRunning)
        refreshCountUpFlag(currentTalk)
        optionsStore.update(options)
        objectWillChange.send()
    }

    // MARK: options

    private func optionsChanged(from old: Options) {
        let o = options
        optionsBox.value = o
        display.options = o
        countdownModel.options = o
        scheduleSave()

        if o.culture != old.culture {
            L10n.shared.setLanguage(o.culture)
            router.clearPageCache()
            rebuildMenusHandler?()
            if !isRunning && !isPaused {
                refreshSchedule()
            }
        }

        if o.operatingMode != old.operatingMode || o.scheduleFile != old.scheduleFile
            || o.isCircuitVisit != old.isCircuitVisit || o.midWeekOrWeekend != old.midWeekOrWeekend {
            if !isRunning {
                refreshSchedule()
            }
            mainWindow?.title = windowTitle
            if o.operatingMode == .automatic && old.operatingMode != .automatic {
                loadFeedAsync()
            }
        }

        if o.autoBell != old.autoBell {
            for t in talks {
                t.autoBell = o.autoBell
            }
        }

        if o.countUp != old.countUp {
            refreshCountUpFlag(currentTalk)
        }

        if o.midWeekAdaptiveMode != old.midWeekAdaptiveMode || o.weekendAdaptiveMode != old.weekendAdaptiveMode {
            refreshDurations(currentTalk)
        }

        if o.timerMonitorId != old.timerMonitorId || o.mainMonitorIsWindowed != old.mainMonitorIsWindowed {
            if o.canDisplayTimerWindow {
                outputController.open()
            } else {
                outputController.hide()
            }
            if countdownModel.isCountingDown {
                countdownController.window?.orderFrontRegardless()
            }
            updateMainWindowLevel()
        }

        if o.countdownMonitorId != old.countdownMonitorId || o.countdownMonitorIsWindowed != old.countdownMonitorIsWindowed
            || o.isCountdownWindowTransparent != old.isCountdownWindowTransparent {
            if countdownModel.isCountingDown {
                if o.canDisplayCountdownWindow {
                    countdownController.open()
                } else {
                    countdownController.hide()
                }
            }
            updateMainWindowLevel()
        }

        if o.httpServerPort != old.httpServerPort || o.isWebClockEnabled != old.isWebClockEnabled || o.isApiEnabled != old.isApiEnabled {
            restartWebServer()
        }

        if o.alwaysOnTop != old.alwaysOnTop {
            updateMainWindowLevel()
        }

        if o.darkModeToggle != old.darkModeToggle {
            applyAppearance()
        }

        if o.showMousePointerInTimerDisplay != old.showMousePointerInTimerDisplay {
            outputController.updatePointer()
        }

        if o.showPauseButton != old.showPauseButton {
            rebuildMenusHandler?()
        }
    }

    private func scheduleSave() {
        saveToken += 1
        let token = saveToken
        after(0.6) { [weak self] in
            guard let self = self, self.saveToken == token else { return }
            self.optionsStore.update(self.options)
        }
    }

    func setMeetingStartTimesText(_ text: String) {
        let parsed = MeetingStartTimes.parse(text, locale: Locale(identifier: L10n.shared.languageCode))
        if parsed != options.meetingStartTimes {
            options.meetingStartTimes = parsed
        }
    }

    var meetingStartTimesText: String {
        MeetingStartTimes.asText(options.meetingStartTimes, locale: Locale(identifier: L10n.shared.languageCode))
    }

    func generateApiCode() {
        let chars = Array("ABCDEFGHJKLMNPQRSTUVWXYZ23456789")
        options.apiCode = String((0..<6).map { _ in chars.randomElement()! })
        apiCodeDraft = options.apiCode ?? ""
    }

    // MARK: windows & appearance

    func applyAppearance() {
        NSApp.appearance = options.darkModeToggle ? NSAppearance(named: .darkAqua) : nil
    }

    func refreshScreens() {
        screens = Screens.all()
    }

    private func screensChanged() {
        refreshScreens()
        if options.canDisplayTimerWindow && !(countdownModel.isCountingDown && countdownAndTimerShareSameMonitor()) {
            outputController.open()
        }
        if countdownModel.isCountingDown {
            countdownController.open()
        }
        updateMainWindowLevel()
    }

    func updateMainWindowLevel() {
        guard let w = mainWindow else { return }
        let outputScreens = [outputController.screen, countdownController.screen].compactMap { $0 }
        if let s = w.screen, outputScreens.contains(s) {
            // the operator window must stay above a full-screen display on the same monitor
            w.level = NSWindow.Level(rawValue: fullScreenDisplayLevel.rawValue + 3)
        } else if options.alwaysOnTop || outputController.isVisible || countdownController.isVisible {
            w.level = .floating
        } else {
            w.level = .normal
        }
    }

    // MARK: web server

    func restartWebServer() {
        webServer.stop()
        webServerError = nil
        localIP = NetworkInfo.localIPv4()
        if options.isWebClockEnabled || options.isApiEnabled {
            webServer.start(port: options.httpServerPort)
        }
    }

    private func serverFailed(_ message: String) {
        webServerError = L10n.f("MAC_SERVER_ERROR", options.httpServerPort) + " (\(message))"
    }

    // MARK: folders

    func openSchedulesFolder() {
        AppFolders.ensure(AppFolders.schedules)
        NSWorkspace.shared.open(AppFolders.schedules)
    }

    func openReportsFolder() {
        AppFolders.ensure(AppFolders.reports)
        NSWorkspace.shared.open(AppFolders.reports)
    }

    func createSampleSchedule() {
        AppFolders.ensure(AppFolders.schedules)
        guard let src = ResourceLocator.url("sample_talk_schedule.xml") else { return }
        var dest = AppFolders.schedules.appendingPathComponent("Sample.xml")
        var n = 1
        while FileManager.default.fileExists(atPath: dest.path) {
            dest = AppFolders.schedules.appendingPathComponent("Sample \(n).xml")
            n += 1
        }
        try? FileManager.default.copyItem(at: src, to: dest)
        refreshScheduleFiles()
        showSnackbar(L10n.t("MAC_SAMPLE_CREATED"))
        NSWorkspace.shared.activateFileViewerSelecting([dest])
    }

    func openHelp() {
        NSWorkspace.shared.open(AppModel.helpURL)
    }

    // MARK: web API (called on the main thread by WebBridge)

    func webOptionsSnapshot() -> WebOptions {
        WebOptions(isWebClockEnabled: options.isWebClockEnabled, isApiEnabled: options.isApiEnabled,
                   isApiThrottled: options.isApiThrottled, apiCode: options.apiCode)
    }

    func currentTimerStatus() -> TimerStatus {
        var s = engine.status()
        s.isPaused = isPaused
        return s
    }

    func timersJSON(talkId id: Int?) throws -> [String: Any] {
        let all = talks
        let status = currentTimerStatus()
        if let id = id {
            guard let t = all.first(where: { $0.id == id }) else {
                throw WebServerErrorCode.timerDoesNotExist
            }
            return ApiJSON.timersResponse(talks: [t], status: status, countUpByDefault: options.countUp)
        }
        return ApiJSON.timersResponse(talks: all, status: status, countUpByDefault: options.countUp)
    }

    func apiStartStop(talkId id: Int, command: StartStopTimerCommand) throws -> [String: Any] {
        guard schedule.item(id) != nil else {
            throw WebServerErrorCode.timerDoesNotExist
        }
        var success = talkId == id || (!isRunning && command == .start)
        if success {
            if talkId != id {
                setTalkId(id)
            }
            success = talkId == id
            if success {
                switch command {
                case .start:
                    success = !isRunning
                    if success { startTimer() }
                case .stop:
                    success = isRunning
                    if success { stopTimer() }
                case .unknown:
                    break
                }
            }
        }
        var status = currentTimerStatus()
        if success {
            status.isRunning = command == .start
        }
        return ApiJSON.startStopResponse(talkId: id, command: command, success: success, status: status)
    }

    func apiChangeDuration(talkId id: Int, deltaSeconds: Int) throws -> [String: Any] {
        guard let talk = schedule.item(id) else {
            throw WebServerErrorCode.timerDoesNotExist
        }
        guard talk.editable else {
            throw WebServerErrorCode.timerNotEditable
        }
        if isRunning && talkId == id {
            return ApiJSON.durationChangeResponse(talkId: id, deltaSeconds: deltaSeconds, success: false, newDurationSecs: 0)
        }
        let newSecs = min(max(talk.plannedDurationSeconds + deltaSeconds, 0), AppModel.maxTimerSecs)
        adjustTalkTime(talk, targetSecs: newSecs, manualMode: isManualMode)
        return ApiJSON.durationChangeResponse(talkId: id, deltaSeconds: deltaSeconds, success: true, newDurationSecs: newSecs)
    }

    func apiRingBell() -> Bool {
        if bell.isPlaying {
            return false
        }
        bell.play(enabled: options.isBellEnabled, volumePercent: options.bellVolumePercent)
        return true
    }

    /// JSON for the web clock page (/data).
    func clockJSON() -> [String: Any] {
        let now = dateTime.now()
        var d: [String: Any] = [
            "mode": "TimeOfDay", "mins": 0, "secs": 0, "ms": 0, "targetSecs": 0, "closingSecs": 0,
            "countUp": false, "use24Hr": options.use24HourClock, "showSecs": options.webClockShowTimeOfDaySeconds,
            "showPersistBar": false, "persistRemainingMs": 0, "persistTotalMs": 0,
        ]
        if engine.isRunning {
            let elapsed = engine.elapsed
            d["mode"] = "Timer"
            d["mins"] = Int(elapsed / 60)
            d["secs"] = Int(elapsed) % 60
            d["ms"] = Int((elapsed - elapsed.rounded(.down)) * 1000)
            d["targetSecs"] = engine.targetSecs
            d["closingSecs"] = engine.closingSecs
            d["countUp"] = engine.isCountingUp
        } else if now < persistUntil {
            d["mode"] = "Persist"
            d["mins"] = persistElapsedSecs / 60
            d["secs"] = persistElapsedSecs % 60
            d["targetSecs"] = persistTargetSecs
            d["closingSecs"] = persistClosingSecs
            d["countUp"] = persistCountUp
            d["showPersistBar"] = options.showPersistCountdown
            d["persistRemainingMs"] = Int(persistUntil.timeIntervalSince(now) * 1000)
            d["persistTotalMs"] = options.persistDurationSecs * 1000
        } else {
            let c = Calendar.current.dateComponents([.hour, .minute, .second, .nanosecond], from: now)
            d["mins"] = (c.hour ?? 0) * 60 + (c.minute ?? 0)
            d["secs"] = c.second ?? 0
            d["ms"] = (c.nanosecond ?? 0) / 1_000_000
        }
        return d
    }
}

// MARK: - Bridge between the web server (background queue) and the model (main thread)

final class WebBridge: WebHost {
    private final class Box<T> {
        var value: T

        init(_ value: T) {
            self.value = value
        }
    }

    weak var model: AppModel?
    private let sessionId = UUID().uuidString

    init(model: AppModel) {
        self.model = model
    }

    private func onMain(_ block: @escaping @MainActor () -> Void) {
        if Thread.isMainThread {
            MainActor.assumeIsolated {
                block()
            }
        } else {
            DispatchQueue.main.sync {
                MainActor.assumeIsolated {
                    block()
                }
            }
        }
    }

    private func call(_ block: @escaping @MainActor (AppModel) throws -> [String: Any]) throws -> [String: Any] {
        guard let m = model else {
            throw WebServerErrorCode.unknownError
        }
        let box = Box<Result<[String: Any], Error>>(.success([:]))
        onMain {
            box.value = Result { try block(m) }
        }
        return try box.value.get()
    }

    func webOptions() -> WebOptions {
        let box = Box(WebOptions(isWebClockEnabled: false, isApiEnabled: false, isApiThrottled: true, apiCode: nil))
        guard let m = model else { return box.value }
        onMain {
            box.value = m.webOptionsSnapshot()
        }
        return box.value
    }

    func clockData() -> [String: Any] {
        (try? call { m in m.clockJSON() }) ?? [:]
    }

    func timersData(talkId: Int?) throws -> [String: Any] {
        try call { m in try m.timersJSON(talkId: talkId) }
    }

    func startTimer(talkId: Int) throws -> [String: Any] {
        try call { m in try m.apiStartStop(talkId: talkId, command: .start) }
    }

    func stopTimer(talkId: Int) throws -> [String: Any] {
        try call { m in try m.apiStartStop(talkId: talkId, command: .stop) }
    }

    func changeDuration(talkId: Int, deltaSeconds: Int) throws -> [String: Any] {
        try call { m in try m.apiChangeDuration(talkId: talkId, deltaSeconds: deltaSeconds) }
    }

    func ringBell() -> Bool {
        let box = Box(false)
        guard let m = model else { return false }
        onMain {
            box.value = m.apiRingBell()
        }
        return box.value
    }

    func now() -> Date {
        let box = Box(Date())
        guard let m = model else { return box.value }
        onMain {
            box.value = m.dateTime.now()
        }
        return box.value
    }

    func systemData() -> [String: Any] {
        let opts = webOptions()
        let code = L10n.shared.languageCode
        let language = Locale(identifier: code).language
        let iso2 = language.languageCode?.identifier ?? String(code.prefix(2))
        let iso3 = language.languageCode?.identifier(.alpha3) ?? iso2
        var usage = rusage()
        getrusage(RUSAGE_SELF, &usage)
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "2.5.0"
        return [
            "machineName": ProcessInfo.processInfo.hostName,
            "accountName": NSUserName(),
            "onlyTVersion": version,
            "apiVersion": ["lowVersion": WebRouter.oldestSupportedApiVer, "highVersion": WebRouter.currentApiVer],
            "culture": ["name": code, "isoCode2": iso2, "isoCode3": iso3],
            "workingSet": Int(usage.ru_maxrss),
            "sessionId": sessionId,
            "apiEnabled": opts.isApiEnabled,
            "apiThrottled": opts.isApiThrottled,
            "apiCodeRequired": !(opts.apiCode ?? "").isEmpty,
        ]
    }
}
