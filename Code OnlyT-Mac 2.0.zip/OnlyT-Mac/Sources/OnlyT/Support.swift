import AppKit
import AVFoundation
import CoreImage
import SwiftUI
import OnlyTCore

// MARK: - Colours (from the original OnlyT)

enum Palette {
    static let cream = Color(hex: 0xF3DCBC)          // durations / labels
    static let creamDim = Color(hex: 0xBBA991)
    static let chartreuse = Color(hex: 0x7FFF00)     // timer green
    static let timerYellow = Color(hex: 0xFFFF00)
    static let timerRed = Color(hex: 0xFF0000)
    static let beige = Color(hex: 0xF5F5DC)          // panel frames
    static let gradientTop = Color(hex: 0x5D4343)
    static let primary = Color(hex: 0x607D8B)        // Material BlueGrey
    static let primaryDark = Color(hex: 0x455A64)
    static let accent = Color(hex: 0xFFC107)         // Material Amber
    static let bellActive = Color(hex: 0xF3DCBC)
    static let bellInactive = Color(nsColor: .darkGray)
    static let overtimeGreen = Color(hex: 0x2E9E3E)
    static let overtimeRed = Color(hex: 0xE53935)

    static func timer(_ c: TimerColour) -> Color {
        switch c {
        case .white: return .white
        case .green: return chartreuse
        case .yellow: return timerYellow
        case .red: return timerRed
        }
    }
}

extension Color {
    init(hex: UInt32, opacity: Double = 1) {
        self.init(.sRGB,
                  red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255,
                  opacity: opacity)
    }
}

extension NSColor {
    convenience init(hex: UInt32, alpha: CGFloat = 1) {
        self.init(srgbRed: CGFloat((hex >> 16) & 0xFF) / 255,
                  green: CGFloat((hex >> 8) & 0xFF) / 255,
                  blue: CGFloat(hex & 0xFF) / 255,
                  alpha: alpha)
    }
}

// MARK: - Text that fills its frame (like a WPF Viewbox) while staying crisp

struct FittedText: View {
    let text: String
    var baseSize: CGFloat = 40
    var weight: NSFont.Weight = .bold
    var color: Color = .white
    var monospacedDigits = true
    var alignment: Alignment = .center

    private func naturalSize() -> CGSize {
        let font = monospacedDigits
            ? NSFont.monospacedDigitSystemFont(ofSize: baseSize, weight: weight)
            : NSFont.systemFont(ofSize: baseSize, weight: weight)
        let measured: NSString = (text.isEmpty ? " " : text) as NSString
        let s = measured.size(withAttributes: [.font: font])
        return CGSize(width: max(s.width, 1), height: max(s.height, 1))
    }

    var body: some View {
        GeometryReader { geo in
            let natural = naturalSize()
            let scale = max(0.01, min(geo.size.width / natural.width, geo.size.height / natural.height))
            Text(text)
                .font(.system(size: baseSize * scale, weight: swiftUIWeight))
                .monospacedDigit()
                .foregroundColor(color)
                .lineLimit(1)
                .fixedSize()
                .frame(width: geo.size.width, height: geo.size.height, alignment: alignment)
        }
    }

    private var swiftUIWeight: Font.Weight {
        switch weight {
        case .bold: return .bold
        case .semibold: return .semibold
        case .medium: return .medium
        case .light: return .light
        case .heavy: return .heavy
        case .black: return .black
        default: return .regular
        }
    }
}

// MARK: - Screens

struct ScreenInfo: Identifiable, Hashable {
    let id: String
    let name: String
    let isPrimary: Bool
    let frame: CGRect

    var title: String {
        isPrimary ? "\(name) (\(L10n.t("PRIMARY_MONITOR")))" : name
    }
}

@MainActor
enum Screens {
    static func displayId(_ screen: NSScreen) -> String {
        let num = screen.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber
        return "display-\(num?.uint32Value ?? 0)"
    }

    static func all() -> [ScreenInfo] {
        let primary = NSScreen.screens.first
        return NSScreen.screens.map { s in
            ScreenInfo(id: displayId(s) + "|" + s.localizedName,
                       name: s.localizedName,
                       isPrimary: s == primary,
                       frame: s.frame)
        }
    }

    /// Finds the screen for a stored id ("display-<n>|<name>"), falling back to the name.
    static func screen(for storedId: String?) -> NSScreen? {
        guard let stored = storedId, !stored.isEmpty else {
            return nil
        }
        let parts = stored.split(separator: "|", maxSplits: 1).map(String.init)
        let idPart = parts.first ?? ""
        let namePart = parts.count > 1 ? parts[1] : ""
        if let s = NSScreen.screens.first(where: { displayId($0) == idPart }) {
            return s
        }
        if !namePart.isEmpty, let s = NSScreen.screens.first(where: { $0.localizedName == namePart }) {
            return s
        }
        return nil
    }
}

// MARK: - Network helpers

enum NetworkInfo {
    /// First non-loopback IPv4 address (preferring Ethernet/Wi-Fi "en" interfaces).
    static func localIPv4() -> String? {
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&ifaddr) == 0, let first = ifaddr else {
            return nil
        }
        defer { freeifaddrs(ifaddr) }

        var candidates: [(name: String, address: String)] = []
        var ptr: UnsafeMutablePointer<ifaddrs>? = first
        while let p = ptr {
            let flags = Int32(p.pointee.ifa_flags)
            if let addr = p.pointee.ifa_addr, addr.pointee.sa_family == UInt8(AF_INET),
               (flags & IFF_UP) != 0, (flags & IFF_LOOPBACK) == 0 {
                var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                if getnameinfo(addr, socklen_t(addr.pointee.sa_len), &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST) == 0 {
                    let name = String(cString: p.pointee.ifa_name)
                    let address = String(cString: host)
                    if !address.hasPrefix("169.254") {
                        candidates.append((name, address))
                    }
                }
            }
            ptr = p.pointee.ifa_next
        }
        return candidates.first(where: { $0.name.hasPrefix("en") })?.address ?? candidates.first?.address
    }

    static func qrCode(for text: String, size: CGFloat = 220) -> NSImage? {
        guard let filter = CIFilter(name: "CIQRCodeGenerator") else {
            return nil
        }
        filter.setValue(Data(text.utf8), forKey: "inputMessage")
        filter.setValue("M", forKey: "inputCorrectionLevel")
        guard let output = filter.outputImage else {
            return nil
        }
        let scale = max(1, floor(size / output.extent.width))
        let scaled = output.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        let rep = NSCIImageRep(ciImage: scaled)
        let image = NSImage(size: rep.size)
        image.addRepresentation(rep)
        return image
    }
}

// MARK: - Bell

@MainActor
final class BellPlayer: NSObject, AVAudioPlayerDelegate {
    private var player: AVAudioPlayer?
    private(set) var isPlaying = false
    var onStatusChange: ((Bool) -> Void)?

    func play(enabled: Bool, volumePercent: Int) {
        guard enabled, !isPlaying, let url = ResourceLocator.url("bell.mp3") else {
            return
        }
        do {
            let p = try AVAudioPlayer(contentsOf: url)
            p.delegate = self
            p.volume = Float(max(0, min(100, volumePercent))) / 100
            p.prepareToPlay()
            if p.play() {
                player = p
                setPlaying(true)
            }
        } catch {
            NSLog("OnlyT: could not play bell: \(error)")
        }
    }

    private func setPlaying(_ v: Bool) {
        isPlaying = v
        onStatusChange?(v)
    }

    nonisolated func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        DispatchQueue.main.async {
            MainActor.assumeIsolated {
                self.player = nil
                self.setPlaying(false)
            }
        }
    }

    nonisolated func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
        DispatchQueue.main.async {
            MainActor.assumeIsolated {
                self.player = nil
                self.setPlaying(false)
            }
        }
    }
}

// MARK: - Folders

enum AppFolders {
    static var appSupport: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support")
        return base.appendingPathComponent("OnlyT", isDirectory: true)
    }

    static var documents: URL {
        let base = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Documents")
        return base.appendingPathComponent("OnlyT", isDirectory: true)
    }

    static var schedules: URL { documents.appendingPathComponent("TalkSchedules", isDirectory: true) }
    static var reports: URL { documents.appendingPathComponent("TimingReports", isDirectory: true) }
    static var legacySchedule: URL { documents.appendingPathComponent("talk_schedule.xml") }
    static var optionsFile: URL { appSupport.appendingPathComponent("options.json") }
    static var feedCache: URL { appSupport.appendingPathComponent("feed.json") }
    static var timingDatabase: URL { appSupport.appendingPathComponent("TimingData.json") }
    static var customSchedules: URL { appSupport.appendingPathComponent("CustomSchedules.json") }

    static func ensure(_ url: URL) {
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
    }
}

// MARK: - Small helpers

@MainActor
func after(_ seconds: Double, _ block: @escaping @MainActor () -> Void) {
    Task { @MainActor in
        if seconds > 0 {
            try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
        }
        block()
    }
}

/// Repeating timer on the main queue (keeps firing while menus are open).
@MainActor
final class RepeatingTimer {
    private var timer: Timer?

    init(interval: TimeInterval, _ block: @escaping @MainActor () -> Void) {
        let t = Timer(timeInterval: interval, repeats: true) { _ in
            MainActor.assumeIsolated {
                block()
            }
        }
        t.tolerance = interval * 0.1
        RunLoop.main.add(t, forMode: .common)
        timer = t
    }

    func invalidate() {
        timer?.invalidate()
        timer = nil
    }
}
