import AppKit
import SwiftUI
import OnlyTCore

/// One part in the schedule editor (a draft: nothing changes until "Apply").
struct ScheduleDraftRow: Identifiable, Equatable {
    let id: UUID
    /// Id of the existing part, nil for a part added in the editor.
    var talkId: Int?
    var name: String
    var sectionInternal: String
    var sectionLocalised: String
    var durationText: String
    var editable: Bool
    var bell: Bool
    var countUp: Bool?
    var persist: Bool
    var closingSecs: Int
    var isStudentTalk: Bool
    var allowAdaptive: Bool

    var durationSecs: Int? {
        DurationParser.parse(durationText)
    }

    var isValid: Bool {
        durationSecs != nil && !name.trimmingCharacters(in: .whitespaces).isEmpty
    }

    init(talk t: TalkScheduleItem) {
        id = UUID()
        talkId = t.id
        name = t.name
        sectionInternal = t.meetingSectionNameInternal
        sectionLocalised = t.meetingSectionNameLocalised
        durationText = TimeFormatter.formatTimer(Int(t.originalDuration))
        editable = t.editable
        bell = t.bellApplicable
        countUp = t.countUp
        persist = t.persistFinalTimerValue
        closingSecs = t.closingSecs
        isStudentTalk = t.isStudentTalk
        allowAdaptive = t.allowAdaptive
    }

    /// A new part, optionally in the same section as `near`.
    init(newPartNear near: ScheduleDraftRow?, isAutoMode: Bool) {
        id = UUID()
        talkId = nil
        name = L10n.t("MAC_NEW_PART")
        sectionInternal = near?.sectionInternal ?? ""
        sectionLocalised = near?.sectionLocalised ?? ""
        durationText = "05:00"
        editable = true
        bell = false
        countUp = nil
        persist = false
        closingSecs = TalkScheduleItem.defaultClosingSecs
        isStudentTalk = false
        allowAdaptive = near?.allowAdaptive ?? isAutoMode
    }

    /// Copy of a part, as a new part.
    func duplicated() -> ScheduleDraftRow {
        ScheduleDraftRow(copying: self)
    }

    private init(copying other: ScheduleDraftRow) {
        id = UUID()
        talkId = nil
        name = other.name
        sectionInternal = other.sectionInternal
        sectionLocalised = other.sectionLocalised
        durationText = other.durationText
        editable = other.editable
        bell = other.bell
        countUp = other.countUp
        persist = other.persist
        closingSecs = other.closingSecs
        isStudentTalk = other.isStudentTalk
        allowAdaptive = other.allowAdaptive
    }
}

/// State of the schedule editor window.
@MainActor
final class ScheduleEditorModel: ObservableObject {
    struct Section: Hashable {
        let internalName: String
        let localisedName: String
    }

    @Published var rows: [ScheduleDraftRow] = []
    @Published var selection: UUID?
    @Published var dirty = false
    @Published var statusText = ""

    let title: String
    let isAutoMode: Bool
    /// The schedule context the draft belongs to (see TalkScheduleService.contextKey).
    let contextKey: String
    var onClose: (() -> Void)?

    init(talks: [TalkScheduleItem], title: String, isAutoMode: Bool, contextKey: String) {
        self.title = title
        self.isAutoMode = isAutoMode
        self.contextKey = contextKey
        load(talks)
    }

    func load(_ talks: [TalkScheduleItem]) {
        rows = talks.map { ScheduleDraftRow(talk: $0) }
        selection = rows.first?.id
        dirty = false
    }

    // MARK: queries

    var isValid: Bool {
        !rows.isEmpty && rows.allSatisfy { $0.isValid }
    }

    var sections: [Section] {
        var seen = Set<String>()
        var result: [Section] = []
        for r in rows where !r.sectionLocalised.isEmpty {
            if seen.insert(r.sectionLocalised).inserted {
                result.append(Section(internalName: r.sectionInternal, localisedName: r.sectionLocalised))
            }
        }
        return result
    }

    var totalText: String {
        let total = rows.compactMap { $0.durationSecs }.reduce(0, +)
        let t = total >= 3600
            ? String(format: "%d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60)
            : TimeFormatter.formatTimer(total)
        return L10n.f("MAC_TOTAL", t)
    }

    func row(_ id: UUID) -> ScheduleDraftRow? {
        rows.first { $0.id == id }
    }

    private var selectedIndex: Int? {
        guard let s = selection else { return nil }
        return rows.firstIndex { $0.id == s }
    }

    // MARK: editing

    /// Binding to a field of a row (looked up by id, so deleting rows is always safe).
    func binding<T>(_ id: UUID, _ keyPath: WritableKeyPath<ScheduleDraftRow, T>, _ fallback: T) -> Binding<T> {
        Binding(
            get: { [weak self] in
                self?.row(id)?[keyPath: keyPath] ?? fallback
            },
            set: { [weak self] value in
                guard let self = self, let i = self.rows.firstIndex(where: { $0.id == id }) else { return }
                self.rows[i][keyPath: keyPath] = value
                self.dirty = true
            })
    }

    /// The section is typed freely; picking an existing name keeps its internal id.
    func sectionBinding(_ id: UUID) -> Binding<String> {
        Binding(
            get: { [weak self] in
                self?.row(id)?.sectionLocalised ?? ""
            },
            set: { [weak self] value in
                guard let self = self else { return }
                let internalName = self.sections.first { $0.localisedName == value }?.internalName ?? value
                self.setSection(id, Section(internalName: internalName, localisedName: value))
            })
    }

    func setSection(_ id: UUID, _ section: Section) {
        guard let i = rows.firstIndex(where: { $0.id == id }) else { return }
        rows[i].sectionInternal = section.internalName
        rows[i].sectionLocalised = section.localisedName
        dirty = true
    }

    /// 0 = as in the settings, 1 = counts up, 2 = counts down.
    func countBinding(_ id: UUID) -> Binding<Int> {
        Binding(
            get: { [weak self] in
                guard let up = self?.row(id)?.countUp else { return 0 }
                return up ? 1 : 2
            },
            set: { [weak self] value in
                guard let self = self, let i = self.rows.firstIndex(where: { $0.id == id }) else { return }
                self.rows[i].countUp = value == 0 ? nil : (value == 1)
                self.dirty = true
            })
    }

    func adjustDuration(_ id: UUID, by seconds: Int) {
        guard let i = rows.firstIndex(where: { $0.id == id }) else { return }
        let current = rows[i].durationSecs ?? 0
        let secs = min(max(current + seconds, 0), 99 * 60)
        rows[i].durationText = TimeFormatter.formatTimer(secs)
        dirty = true
    }

    func addPart() {
        let near = selectedIndex.map { rows[$0] } ?? rows.last
        let row = ScheduleDraftRow(newPartNear: near, isAutoMode: isAutoMode)
        if let i = selectedIndex {
            rows.insert(row, at: i + 1)
        } else {
            rows.append(row)
        }
        selection = row.id
        dirty = true
    }

    func duplicateSelected() {
        guard let i = selectedIndex else { return }
        let copy = rows[i].duplicated()
        rows.insert(copy, at: i + 1)
        selection = copy.id
        dirty = true
    }

    func deleteSelected() {
        guard let i = selectedIndex else { return }
        rows.remove(at: i)
        if rows.isEmpty {
            selection = nil
        } else {
            selection = rows[min(i, rows.count - 1)].id
        }
        dirty = true
    }

    var canMoveUp: Bool {
        (selectedIndex ?? 0) > 0
    }

    var canMoveDown: Bool {
        guard let i = selectedIndex else { return false }
        return i < rows.count - 1
    }

    func moveSelected(by delta: Int) {
        guard let i = selectedIndex else { return }
        let j = i + delta
        guard j >= 0 && j < rows.count else { return }
        rows.swapAt(i, j)
        dirty = true
    }

    /// Drag & drop in the list.
    func move(from source: IndexSet, to destination: Int) {
        rows.move(fromOffsets: source, toOffset: destination)
        dirty = true
    }

    /// Parts built from the draft (for the XML export).
    func previewItems() -> [TalkScheduleItem] {
        rows.enumerated().map { pair -> TalkScheduleItem in
            let n = pair.offset
            let r = pair.element
            let t = TalkScheduleItem(id: TalkScheduleFileBased.startId + n, name: r.name,
                                     sectionInternal: r.sectionInternal, sectionLocalised: r.sectionLocalised)
            t.originalDuration = TimeInterval(r.durationSecs ?? 0)
            t.editable = r.editable
            t.bellApplicable = r.bell
            t.countUp = r.countUp
            t.persistFinalTimerValue = r.persist
            t.closingSecs = r.closingSecs
            t.isStudentTalk = r.isStudentTalk
            t.allowAdaptive = r.allowAdaptive
            return t
        }
    }
}

// MARK: - View

@MainActor
struct ScheduleEditorView: View {
    @ObservedObject var model: AppModel
    @ObservedObject var editor: ScheduleEditorModel

    var body: some View {
        VStack(spacing: 0) {
            header
            Divider()
            HStack(spacing: 0) {
                partsList
                    .frame(width: 330)
                Divider()
                detail
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            Divider()
            footer
        }
        .frame(minWidth: 760, minHeight: 500)
    }

    // MARK: header

    private var header: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(editor.title)
                .font(.system(size: 15, weight: .semibold))
            Text(L10n.t("MAC_EDITOR_NOTE"))
                .font(.system(size: 11))
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
    }

    // MARK: list

    private var partsList: some View {
        VStack(spacing: 0) {
            List(selection: $editor.selection) {
                ForEach(editor.rows) { row in
                    rowView(row)
                        .tag(row.id)
                }
                .onMove { source, destination in
                    editor.move(from: source, to: destination)
                }
            }
            .listStyle(.inset(alternatesRowBackgrounds: true))

            Divider()
            HStack(spacing: 2) {
                toolButton("plus", L10n.t("MAC_ADD_PART"), enabled: true) { editor.addPart() }
                toolButton("plus.square.on.square", L10n.t("MAC_DUPLICATE_PART"), enabled: editor.selection != nil) {
                    editor.duplicateSelected()
                }
                toolButton("minus", L10n.t("MAC_DELETE_PART"), enabled: editor.selection != nil) { editor.deleteSelected() }
                Divider().frame(height: 16).padding(.horizontal, 4)
                toolButton("arrow.up", L10n.t("MAC_MOVE_UP"), enabled: editor.canMoveUp) { editor.moveSelected(by: -1) }
                toolButton("arrow.down", L10n.t("MAC_MOVE_DOWN"), enabled: editor.canMoveDown) { editor.moveSelected(by: 1) }
                Spacer(minLength: 0)
                Text(editor.totalText)
                    .font(.system(size: 11))
                    .monospacedDigit()
                    .foregroundColor(.secondary)
                    .padding(.trailing, 6)
            }
            .padding(.horizontal, 6)
            .frame(height: 30)
        }
    }

    private func rowView(_ row: ScheduleDraftRow) -> some View {
        HStack(spacing: 8) {
            Image(systemName: "line.3.horizontal")
                .font(.system(size: 10))
                .foregroundColor(.secondary)
            Text(row.durationSecs.map { TimeFormatter.formatTimer($0) } ?? row.durationText)
                .monospacedDigit()
                .foregroundColor(row.durationSecs == nil ? Color.red : Color.secondary)
                .frame(width: 46, alignment: .leading)
            VStack(alignment: .leading, spacing: 1) {
                Text(row.name.isEmpty ? "—" : row.name)
                    .lineLimit(1)
                if !row.sectionLocalised.isEmpty {
                    Text(row.sectionLocalised)
                        .font(.system(size: 10))
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
            }
            Spacer(minLength: 0)
            if row.bell {
                Image(systemName: "bell.fill")
                    .font(.system(size: 10))
                    .foregroundColor(.secondary)
            }
        }
        .padding(.vertical, 2)
    }

    private func toolButton(_ symbol: String, _ tip: String, enabled: Bool, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 13, weight: .medium))
                .frame(width: 26, height: 22)
        }
        .buttonStyle(.borderless)
        .disabled(!enabled)
        .help(tip)
    }

    // MARK: detail

    @ViewBuilder
    private var detail: some View {
        if let id = editor.selection, let row = editor.row(id) {
            Form {
                Section {
                    TextField(L10n.t("MAC_PART_NAME"), text: editor.binding(id, \.name, ""))
                    HStack(spacing: 6) {
                        TextField(L10n.t("MAC_PART_SECTION"), text: editor.sectionBinding(id))
                        Menu {
                            Button(L10n.t("MAC_NO_SECTION")) {
                                editor.setSection(id, ScheduleEditorModel.Section(internalName: "", localisedName: ""))
                            }
                            ForEach(editor.sections, id: \.self) { s in
                                Button(s.localisedName) {
                                    editor.setSection(id, s)
                                }
                            }
                        } label: {
                            Image(systemName: "list.bullet")
                        }
                        .menuStyle(.borderlessButton)
                        .fixedSize()
                        .help(L10n.t("MAC_SECTIONS"))
                    }
                    HStack(spacing: 6) {
                        TextField(L10n.t("MAC_PART_DURATION"), text: editor.binding(id, \.durationText, ""))
                            .monospacedDigit()
                        Stepper("", onIncrement: { editor.adjustDuration(id, by: 60) },
                                onDecrement: { editor.adjustDuration(id, by: -60) })
                            .labelsHidden()
                            .help(L10n.t("MAC_ADD_MINUTE") + " / " + L10n.t("MAC_REMOVE_MINUTE"))
                    }
                    if row.durationSecs == nil {
                        Text(L10n.t("MAC_INVALID_DURATION"))
                            .font(.system(size: 11))
                            .foregroundColor(.red)
                    }
                }

                Section {
                    Picker(L10n.t("MAC_PART_COUNT"), selection: editor.countBinding(id)) {
                        Text(L10n.t("MAC_COUNT_DEFAULT")).tag(0)
                        Text(L10n.t("MAC_COUNT_UP")).tag(1)
                        Text(L10n.t("MAC_COUNT_DOWN")).tag(2)
                    }
                    Stepper(L10n.f("MAC_PART_CLOSING", row.closingSecs),
                            value: editor.binding(id, \.closingSecs, TalkScheduleItem.defaultClosingSecs),
                            in: 0...600, step: 5)
                    Toggle(L10n.t("MAC_PART_EDITABLE"), isOn: editor.binding(id, \.editable, true))
                    Toggle(L10n.t("MAC_PART_BELL"), isOn: editor.binding(id, \.bell, false))
                    Toggle(L10n.t("MAC_PART_PERSIST"), isOn: editor.binding(id, \.persist, false))
                    Toggle(L10n.t("MAC_PART_STUDENT"), isOn: editor.binding(id, \.isStudentTalk, false))
                    if editor.isAutoMode {
                        Toggle(L10n.t("MAC_PART_ADAPTIVE"), isOn: editor.binding(id, \.allowAdaptive, false))
                    }
                }
            }
            .formStyle(.grouped)
        } else {
            Text(L10n.t("MAC_SELECT_PART_HINT"))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(30)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }

    // MARK: footer

    private var footer: some View {
        HStack(spacing: 10) {
            if model.isScheduleCustomised {
                Button(L10n.t("MAC_RESET_SCHEDULE")) {
                    if confirm(L10n.t("MAC_RESET_SCHEDULE_CONFIRM"), button: L10n.t("MAC_RESET_SCHEDULE")) {
                        model.restoreOriginalSchedule(editor)
                    }
                }
                .disabled(model.isRunning || model.isPaused)
            }
            Button(L10n.t("MAC_EXPORT_SCHEDULE")) {
                model.exportSchedule(editor)
            }
            .disabled(!editor.isValid)

            if !editor.statusText.isEmpty {
                Text(editor.statusText)
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
                    .lineLimit(2)
            }
            Spacer(minLength: 8)

            if model.isRunning || model.isPaused {
                Text(L10n.t("MAC_STOP_TIMER_TO_APPLY"))
                    .font(.system(size: 11))
                    .foregroundColor(.orange)
            } else if !editor.isValid {
                Text(L10n.t(editor.rows.isEmpty ? "MAC_EMPTY_SCHEDULE" : "MAC_INVALID_PARTS"))
                    .font(.system(size: 11))
                    .foregroundColor(.red)
            }
            Button(L10n.t("MAC_CANCEL")) {
                editor.dirty = false
                editor.onClose?()
            }
            Button(L10n.t("MAC_APPLY")) {
                if model.applyScheduleEdit(editor) {
                    editor.onClose?()
                }
            }
            .disabled(!editor.isValid || !editor.dirty || model.isRunning || model.isPaused)
        }
        .padding(12)
    }
}

/// Simple confirmation dialog.
@MainActor
func confirm(_ message: String, button: String) -> Bool {
    let alert = NSAlert()
    alert.messageText = message
    alert.alertStyle = .warning
    alert.addButton(withTitle: button)
    alert.addButton(withTitle: L10n.t("MAC_CANCEL"))
    return alert.runModal() == .alertFirstButtonReturn
}
