import AppKit
import SwiftUI
import OnlyTCore

/// Small floating notifications (port of the ToastNotifications used by OnlyT
/// for timer reminders and overrun/underrun notifications).
@MainActor
final class ToastCenter {
    enum Corner {
        case bottomRight
        case topRight
    }

    private final class Toast {
        let panel: NSPanel
        let corner: Corner
        var token: Int

        init(panel: NSPanel, corner: Corner, token: Int) {
            self.panel = panel
            self.corner = corner
            self.token = token
        }
    }

    private var toasts: [Toast] = []
    private var nextToken = 0
    private let lifetime: TimeInterval = 10
    private let maxCount = 2

    /// "Should you have started the timer?"
    func showReminder(onClose: @escaping () -> Void) {
        nextToken += 1
        let token = nextToken
        let view = ReminderToastView(message: L10n.t("TIMER_REMINDER_MSG")) { [weak self] in
            onClose()
            self?.dismiss(token)
        }
        show(view, width: 300, height: 74, corner: .bottomRight, token: token)
    }

    func showOverrun(_ overrun: TimeInterval) {
        let absMins = Int(abs((overrun / 60).rounded()))
        let isOverrun = overrun < 0
        let msg = isOverrun ? L10n.f("OVERRUN_MSG", absMins) : L10n.f("UNDERRUN_MSG", absMins)
        nextToken += 1
        show(OverrunToastView(message: msg, isOverrun: isOverrun, mins: absMins),
             width: 240, height: 70, corner: .topRight, token: nextToken)
    }

    func clearAll() {
        for t in toasts {
            t.panel.orderOut(nil)
        }
        toasts.removeAll()
    }

    private func show<V: View>(_ view: V, width: CGFloat, height: CGFloat, corner: Corner, token: Int) {
        let existing = toasts.filter { $0.corner == corner }
        if existing.count >= maxCount, let oldest = existing.first {
            dismiss(oldest.token)
        }

        let panel = NSPanel(contentRect: NSRect(x: 0, y: 0, width: width, height: height),
                            styleMask: [.borderless, .nonactivatingPanel],
                            backing: .buffered, defer: false)
        panel.isFloatingPanel = true
        panel.level = NSWindow.Level(rawValue: fullScreenDisplayLevel.rawValue + 2)
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary]
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = true
        panel.hidesOnDeactivate = false
        panel.isReleasedWhenClosed = false
        panel.contentView = unconstrainedHostingView(view.frame(width: width, height: height))

        toasts.append(Toast(panel: panel, corner: corner, token: token))
        layout()
        panel.alphaValue = 0
        panel.orderFrontRegardless()
        NSAnimationContext.runAnimationGroup { ctx in
            ctx.duration = 0.25
            panel.animator().alphaValue = 1
        }

        after(lifetime) { [weak self] in
            self?.dismiss(token)
        }
    }

    private func dismiss(_ token: Int) {
        guard let index = toasts.firstIndex(where: { $0.token == token }) else {
            return
        }
        let t = toasts.remove(at: index)
        NSAnimationContext.runAnimationGroup { ctx in
            ctx.duration = 0.25
            t.panel.animator().alphaValue = 0
        }
        after(0.3) {
            t.panel.orderOut(nil)
        }
        layout()
    }

    private func layout() {
        guard let screen = NSScreen.screens.first else {
            return
        }
        let visible = screen.visibleFrame
        let margin: CGFloat = 20
        var bottomY = visible.minY + margin
        var topY = visible.maxY - margin
        for t in toasts.reversed() {
            let size = t.panel.frame.size
            let x = visible.maxX - margin - size.width
            switch t.corner {
            case .bottomRight:
                t.panel.setFrameOrigin(NSPoint(x: x, y: bottomY))
                bottomY += size.height + 8
            case .topRight:
                t.panel.setFrameOrigin(NSPoint(x: x, y: topY - size.height))
                topY -= size.height + 8
            }
        }
    }
}

private struct ReminderToastView: View {
    let message: String
    let onClose: () -> Void

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 22))
                .foregroundColor(.white)
            Text(message)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.white)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
            Button(action: onClose) {
                Image(systemName: "xmark")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(.white.opacity(0.9))
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 14)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(RoundedRectangle(cornerRadius: 10, style: .continuous).fill(Color(hex: 0xE68A00)))
    }
}

private struct OverrunToastView: View {
    let message: String
    let isOverrun: Bool
    let mins: Int

    var body: some View {
        let bg = isOverrun ? Color(hex: 0xC62828) : Color(hex: 0x2E7D32)
        HStack(spacing: 10) {
            ZStack {
                Circle().fill(Color.white)
                Circle().stroke(Color.black, lineWidth: 1)
                Text("\(mins)")
                    .font(.system(size: 18, weight: .heavy))
                    .foregroundColor(bg)
            }
            .frame(width: 40, height: 40)
            Text(message)
                .font(.system(size: 13, weight: .light))
                .foregroundColor(.white)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 10)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(RoundedRectangle(cornerRadius: 10, style: .continuous).fill(bg))
    }
}
