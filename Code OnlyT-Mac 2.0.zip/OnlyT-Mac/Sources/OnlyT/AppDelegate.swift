import AppKit
import SwiftUI
import OnlyTCore

/// Operator window: can "shrink" to a compact size instead of minimising
/// (the "Shrink on minimise" option of the original).
final class MainWindow: NSWindow {
    var shouldShrinkInsteadOfMinimise: () -> Bool = { false }
    var onShrinkRequest: () -> Void = {}

    override func miniaturize(_ sender: Any?) {
        if shouldShrinkInsteadOfMinimise() {
            onShrinkRequest()
        } else {
            super.miniaturize(sender)
        }
    }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate {
    private var model: AppModel!
    private var mainWindow: MainWindow!
    private var settingsWindow: NSWindow?
    private var editorWindow: NSWindow?
    private var scheduleEditor: ScheduleEditorModel?
    private var normalFrame: NSRect?

    static let defaultSize = NSSize(width: 395, height: 350)
    /// Below this content size the compact ("shrunk") layout is used. The height
    /// is the minimum the full operator layout needs (12+30+10+90+10+54+10+40+12).
    static let minNormalSize = NSSize(width: 250, height: 268)
    static let shrunkSize = NSSize(width: 143, height: 118)

    func applicationDidFinishLaunching(_ notification: Notification) {
        model = AppModel()

        let w = MainWindow(contentRect: NSRect(origin: .zero, size: AppDelegate.defaultSize),
                           styleMask: [.titled, .closable, .miniaturizable, .resizable],
                           backing: .buffered, defer: false)
        w.title = model.windowTitle
        w.isReleasedWhenClosed = false
        w.contentMinSize = AppDelegate.shrunkSize
        w.delegate = self
        // no SwiftUI size constraints: the window must be able to shrink to the compact layout
        w.contentView = unconstrainedHostingView(OperatorView(model: model))
        w.setFrameAutosaveName("OnlyTOperatorWindow")
        if !w.setFrameUsingName("OnlyTOperatorWindow") {
            w.center()
        }
        w.collectionBehavior = [.fullScreenNone]
        w.shouldShrinkInsteadOfMinimise = { [weak self] in
            self?.model.options.shrinkOnMinimise ?? false
        }
        w.onShrinkRequest = { [weak self] in
            self?.shrink()
        }
        mainWindow = w

        model.mainWindow = w
        model.openSettingsHandler = { [weak self] in self?.showSettings() }
        model.rebuildMenusHandler = { [weak self] in self?.buildMenus() }
        model.expandHandler = { [weak self] in self?.expand() }
        model.shrinkHandler = { [weak self] in self?.shrink() }
        model.openScheduleEditorHandler = { [weak self] in self?.showScheduleEditor() }

        buildMenus()
        updateShrunkState()
        w.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        model.start()
    }

    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        if model?.isRunning == true {
            model.showSnackbar(L10n.t("MAC_CANNOT_QUIT_RUNNING"))
            NSSound.beep()
            return .terminateCancel
        }
        model?.shutdown()
        return .terminateNow
    }

    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        mainWindow?.makeKeyAndOrderFront(nil)
        return true
    }

    // MARK: window delegate

    func windowShouldClose(_ sender: NSWindow) -> Bool {
        if sender === mainWindow {
            // closing the operator window quits the app (as in the original)
            NSApp.terminate(nil)
            return false
        }
        if sender === editorWindow, let editor = scheduleEditor, editor.dirty {
            let alert = NSAlert()
            alert.messageText = L10n.t("MAC_UNSAVED_TITLE")
            alert.addButton(withTitle: L10n.t("MAC_APPLY"))
            alert.addButton(withTitle: L10n.t("MAC_DONT_APPLY"))
            alert.addButton(withTitle: L10n.t("MAC_CANCEL"))
            switch alert.runModal() {
            case .alertFirstButtonReturn:
                return model.applyScheduleEdit(editor)
            case .alertSecondButtonReturn:
                return true
            default:
                return false
            }
        }
        return true
    }

    func windowWillClose(_ notification: Notification) {
        if let w = notification.object as? NSWindow, w === settingsWindow {
            model.settingsWindowClosed()
        }
        if let w = notification.object as? NSWindow, w === editorWindow {
            scheduleEditor = nil
        }
    }

    func windowDidResize(_ notification: Notification) {
        if let w = notification.object as? NSWindow, w === mainWindow {
            updateShrunkState()
        }
    }

    func windowDidChangeScreen(_ notification: Notification) {
        if let w = notification.object as? NSWindow, w === mainWindow {
            model.updateMainWindowLevel()
        }
    }

    private func updateShrunkState() {
        guard let w = mainWindow else { return }
        let size = w.contentLayoutRect.size
        let shrunk = size.height < AppDelegate.minNormalSize.height || size.width < AppDelegate.minNormalSize.width
        if model.isShrunk != shrunk {
            model.isShrunk = shrunk
        }
    }

    // MARK: shrink / expand

    private func shrink() {
        guard let w = mainWindow, !model.isShrunk else { return }
        normalFrame = w.frame
        var frame = w.frameRect(forContentRect: NSRect(origin: .zero, size: AppDelegate.shrunkSize))
        frame.origin = NSPoint(x: w.frame.maxX - frame.width, y: w.frame.maxY - frame.height)
        w.setFrame(frame, display: true, animate: true)
    }

    private func expand() {
        guard let w = mainWindow else { return }
        var frame = normalFrame ?? w.frameRect(forContentRect: NSRect(origin: .zero, size: AppDelegate.defaultSize))
        if normalFrame == nil {
            frame.origin = NSPoint(x: w.frame.maxX - frame.width, y: w.frame.maxY - frame.height)
        }
        w.setFrame(frame, display: true, animate: true)
    }

    // MARK: settings window

    private func showSettings() {
        if settingsWindow == nil {
            let sw = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 560, height: 680),
                              styleMask: [.titled, .closable, .resizable, .miniaturizable],
                              backing: .buffered, defer: false)
            sw.isReleasedWhenClosed = false
            sw.delegate = self
            let settingsHost = NSHostingView(rootView: SettingsView(model: model))
            settingsHost.sizingOptions = [.minSize]
            sw.contentView = settingsHost
            sw.setFrameAutosaveName("OnlyTSettingsWindow")
            if !sw.setFrameUsingName("OnlyTSettingsWindow") {
                sw.center()
            }
            settingsWindow = sw
        }
        guard let sw = settingsWindow else { return }
        sw.title = L10n.t("SETTINGS")
        sw.level = mainWindow.level
        if !sw.isVisible {
            model.settingsWindowOpened()
        }
        sw.makeKeyAndOrderFront(nil)
    }

    // MARK: schedule editor window

    private func showScheduleEditor() {
        if let w = editorWindow, w.isVisible, scheduleEditor != nil {
            w.makeKeyAndOrderFront(nil)
            return
        }
        // a fresh draft of the current schedule each time the editor opens
        let editor = model.makeScheduleEditor()
        editor.onClose = { [weak self] in
            self?.editorWindow?.close()
        }
        scheduleEditor = editor

        let host = NSHostingView(rootView: ScheduleEditorView(model: model, editor: editor))
        host.sizingOptions = [.minSize]

        let w: NSWindow
        if let existing = editorWindow {
            w = existing
        } else {
            w = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 860, height: 620),
                         styleMask: [.titled, .closable, .resizable, .miniaturizable],
                         backing: .buffered, defer: false)
            w.isReleasedWhenClosed = false
            w.delegate = self
            w.setFrameAutosaveName("OnlyTScheduleEditor")
            if !w.setFrameUsingName("OnlyTScheduleEditor") {
                w.center()
            }
            editorWindow = w
        }
        w.contentView = host
        w.title = L10n.t("MAC_SCHEDULE_EDITOR_TITLE")
        w.level = mainWindow.level
        w.makeKeyAndOrderFront(nil)
    }

    // MARK: menus

    func buildMenus() {
        let main = NSMenu()

        // application menu
        let appItem = NSMenuItem()
        let appMenu = NSMenu()
        appMenu.addItem(withTitle: L10n.t("MAC_ABOUT"), action: #selector(NSApplication.orderFrontStandardAboutPanel(_:)), keyEquivalent: "")
        appMenu.addItem(.separator())
        appMenu.addItem(item(L10n.t("SETTINGS") + "…", #selector(menuSettings), ","))
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: L10n.t("MAC_HIDE"), action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        let hideOthers = NSMenuItem(title: L10n.t("MAC_HIDE_OTHERS"), action: #selector(NSApplication.hideOtherApplications(_:)), keyEquivalent: "h")
        hideOthers.keyEquivalentModifierMask = [.command, .option]
        appMenu.addItem(hideOthers)
        appMenu.addItem(withTitle: L10n.t("MAC_SHOW_ALL"), action: #selector(NSApplication.unhideAllApplications(_:)), keyEquivalent: "")
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: L10n.t("MAC_QUIT"), action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        appItem.submenu = appMenu
        main.addItem(appItem)

        // edit menu (for text fields)
        let editItem = NSMenuItem()
        let editMenu = NSMenu(title: L10n.t("MAC_EDIT"))
        editMenu.addItem(withTitle: L10n.t("MAC_UNDO"), action: Selector(("undo:")), keyEquivalent: "z")
        let redo = NSMenuItem(title: L10n.t("MAC_REDO"), action: Selector(("redo:")), keyEquivalent: "z")
        redo.keyEquivalentModifierMask = [.command, .shift]
        editMenu.addItem(redo)
        editMenu.addItem(.separator())
        editMenu.addItem(withTitle: L10n.t("MAC_CUT"), action: #selector(NSText.cut(_:)), keyEquivalent: "x")
        editMenu.addItem(withTitle: L10n.t("MAC_COPY"), action: #selector(NSText.copy(_:)), keyEquivalent: "c")
        editMenu.addItem(withTitle: L10n.t("MAC_PASTE"), action: #selector(NSText.paste(_:)), keyEquivalent: "v")
        editMenu.addItem(withTitle: L10n.t("MAC_SELECT_ALL"), action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")
        editItem.submenu = editMenu
        main.addItem(editItem)

        // timer menu
        let timerItem = NSMenuItem()
        let timerMenu = NSMenu(title: L10n.t("MAC_TIMER_MENU"))
        timerMenu.addItem(item(L10n.t("MAC_START_STOP"), #selector(menuStartStop), "\r"))
        if model.options.showPauseButton {
            timerMenu.addItem(item(L10n.t("PAUSE_TIMER"), #selector(menuPause), "p"))
        }
        timerMenu.addItem(.separator())
        timerMenu.addItem(item(L10n.t("MAC_PREV_TALK"), #selector(menuPrevTalk), "["))
        timerMenu.addItem(item(L10n.t("MAC_NEXT_TALK"), #selector(menuNextTalk), "]"))
        timerMenu.addItem(.separator())
        timerMenu.addItem(item(L10n.t("MAC_ADD_MINUTE"), #selector(menuAddMinute), "="))
        timerMenu.addItem(item(L10n.t("MAC_REMOVE_MINUTE"), #selector(menuRemoveMinute), "-"))
        timerMenu.addItem(item(L10n.t("EDIT_DURATION"), #selector(menuEditDuration), "e"))
        let editSchedule = item(L10n.t("MAC_EDIT_SCHEDULE"), #selector(menuEditSchedule), "e")
        editSchedule.keyEquivalentModifierMask = [.command, .option]
        timerMenu.addItem(editSchedule)
        timerMenu.addItem(.separator())
        timerMenu.addItem(item(L10n.t("SOUND_BELL"), #selector(menuBell), "b"))
        timerItem.submenu = timerMenu
        main.addItem(timerItem)

        // window menu
        let windowItem = NSMenuItem()
        let windowMenu = NSMenu(title: L10n.t("MAC_WINDOW"))
        windowMenu.addItem(withTitle: L10n.t("MAC_MINIMIZE"), action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
        windowMenu.addItem(item(L10n.t("MAC_COMPACT"), #selector(menuCompact), "k"))
        windowMenu.addItem(withTitle: L10n.t("MAC_CLOSE_WINDOW"), action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w")
        windowMenu.addItem(.separator())
        windowMenu.addItem(item(L10n.t("MAC_OPERATOR_WINDOW"), #selector(menuShowOperator), "1"))
        windowItem.submenu = windowMenu
        main.addItem(windowItem)
        NSApp.windowsMenu = windowMenu

        // help menu
        let helpItem = NSMenuItem()
        let helpMenu = NSMenu(title: L10n.t("HELP"))
        helpMenu.addItem(item(L10n.t("HELP"), #selector(menuHelp), "?"))
        helpItem.submenu = helpMenu
        main.addItem(helpItem)
        NSApp.helpMenu = helpMenu

        NSApp.mainMenu = main
        settingsWindow?.title = L10n.t("SETTINGS")
    }

    private func item(_ title: String, _ action: Selector, _ key: String) -> NSMenuItem {
        let i = NSMenuItem(title: title, action: action, keyEquivalent: key)
        i.target = self
        return i
    }

    @objc private func menuSettings() { model.openSettings() }
    @objc private func menuStartStop() { model.toggleStartStop() }
    @objc private func menuPause() { model.pauseTimer() }
    @objc private func menuPrevTalk() { model.selectPreviousTalk() }
    @objc private func menuNextTalk() { model.selectNextTalk() }
    @objc private func menuAddMinute() { model.increment(60) }
    @objc private func menuRemoveMinute() { model.increment(-60) }
    @objc private func menuEditDuration() { model.startDurationEdit() }
    @objc private func menuEditSchedule() { model.openScheduleEditor() }
    @objc private func menuBell() { model.bellToggle() }
    @objc private func menuHelp() { model.openHelp() }

    @objc private func menuCompact() {
        if model.isShrunk {
            expand()
        } else {
            shrink()
        }
    }

    @objc private func menuShowOperator() {
        mainWindow.makeKeyAndOrderFront(nil)
    }
}
