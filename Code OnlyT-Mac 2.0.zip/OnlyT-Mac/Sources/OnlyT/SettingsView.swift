import AppKit
import SwiftUI
import OnlyTCore

/// Settings page (port of SettingsPage.xaml), shown in its own window.
@MainActor
struct SettingsView: View {
    @ObservedObject var model: AppModel

    private var o: Binding<Options> { $model.options }

    var body: some View {
        Form {
            mainSection
            autoSection
            bellSection
            timerWindowSection
            remoteSection
            webClockSection
            remoteAppsSection
            countdownSection
            miscSection
        }
        .formStyle(.grouped)
        .frame(minWidth: 480, minHeight: 400)
    }

    // MARK: helpers

    private func header(_ key: String) -> some View {
        Text(L10n.t(key))
            .font(.system(size: 12, weight: .bold))
            .foregroundColor(Palette.primary)
    }

    private func percentBinding(_ keyPath: WritableKeyPath<Options, Int>) -> Binding<Double> {
        Binding(
            get: { Double(model.options[keyPath: keyPath]) },
            set: { model.options[keyPath: keyPath] = Int($0.rounded()) })
    }

    private func monitorBinding(_ keyPath: WritableKeyPath<Options, String?>) -> Binding<String> {
        Binding(
            get: { model.options[keyPath: keyPath] ?? "" },
            set: { model.options[keyPath: keyPath] = $0.isEmpty ? nil : $0 })
    }

    @ViewBuilder
    private func monitorPicker(_ keyPath: WritableKeyPath<Options, String?>, disabled: Bool) -> some View {
        let current = model.options[keyPath: keyPath] ?? ""
        Picker(L10n.t("MONITOR"), selection: monitorBinding(keyPath)) {
            Text(L10n.t("MONITOR_NONE")).tag("")
            ForEach(model.screens) { s in
                Text(s.title).tag(s.id)
            }
            if !current.isEmpty && !model.screens.contains(where: { $0.id == current }) {
                Text(current.split(separator: "|").last.map(String.init) ?? current).tag(current)
            }
        }
        .disabled(disabled)
    }

    // MARK: sections

    private var mainSection: some View {
        Section(header: header("MAIN_SECTION")) {
            monitorPicker(\.timerMonitorId, disabled: model.options.mainMonitorIsWindowed)
            Toggle(L10n.t("MONITOR_IS_WINDOWED"), isOn: o.mainMonitorIsWindowed)

            Picker(L10n.t("OP_MODE"), selection: o.operatingMode) {
                ForEach(OperatingMode.allCases) { m in
                    Text(m.title).tag(m)
                }
            }

            if model.options.operatingMode == .scheduleFile {
                Picker(L10n.t("SCHEDULE_FILE"), selection: Binding(
                    get: { model.options.scheduleFile ?? "" },
                    set: { model.options.scheduleFile = $0.isEmpty ? nil : $0 })) {
                    if model.scheduleFiles.isEmpty {
                        Text(L10n.t("MAC_NO_SCHEDULE_FILES")).tag("")
                    } else if !(model.scheduleFiles.contains(model.options.scheduleFile ?? "")) {
                        Text("-").tag(model.options.scheduleFile ?? "")
                    }
                    ForEach(model.scheduleFiles, id: \.self) { f in
                        Text((f as NSString).deletingPathExtension).tag(f)
                    }
                }
                HStack {
                    Button(L10n.t("MAC_OPEN_SCHEDULES_FOLDER")) { model.openSchedulesFolder() }
                    Button(L10n.t("MAC_CREATE_SAMPLE_SCHEDULE")) { model.createSampleSchedule() }
                    Spacer()
                    Button {
                        model.refreshScheduleFiles()
                    } label: {
                        Image(systemName: "arrow.clockwise")
                    }
                    .help("Refresh")
                }
            }

            Picker(L10n.t("DIGITAL_CLOCK_FORMAT"), selection: o.clockHourFormat) {
                ForEach(ClockHourFormat.allCases) { f in
                    Text(f.title).tag(f)
                }
            }
            Toggle(L10n.t("SHOW_SECONDS"), isOn: o.showDigitalSeconds)
                .disabled(model.options.clockHourFormat.showsAMPM)

            Text(L10n.f("APP_VER", appVersion))
                .font(.footnote)
                .foregroundColor(.secondary)
        }
    }

    private var appVersion: String {
        (Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "2.5.0") + " (macOS)"
    }

    private var autoSection: some View {
        Section(header: header("AUTO_SECTION")) {
            Picker(L10n.t("MEETING"), selection: o.midWeekOrWeekend) {
                Text(L10n.t("MIDWEEK")).tag(MidWeekOrWeekend.midWeek)
                Text(L10n.t("WEEKEND")).tag(MidWeekOrWeekend.weekend)
            }
            Picker(L10n.t("ADAPTIVE_MIDWEEK"), selection: o.midWeekAdaptiveMode) {
                ForEach(AdaptiveMode.allCases) { m in
                    Text(m.title).tag(m)
                }
            }
            Picker(L10n.t("ADAPTIVE_WEEKEND"), selection: o.weekendAdaptiveMode) {
                ForEach(AdaptiveMode.allCases) { m in
                    Text(m.title).tag(m)
                }
            }
            Toggle(L10n.t("WEEKEND_INCLUDES_FRIDAY"), isOn: o.weekendIncludesFriday)
            Toggle(L10n.t("CIRCUIT_VISIT"), isOn: o.isCircuitVisit)
            Toggle(L10n.t("CO_VISIT_TOGGLE"), isOn: o.showCircuitVisitToggle)
            Toggle(L10n.t("PERSIST_STUDENT_TIME"), isOn: o.persistStudentTime)
            Toggle(L10n.t("PERSIST_COUNTDOWN_BAR"), isOn: o.showPersistCountdown)
            Toggle(L10n.t("SHOULD_GENERATE_REPORTS"), isOn: o.generateTimingReports)
            HStack {
                Button(L10n.t("MAC_OPEN_REPORTS_FOLDER")) { model.openReportsFolder() }
                Button(L10n.t("MAC_DELETE_TIMING_DATA")) { model.deleteTimingData() }
            }
        }
        .disabled(model.options.operatingMode != .automatic)
    }

    private var bellSection: some View {
        Section(header: header("BELL_SECTION")) {
            Toggle(L10n.t("ENABLED_BELL"), isOn: o.isBellEnabled)
            Toggle(L10n.t("AUTO_BELL"), isOn: o.autoBell)
                .disabled(!model.options.isBellEnabled)
            HStack {
                Text(L10n.t("VOLUME"))
                Slider(value: percentBinding(\.bellVolumePercent), in: 0...100)
                Text("\(model.options.bellVolumePercent)%")
                    .monospacedDigit()
                    .frame(width: 44, alignment: .trailing)
                Button(L10n.t("TEST")) { model.testBell() }
            }
            .disabled(!model.options.isBellEnabled)
        }
    }

    private var timerWindowSection: some View {
        Section(header: header("TIMER_WIN_SECTION")) {
            Picker(L10n.t("FULL_SCREEN_CLOCK"), selection: o.fullScreenClockMode) {
                ForEach(FullScreenClockMode.allCases) { m in
                    Text(m.title).tag(m)
                }
            }
            HStack {
                Text(L10n.t("SPLIT_WIDTH"))
                Slider(value: percentBinding(\.analogueClockWidthPercent), in: 0...100)
                Text("\(model.options.analogueClockWidthPercent)%")
                    .monospacedDigit()
                    .frame(width: 44, alignment: .trailing)
            }
            Toggle(L10n.t("SHOW_CLOCK_FRAME"), isOn: o.timerFrame)
            Toggle(L10n.t("SHOW_TIMER_FRAME"), isOn: o.clockTimerFrame)
            Toggle(L10n.t("CLOCK_BACKGROUND_COLOUR"), isOn: o.showBackgroundOnClock)
            Toggle(L10n.t("TIMER_BACKGROUND_COLOUR"), isOn: o.showBackgroundOnTimer)
            Toggle(L10n.t("TIME_UNDER_TIMER"), isOn: o.showTimeOfDayUnderTimer)
            Toggle(L10n.t("TIMER_COUNT_UP"), isOn: o.countUp)
            Toggle(L10n.t("SECTOR_ANALOG_CLOCK"), isOn: o.showDurationSector)
            Toggle(L10n.t("MOUSE_PTR"), isOn: o.showMousePointerInTimerDisplay)
            Toggle(L10n.t("FLAT_CLOCK"), isOn: o.clockIsFlat)
            Picker(L10n.t("PERSIST_TALK_DURATION"), selection: o.persistDurationSecs) {
                ForEach(Options.persistDurationItems, id: \.self) { s in
                    Text(L10n.f("X_SECONDS", s)).tag(s)
                }
            }
            Text(L10n.t("MAC_SEPARATE_SPACES_NOTE"))
                .font(.footnote)
                .foregroundColor(.secondary)
        }
    }

    private var remoteSection: some View {
        Section(header: header("REMOTE_SECTION")) {
            Picker(L10n.t("PORT"), selection: o.httpServerPort) {
                ForEach(Options.portItems, id: \.self) { p in
                    Text(String(p)).tag(p)
                }
            }
            if let err = model.webServerError {
                Text(err)
                    .font(.footnote)
                    .foregroundColor(.red)
            }
            Text(L10n.t("MAC_FIREWALL_NOTE"))
                .font(.footnote)
                .foregroundColor(.secondary)
        }
    }

    private var webClockSection: some View {
        Section(header: header("CLOCK_SECTION")) {
            Toggle(L10n.t("ENABLED_WEB_CLOCK"), isOn: o.isWebClockEnabled)
            Toggle(L10n.t("WEB_CLOCK_SHOW_TOD_SECONDS"), isOn: o.webClockShowTimeOfDaySeconds)
                .disabled(!model.options.isWebClockEnabled)
            if let url = model.webClockURL {
                HStack(alignment: .top, spacing: 16) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(url)
                            .textSelection(.enabled)
                            .font(.system(.body, design: .monospaced))
                        HStack {
                            Button(L10n.t("MAC_OPEN_IN_BROWSER")) {
                                if let u = URL(string: url) {
                                    NSWorkspace.shared.open(u)
                                }
                            }
                            Button(L10n.t("MAC_COPY")) {
                                NSPasteboard.general.clearContents()
                                NSPasteboard.general.setString(url, forType: .string)
                            }
                        }
                    }
                    Spacer()
                    if let qr = NetworkInfo.qrCode(for: url, size: 120) {
                        Image(nsImage: qr)
                            .interpolation(.none)
                            .resizable()
                            .frame(width: 120, height: 120)
                    }
                }
                .disabled(!model.options.isWebClockEnabled)
            } else {
                Text(L10n.t("MAC_WEB_CLOCK_NA")).foregroundColor(.secondary)
            }
        }
    }

    private var remoteAppsSection: some View {
        Section(header: header("APPS_SECTION")) {
            Toggle(L10n.t("ENABLED_API"), isOn: o.isApiEnabled)
            Toggle(L10n.t("THROTTLED"), isOn: o.isApiThrottled)
                .disabled(!model.options.isApiEnabled)
            HStack {
                Text(L10n.t("IP_ADDRESS"))
                Spacer()
                Text(model.localIP ?? L10n.t("MAC_NOT_AVAILABLE"))
                    .textSelection(.enabled)
                    .foregroundColor(.secondary)
            }
            HStack {
                TextField(L10n.t("ACCESS_CODE"), text: Binding(
                    get: { model.apiCodeDraft },
                    set: { v in
                        model.apiCodeDraft = v
                        let t = v.trimmingCharacters(in: .whitespaces)
                        model.options.apiCode = t.isEmpty ? nil : t
                    }))
                Button(L10n.t("MAC_GENERATE_CODE")) {
                    model.generateApiCode()
                }
            }
            .disabled(!model.options.isApiEnabled)
        }
    }

    private var countdownSection: some View {
        Section(header: header("COUNTDOWN_SECTION")) {
            monitorPicker(\.countdownMonitorId, disabled: model.options.countdownMonitorIsWindowed)
            Toggle(L10n.t("COUNTDOWN_IS_WINDOWED"), isOn: o.countdownMonitorIsWindowed)
            Picker(L10n.t("LOCATION_ON_SCREEN"), selection: o.countdownScreenLocation) {
                ForEach(ScreenLocation.allCases) { l in
                    Text(l.title).tag(l)
                }
            }
            HStack {
                Text(L10n.t("COUNTDOWN_ZOOM"))
                Slider(value: percentBinding(\.countdownZoomPercent), in: 10...100)
                Text("\(model.options.countdownZoomPercent)%")
                    .monospacedDigit()
                    .frame(width: 44, alignment: .trailing)
            }
            Toggle(L10n.t("SHOW_COUNTDOWN_FRAME"), isOn: o.countdownFrame)
            Toggle(L10n.t("COUNTDOWN_TRANSPARENT"), isOn: o.isCountdownWindowTransparent)
            Picker(L10n.t("COUNTDOWN_ELEMENTS"), selection: o.countdownElementsToShow) {
                ForEach(CountdownElements.allCases) { e in
                    Text(e.title).tag(e)
                }
            }
            Picker(L10n.t("COUNTDOWN_DURATION_MINS"), selection: o.countdownDurationMins) {
                ForEach(Options.countdownDurationItems, id: \.self) { m in
                    Text(String(m)).tag(m)
                }
            }
            VStack(alignment: .leading, spacing: 6) {
                Text(L10n.t("MEETING_STARTS"))
                TextEditor(text: Binding(
                    get: { model.startTimesDraft },
                    set: { v in
                        model.startTimesDraft = v
                        model.setMeetingStartTimesText(v)
                    }))
                    .font(.system(.body, design: .monospaced))
                    .frame(height: 90)
                    .overlay(RoundedRectangle(cornerRadius: 4).stroke(Color.secondary.opacity(0.4)))
                Text(L10n.t("NOTES") + " " + L10n.t("MTG_START_NOTES1") + " " + L10n.t("MTG_START_NOTES2") + " " + L10n.t("MTG_START_NOTES3"))
                    .font(.footnote)
                    .foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var miscSection: some View {
        Section(header: header("MISC_SECTION")) {
            Toggle(L10n.t("DARK_MODE"), isOn: o.darkModeToggle)
            Toggle(L10n.t("ALLOW_COUNT_UP_TOGGLE"), isOn: o.allowCountUpToggle)
            Toggle(L10n.t("SHOW_PAUSE"), isOn: o.showPauseButton)
            Toggle(L10n.t("ALLOW_MOUSE_WHEEL_TIMER_ADJUST"), isOn: o.allowMouseWheelTimerAdjust)
            Toggle(L10n.t("ALWAYS_ON_TOP"), isOn: o.alwaysOnTop)
            Toggle(L10n.t("SHRINK_ON_MINIMISE"), isOn: o.shrinkOnMinimise)
            Toggle(L10n.t("TIMER_REMINDER"), isOn: o.timerReminder)
            Toggle(L10n.t("OVERRUN_NOTIFICATIONS"), isOn: o.overrunNotifications)
            Picker(L10n.t("LANGUAGE"), selection: Binding(
                get: { model.options.culture ?? "" },
                set: { model.options.culture = $0.isEmpty ? nil : $0 })) {
                Text(L10n.t("MAC_SYSTEM_LANGUAGE")).tag("")
                ForEach(L10n.shared.availableLanguages, id: \.self) { code in
                    Text(L10n.displayName(for: code)).tag(code)
                }
            }
            Text(L10n.t("RESTART_LANGUAGE"))
                .font(.footnote)
                .foregroundColor(.secondary)
        }
    }
}
