import AppKit
import SwiftUI
import OnlyTCore

// MARK: - Geometry helpers

/// Point on a circle; `degrees` measured clockwise from 12 o'clock (y axis pointing down).
private func pointOnCircle(_ centre: CGPoint, _ radius: CGFloat, _ degrees: Double) -> CGPoint {
    let r = degrees * .pi / 180
    return CGPoint(x: centre.x + radius * CGFloat(sin(r)), y: centre.y - radius * CGFloat(cos(r)))
}

/// Wedge from the centre between two clock angles (clockwise from `from` to `to`).
private func wedge(_ centre: CGPoint, _ radius: CGFloat, from: Double, to: Double) -> Path {
    var sweep = (to - from).truncatingRemainder(dividingBy: 360)
    if sweep < 0 {
        sweep += 360
    }
    var p = Path()
    p.move(to: centre)
    let steps = max(2, Int(sweep))
    for i in 0...steps {
        p.addLine(to: pointOnCircle(centre, radius, from + sweep * Double(i) / Double(steps)))
    }
    p.closeSubpath()
    return p
}

/// Ring segment from `angle` clockwise round to 12 o'clock (port of CountdownTimer PieSlice).
private func annulusSegment(_ centre: CGPoint, inner: CGFloat, outer: CGFloat, angle: Double) -> Path {
    var p = Path()
    let a = max(0, min(360, angle))
    let steps = max(2, Int(360 - a))
    p.move(to: pointOnCircle(centre, inner, a))
    for i in 0...steps {
        p.addLine(to: pointOnCircle(centre, outer, a + (360 - a) * Double(i) / Double(steps)))
    }
    for i in 0...steps {
        p.addLine(to: pointOnCircle(centre, inner, 360 - (360 - a) * Double(i) / Double(steps)))
    }
    p.closeSubpath()
    return p
}

// MARK: - Analogue clock

/// Port of the OnlyT analogue clock control (drawn in a 500 x 500 design space).
struct AnalogueClockView: View {
    let now: () -> Date
    let isFlat: Bool
    let sector: DurationSector?
    let sectorRevealDate: Date
    /// Start of the hands' start-up sweep (owned by the display model: no @State).
    let appearDate: Date

    private static let clockRadius: CGFloat = 250
    private static let sectorRadius: CGFloat = 230
    private static let hourNumberColor = Color(hex: 0x483D8B) // DarkSlateBlue
    private static let secondHandColor = Color(hex: 0xB22222) // Firebrick

    var body: some View {
        let appear = appearDate
        TimelineView(.animation(minimumInterval: 0.05)) { timeline in
            Canvas { ctx, size in
                draw(ctx: &ctx, size: size, wallClock: timeline.date, appear: appear)
            }
        }
    }

    private func draw(ctx: inout GraphicsContext, size: CGSize, wallClock: Date, appear: Date) {
        let side = min(size.width, size.height)
        guard side > 1 else {
            return
        }
        let scale = side / 500
        ctx.translateBy(x: (size.width - side) / 2, y: (size.height - side) / 2)
        ctx.scaleBy(x: scale, y: scale)

        let c = CGPoint(x: 250, y: 250)

        // dials
        let outer = Path(ellipseIn: CGRect(x: 0, y: 0, width: 500, height: 500))
        let middle = Path(ellipseIn: CGRect(x: 10, y: 10, width: 480, height: 480))
        let inner = Path(ellipseIn: CGRect(x: 17, y: 17, width: 466, height: 466))
        if isFlat {
            ctx.fill(outer, with: .color(Color(hex: 0xACACA2)))
            ctx.fill(middle, with: .color(Color(hex: 0x130101)))
        } else {
            ctx.fill(outer, with: .linearGradient(
                Gradient(stops: [
                    .init(color: Color(hex: 0xB1B2AA), location: 0),
                    .init(color: Color(hex: 0xD1D1D1), location: 0.673),
                    .init(color: Color(hex: 0xACACA2), location: 1),
                ]),
                startPoint: CGPoint(x: 250, y: 0), endPoint: CGPoint(x: 0, y: 250)))
            ctx.fill(middle, with: .linearGradient(
                Gradient(stops: [
                    .init(color: Color(hex: 0x151515), location: 0),
                    .init(color: Color(hex: 0xD1D1D1), location: 0.673),
                    .init(color: Color(hex: 0x130101), location: 1),
                ]),
                startPoint: CGPoint(x: 250, y: 10), endPoint: CGPoint(x: 10, y: 250)))
        }
        ctx.fill(inner, with: .color(.white))

        // duration sector
        if let s = sector, wallClock >= sectorRevealDate {
            let stroke = Color(hex: 0xDDDDDD)
            let p1 = wedge(c, Self.sectorRadius, from: s.startAngle, to: s.endAngle)
            ctx.fill(p1, with: .color(Color(hex: 0x99FF99)))
            ctx.stroke(p1, with: .color(stroke), lineWidth: 1)
            if s.showElapsedSector {
                let elapsedEnd = s.isOvertime ? s.endAngle : s.currentAngle
                let p2 = wedge(c, Self.sectorRadius, from: s.startAngle, to: elapsedEnd)
                ctx.fill(p2, with: .color(Color(hex: 0xE6FFE6)))
                ctx.stroke(p2, with: .color(stroke), lineWidth: 1)
            }
            if s.isOvertime {
                let p3 = wedge(c, Self.sectorRadius, from: s.endAngle, to: s.currentAngle)
                ctx.fill(p3, with: .color(Color(hex: 0xFFB399)))
                ctx.stroke(p3, with: .color(stroke), lineWidth: 1)
            }
        }

        // markers
        for n in 0..<60 {
            let angle = Double(n) * 6
            let isHour = n % 5 == 0
            let isMajor = n % 15 == 0
            let width: CGFloat = isMajor ? 7 : (isHour ? 3 : 1)
            let length: CGFloat = isMajor ? 8 : 6
            var line = Path()
            line.move(to: pointOnCircle(c, 250 - 19, angle))
            line.addLine(to: pointOnCircle(c, 250 - 19 - length, angle))
            ctx.stroke(line, with: .color(.black), lineWidth: width)
        }

        // hour numbers
        for n in 0..<12 {
            let hour = n == 0 ? 12 : n
            let pt = pointOnCircle(c, 200, Double(n) * 30)
            let text = Text("\(hour)").font(.system(size: 36, weight: .bold)).foregroundColor(Self.hourNumberColor)
            ctx.draw(text, at: pt, anchor: .center)
        }

        // hands
        let t = now()
        let cal = Calendar.current
        let comps = cal.dateComponents([.hour, .minute, .second, .nanosecond], from: t)
        let hour = Double((comps.hour ?? 0) % 12)
        let minute = Double(comps.minute ?? 0)
        let second = Double(comps.second ?? 0)
        let ms = Double(comps.nanosecond ?? 0) / 1_000_000

        var secondsAngle = second * 6
        var minutesAngle = minute * 6 + second * 0.1 + ms * 0.0001
        var hoursAngle = hour * 30 + minute * 0.5 + second * (0.5 / 60) + ms * (0.5 / 60_000)

        // start-up animation: the hands sweep from 12 o'clock
        let progress = min(1, max(0, wallClock.timeIntervalSince(appear) / 1.2))
        if progress < 1 {
            let eased = 1 - pow(1 - progress, 3)
            secondsAngle *= eased
            minutesAngle *= eased
            hoursAngle *= eased
        }

        drawHand(&ctx, c, angle: hoursAngle, length: 120, tail: 0, width: 18, color: .black,
                 shadowOpacity: isFlat ? 0 : 1.0, blur: 5, pointed: true)
        drawHand(&ctx, c, angle: minutesAngle, length: 160, tail: 0, width: 12, color: .black,
                 shadowOpacity: isFlat ? 0 : 0.4, blur: 5, pointed: true)
        drawHand(&ctx, c, angle: secondsAngle, length: 150, tail: 40, width: 2, color: Self.secondHandColor,
                 shadowOpacity: isFlat ? 0 : 0.3, blur: 1.2, pointed: false)

        // centre point
        let centre = Path(ellipseIn: CGRect(x: 235, y: 235, width: 30, height: 30))
        ctx.drawLayer { layer in
            if !isFlat {
                layer.addFilter(.shadow(color: .black.opacity(0.5), radius: 4, x: 0, y: 0))
            }
            layer.fill(centre, with: .color(Color(hex: 0xD1D1D1)))
        }
        ctx.stroke(centre, with: .color(.black), lineWidth: 3)
    }

    private func drawHand(_ ctx: inout GraphicsContext, _ c: CGPoint, angle: Double, length: CGFloat, tail: CGFloat,
                          width: CGFloat, color: Color, shadowOpacity: Double, blur: CGFloat, pointed: Bool) {
        var hand = Path()
        if pointed {
            // line with a triangular end cap (StrokeEndLineCap = Triangle)
            let half = width / 2
            hand.move(to: CGPoint(x: c.x - half, y: c.y + tail))
            hand.addLine(to: CGPoint(x: c.x - half, y: c.y - length))
            hand.addLine(to: CGPoint(x: c.x, y: c.y - length - half))
            hand.addLine(to: CGPoint(x: c.x + half, y: c.y - length))
            hand.addLine(to: CGPoint(x: c.x + half, y: c.y + tail))
            hand.closeSubpath()
        } else {
            hand.addRect(CGRect(x: c.x - width / 2, y: c.y - length, width: width, height: length + tail))
        }
        let rotation = CGAffineTransform(translationX: c.x, y: c.y)
            .rotated(by: CGFloat(angle * .pi / 180))
            .translatedBy(x: -c.x, y: -c.y)
        let rotated = hand.applying(rotation)
        ctx.drawLayer { layer in
            if shadowOpacity > 0 {
                layer.addFilter(.shadow(color: Color(white: 0.35).opacity(shadowOpacity), radius: blur, x: 2, y: 2))
            }
            layer.fill(rotated, with: .color(color))
        }
    }
}

// MARK: - Digital time of day

struct DigitalTimeView: View {
    let now: () -> Date
    let format: ClockHourFormat
    let showSeconds: Bool

    var body: some View {
        TimelineView(.periodic(from: Date(), by: 0.25)) { _ in
            let t = now()
            let hm = format.formatHoursMinutes(t)
            let secs = showSeconds ? format.formatSeconds(t) : ""
            GeometryReader { geo in
                let natural = Self.naturalSize(hm, secs)
                let scale = max(0.01, min(geo.size.width / natural.width, geo.size.height / natural.height))
                HStack(alignment: .top, spacing: 0) {
                    Text(hm)
                        .font(.system(size: 24 * scale, weight: .bold))
                        .monospacedDigit()
                        .foregroundColor(.white)
                    if !secs.isEmpty {
                        Text(secs)
                            .font(.system(size: 13 * scale))
                            .monospacedDigit()
                            .foregroundColor(Color(hex: 0xCBABAB))
                            .padding(.leading, 2 * scale)
                    }
                }
                .fixedSize()
                .frame(width: geo.size.width, height: geo.size.height)
            }
        }
    }

    static func naturalSize(_ hm: String, _ secs: String) -> CGSize {
        let big = (hm as NSString).size(withAttributes: [.font: NSFont.monospacedDigitSystemFont(ofSize: 24, weight: .bold)])
        var width = big.width + 10
        if !secs.isEmpty {
            let small = (secs as NSString).size(withAttributes: [.font: NSFont.monospacedDigitSystemFont(ofSize: 13, weight: .regular)])
            width += small.width + 2
        }
        return CGSize(width: max(width, 1), height: max(big.height, 1))
    }
}

// MARK: - Countdown

/// Port of the OnlyT.CountdownTimer control: a ring that empties clockwise, a
/// "seconds ball" and the remaining time.
@MainActor
struct CountdownDialView: View {
    @ObservedObject var model: CountdownModel

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30)) { _ in
            let snapshot = CountdownSnapshot(durationMins: model.durationMins,
                                    secondsLeft: model.secondsLeft(at: model.now()),
                                    elements: model.options.countdownElementsToShow)
            Canvas { ctx, size in
                drawCountdown(&ctx, size, snapshot)
            }
        }
    }
}

private struct CountdownSnapshot {
    let durationMins: Int
    let secondsLeft: Double?
    let elements: CountdownElements
}

private let countdownRevealed = Color(hex: 0xC0C5C1)
private let countdownRing = Color(hex: 0x74546A)
private let countdownRingStroke = Color(hex: 0x473341)
private let countdownBall = Color(hex: 0xEAF0CE)

private func countdownTimeText(_ secondsLeft: Double, twoDigitMins: Bool) -> String {
    let left = max(0, secondsLeft + 1)
    let mins = Int(left) / 60
    let secs = Int(left.truncatingRemainder(dividingBy: 60))
    return twoDigitMins ? String(format: "%02d:%02d", mins, secs) : String(format: "%d:%02d", mins, secs)
}

private func drawCountdown(_ ctx: inout GraphicsContext, _ size: CGSize, _ snap: CountdownSnapshot) {
    let durationMins = max(1, snap.durationMins)
    let total = Double(durationMins * 60)
    let left = snap.secondsLeft ?? total
    let elapsed = total - left
    let clampedLeft = max(0, left)
    let angle = left >= 0 ? 360 - (360 / total) * clampedLeft : 0
    let twoDigits = durationMins > 9
    let elements = snap.elements
    let text = countdownTimeText(min(left, total - 1), twoDigitMins: twoDigits)
    let textColor = countdownBall

    let w = size.width
    let h = size.height
    guard w > 10 && h > 10 else {
        return
    }

    var outerFactor = 0.24
    var innerFactor = 0.15
    if elements == .dial {
        outerFactor *= 1.75
        innerFactor *= 1.75
    }
    let outerR = CGFloat(Int(h * outerFactor))
    let innerR = CGFloat(Int(h * innerFactor))
    let outerD = outerR * 2

    if elements == .digital {
        let probe = ctx.resolve(Text(text).font(.system(size: 100, weight: .bold)).monospacedDigit())
        let probeSize = probe.measure(in: CGSize(width: 10_000, height: 10_000))
        var fs = 100 * (0.95 * w) / max(probeSize.width, 1)
        fs = min(fs, 100 * (0.95 * h) / max(probeSize.height, 1))
        let resolved = ctx.resolve(Text(text).font(.system(size: fs, weight: .bold)).monospacedDigit().foregroundColor(textColor))
        ctx.draw(resolved, at: CGPoint(x: w / 2, y: h / 2), anchor: .center)
        return
    }

    let totalWidth = elements == .dialAndDigital ? 3.25 * outerD : outerD
    let margin = (w - totalWidth) / 2
    let centre = CGPoint(x: margin + outerR, y: h / 2)

    // revealed ring (radial gradient white -> grey)
    let donut = annulusSegment(centre, inner: innerR, outer: outerR, angle: 0.1)
    ctx.fill(donut, with: .radialGradient(
        Gradient(stops: [
            .init(color: .white, location: 0.7),
            .init(color: countdownRevealed, location: 1),
        ]),
        center: centre, startRadius: 0, endRadius: outerR))

    // remaining time ring
    if angle < 360 {
        let pie = annulusSegment(centre, inner: innerR, outer: outerR, angle: max(angle, 0.1))
        ctx.fill(pie, with: .color(countdownRing))
        ctx.stroke(pie, with: .color(countdownRingStroke), lineWidth: 1)
    }

    // seconds ball
    if durationMins > 1 {
        let ballR = innerR / 12
        let pathR = innerR - 1.5 * ballR
        let secs = Int(max(0, elapsed)) % 60
        let p = pointOnCircle(centre, pathR, Double(secs) * 6)
        ctx.fill(Path(ellipseIn: CGRect(x: p.x - ballR, y: p.y - ballR, width: ballR * 2, height: ballR * 2)),
                 with: .color(countdownBall))
    }

    if elements == .dialAndDigital {
        // digits about 75% of the dial height (60% for 2-digit minutes)
        let factor: CGFloat = twoDigits ? 0.60 : 0.75
        let font = NSFont.systemFont(ofSize: 100, weight: .bold)
        let capRatio = max(font.capHeight / 100, 0.5)
        let fs = factor * outerD / capRatio
        let resolved = ctx.resolve(Text(text).font(.system(size: fs, weight: .bold)).monospacedDigit().foregroundColor(textColor))
        let rightX = centre.x - outerR + totalWidth
        ctx.draw(resolved, at: CGPoint(x: rightX, y: centre.y), anchor: .trailing)
    }
}
