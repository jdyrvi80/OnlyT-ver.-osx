import Foundation
import Network
import OnlyTCore

/// Minimal HTTP/1.1 server (Network.framework) for the web clock and the
/// remote-control API, replacing the HttpListener of the Windows version.
final class WebServer {
    private let queue = DispatchQueue(label: "OnlyT.WebServer")
    private var listener: NWListener?
    let router: WebRouter
    /// Called (on the main queue) when the server cannot start.
    var onError: ((String) -> Void)?
    private(set) var port: Int = 0

    init(router: WebRouter) {
        self.router = router
    }

    var isRunning: Bool {
        listener != nil
    }

    func start(port: Int) {
        stop()
        guard let nwPort = NWEndpoint.Port(rawValue: UInt16(clamping: port)) else {
            return
        }
        self.port = port
        do {
            let params = NWParameters.tcp
            params.allowLocalEndpointReuse = true
            let l = try NWListener(using: params, on: nwPort)
            l.newConnectionHandler = { [weak self] connection in
                guard let self = self else {
                    connection.cancel()
                    return
                }
                HTTPSession(connection: connection, router: self.router, queue: self.queue).start()
            }
            l.stateUpdateHandler = { [weak self] state in
                if case .failed(let error) = state {
                    let message = "\(error)"
                    DispatchQueue.main.async {
                        self?.onError?(message)
                    }
                }
            }
            l.start(queue: queue)
            listener = l
        } catch {
            let message = "\(error)"
            DispatchQueue.main.async { [weak self] in
                self?.onError?(message)
            }
        }
    }

    func stop() {
        listener?.newConnectionHandler = nil
        listener?.stateUpdateHandler = nil
        listener?.cancel()
        listener = nil
    }
}

/// One client connection (supports keep-alive, as browsers expect).
private final class HTTPSession {
    private let connection: NWConnection
    private let router: WebRouter
    private let queue: DispatchQueue
    private var buffer = Data()
    private var closed = false
    private var closing = false
    private var endpoint = ""
    private var idleWork: DispatchWorkItem?
    private static let idleTimeout: TimeInterval = 30

    init(connection: NWConnection, router: WebRouter, queue: DispatchQueue) {
        self.connection = connection
        self.router = router
        self.queue = queue
    }

    func start() {
        switch connection.endpoint {
        case let .hostPort(host, port):
            endpoint = "\(host):\(port)"
        default:
            endpoint = "\(connection.endpoint)"
        }
        // the handlers keep the session alive until the connection ends
        connection.stateUpdateHandler = { state in
            switch state {
            case .failed, .cancelled:
                self.finish()
            default:
                break
            }
        }
        connection.start(queue: queue)
        scheduleIdleTimeout()
        receive()
    }

    private func receive() {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1024) { data, _, isComplete, error in
            if let data = data, !data.isEmpty {
                self.buffer.append(data)
                self.scheduleIdleTimeout()
                self.process()
            }
            if isComplete || error != nil {
                self.close()
                return
            }
            if !self.closed && !self.closing {
                self.receive()
            }
        }
    }

    private func process() {
        while !closed && !closing {
            let parsed: (HTTPRequest, Int)?
            do {
                parsed = try HTTPParser.parse(buffer, remoteEndpoint: endpoint)
            } catch {
                send(HTTPResponse(status: 400).serialized(keepAlive: false), thenClose: true)
                return
            }
            guard let result = parsed else {
                return
            }
            let request = result.0
            let consumed = result.1
            buffer = consumed >= buffer.count ? Data() : Data(buffer.suffix(from: buffer.startIndex + consumed))
            let response = router.handle(request)
            let keepAlive = request.wantsKeepAlive
            send(response.serialized(keepAlive: keepAlive), thenClose: !keepAlive)
        }
    }

    private func send(_ data: Data, thenClose: Bool) {
        if thenClose {
            closing = true
        }
        connection.send(content: data, completion: .contentProcessed { _ in
            if thenClose {
                self.close()
            }
        })
    }

    private func scheduleIdleTimeout() {
        idleWork?.cancel()
        let work = DispatchWorkItem { [weak self] in
            self?.close()
        }
        idleWork = work
        queue.asyncAfter(deadline: .now() + HTTPSession.idleTimeout, execute: work)
    }

    private func close() {
        guard !closed else {
            return
        }
        connection.cancel()
        finish()
    }

    private func finish() {
        closed = true
        idleWork?.cancel()
        idleWork = nil
        connection.stateUpdateHandler = nil
    }
}
