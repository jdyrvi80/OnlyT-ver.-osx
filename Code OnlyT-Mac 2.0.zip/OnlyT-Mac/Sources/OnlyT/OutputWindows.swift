import AppKit
import SwiftUI
import OnlyTCore

/// Borderless window used for the timer / countdown displays.
final class OutputWindow: NSWindow {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { false }
}

/// Container view (hosting the SwiftUI content) that can hide the mouse
/// pointer while it is over the display.
final class CursorHidingContainer: NSView {
    var hidePointer = true {
        didSet {
            if !hidePointer {
                releaseCursor()
            }
        }
    }
    private var cursorHidden = false
    private var area: NSTrackingArea?

    init(content: NSView) {
        super.init(frame: NSRect(x: 0, y: 0, width: 700, height: 500))
        content.frame = bounds
        content.autoresizingMask = [.width, .height]
        addSubview(content)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) is not supported")
    }

    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        if let a = area {
            removeTrackingArea(a)
        }
        let a = NSTrackingArea(rect: bounds, options: [.mouseEnteredAndExited, .activeAlways, .inVisibleRect], owner: self, userInfo: nil)
        addTrackingArea(a)
        area = a
    }

    override func mouseEntered(with event: NSEvent) {
        super.mouseEntered(with: event)
        if hidePointer && !cursorHidden {
            NSCursor.hide()
            cursorHidden = true
        }
    }

    override func mouseExited(with event: NSEvent) {
        super.mouseExited(with: event)
        releaseCursor()
    }

    func releaseCursor() {
        if cursorHidden {
            NSCursor.unhide()
            cursorHidden = false
        }
    }
}

/// Window level used for full-screen displays: above the menu bar and the Dock,
/// but below pop-up menus (level 101), so pickers in the operator / settings
/// windows still open in front when they share the monitor with a display.
let fullScreenDisplayLevel = NSWindow.Level(rawValue: NSWindow.Level.statusBar.rawValue + 1)

/// Hosting view that lets the window decide its own size (no SwiftUI size constraints).
@MainActor
func unconstrainedHostingView<V: View>(_ root: V) -> NSHostingView<V> {
    let v = NSHostingView(rootView: root)
    v.sizingOptions = []
    return v
}

/// Manages the timer output window (port of TimerOutputDisplayService).
@MainActor
final class TimerOutputController: NSObject, NSWindowDelegate {
    let model: TimerDisplayModel
    var optionsProvider: () -> Options = { Options() }
    var onFrameSaved: ((String) -> Void)?
    var onVisibilityChanged: (() -> Void)?

    private(set) var window: OutputWindow?
    private var hostingView: CursorHidingContainer?
    private var activity: NSObjectProtocol?

    init(model: TimerDisplayModel) {
        self.model = model
    }

    var isWindowAvailable: Bool { window != nil }
    var isVisible: Bool { window?.isVisible ?? false }

    /// Screen currently showing the window (nil if windowed or hidden).
    var screen: NSScreen? {
        guard let w = window, w.isVisible, !model.windowed else {
            return nil
        }
        return w.screen
    }

    /// Opens the window according to the options (windowed or on a monitor).
    func open() {
        let o = optionsProvider()
        if o.mainMonitorIsWindowed {
            openWindowed()
        } else if Screens.screen(for: o.timerMonitorId) != nil {
            openInMonitor()
        } else {
            hide()
        }
    }

    func openInMonitor() {
        let o = optionsProvider()
        guard let screen = Screens.screen(for: o.timerMonitorId) else {
            hide()
            return
        }
        let w = makeWindow(windowed: false)
        model.windowed = false
        w.setFrame(screen.frame, display: true)
        w.orderFrontRegardless()
        updatePointer()
        beginActivity()
        onVisibilityChanged?()
    }

    func openWindowed() {
        let o = optionsProvider()
        let w = makeWindow(windowed: true)
        model.windowed = true
        if let s = o.timerWindowFrame {
            let r = NSRectFromString(s)
            if r.width > 50 && r.height > 50 {
                w.setFrame(r, display: true)
            } else {
                w.setFrame(defaultWindowedFrame(), display: true)
            }
        } else {
            w.setFrame(defaultWindowedFrame(), display: true)
        }
        w.orderFrontRegardless()
        updatePointer()
        beginActivity()
        onVisibilityChanged?()
    }

    func relocate() {
        open()
    }

    func show() {
        if let w = window {
            w.orderFrontRegardless()
            onVisibilityChanged?()
        } else {
            open()
        }
    }

    func hide() {
        window?.orderOut(nil)
        endActivity()
        onVisibilityChanged?()
    }

    func close() {
        saveWindowedFrame()
        hostingView?.releaseCursor()
        window?.delegate = nil
        window?.orderOut(nil)
        window = nil
        hostingView = nil
        endActivity()
        onVisibilityChanged?()
    }

    func saveWindowedFrame() {
        if let w = window, model.windowed {
            onFrameSaved?(NSStringFromRect(w.frame))
        }
    }

    func updatePointer() {
        hostingView?.hidePointer = !optionsProvider().showMousePointerInTimerDisplay
    }

    private func defaultWindowedFrame() -> NSRect {
        let visible = NSScreen.main?.visibleFrame ?? NSRect(x: 0, y: 0, width: 1200, height: 800)
        return NSRect(x: visible.minX + 10, y: visible.maxY - 500 - 10, width: 700, height: 500)
    }

    private func makeWindow(windowed: Bool) -> OutputWindow {
        if let existing = window {
            saveWindowedFrame()
            existing.delegate = nil
            existing.orderOut(nil)
            hostingView?.releaseCursor()
        }
        let style: NSWindow.StyleMask = windowed
            ? [.titled, .resizable, .miniaturizable, .fullSizeContentView]
            : [.borderless]
        let w = OutputWindow(contentRect: NSRect(x: 0, y: 0, width: 700, height: 500), styleMask: style, backing: .buffered, defer: false)
        w.title = L10n.t("MAC_TIMER_DISPLAY_TITLE")
        w.isReleasedWhenClosed = false
        w.backgroundColor = .black
        w.delegate = self
        if windowed {
            w.titlebarAppearsTransparent = true
            w.titleVisibility = .hidden
            w.isMovableByWindowBackground = true
            w.level = .normal
            w.collectionBehavior = [.fullScreenPrimary]
            w.minSize = NSSize(width: 200, height: 100)
            w.standardWindowButton(.closeButton)?.isHidden = true
        } else {
            w.level = fullScreenDisplayLevel
            w.collectionBehavior = [.canJoinAllSpaces, .stationary, .ignoresCycle, .fullScreenAuxiliary]
            w.hasShadow = false
        }
        model.clockAppearDate = Date()
        let host = CursorHidingContainer(content: unconstrainedHostingView(TimerOutputView(model: model)))
        w.contentView = host
        hostingView = host
        window = w
        return w
    }

    private func beginActivity() {
        if activity == nil {
            activity = ProcessInfo.processInfo.beginActivity(
                options: [.idleDisplaySleepDisabled, .userInitiated],
                reason: "OnlyT timer display")
        }
    }

    private func endActivity() {
        if let a = activity {
            ProcessInfo.processInfo.endActivity(a)
            activity = nil
        }
    }

    // the window can't be closed independently of the application
    func windowShouldClose(_ sender: NSWindow) -> Bool {
        false
    }

    func windowDidEndLiveResize(_ notification: Notification) {
        saveWindowedFrame()
    }

    func windowDidMove(_ notification: Notification) {
        saveWindowedFrame()
    }
}

/// Manages the countdown window (port of CountdownOutputDisplayService).
@MainActor
final class CountdownController: NSObject, NSWindowDelegate {
    let model: CountdownModel
    var optionsProvider: () -> Options = { Options() }
    var onFrameSaved: ((String) -> Void)?

    private(set) var window: OutputWindow?
    private var hostingView: CursorHidingContainer?

    init(model: CountdownModel) {
        self.model = model
    }

    var isVisible: Bool { window?.isVisible ?? false }

    var screen: NSScreen? {
        guard let w = window, w.isVisible, !model.windowed else {
            return nil
        }
        return w.screen
    }

    /// Opens the countdown window; returns false if it can't be shown.
    @discardableResult
    func open() -> Bool {
        let o = optionsProvider()
        if o.countdownMonitorIsWindowed {
            return openWindowed()
        }
        return openInMonitor()
    }

    func openInMonitor() -> Bool {
        let o = optionsProvider()
        guard let screen = Screens.screen(for: o.countdownMonitorId) else {
            return false
        }
        let w = makeWindow(windowed: false, transparent: o.isCountdownWindowTransparent)
        model.windowed = false
        w.setFrame(screen.frame, display: true)
        w.orderFrontRegardless()
        hostingView?.hidePointer = !o.showMousePointerInTimerDisplay
        return true
    }

    func openWindowed() -> Bool {
        let o = optionsProvider()
        let w = makeWindow(windowed: true, transparent: false)
        model.windowed = true
        var frame = NSRect(x: 60, y: 60, width: 640, height: 360)
        if let s = o.countdownWindowFrame {
            let r = NSRectFromString(s)
            if r.width > 50 && r.height > 50 {
                frame = r
            }
        } else if let visible = NSScreen.main?.visibleFrame {
            frame.origin = NSPoint(x: visible.midX - frame.width / 2, y: visible.midY - frame.height / 2)
        }
        w.setFrame(frame, display: true)
        w.orderFrontRegardless()
        hostingView?.hidePointer = !o.showMousePointerInTimerDisplay
        return true
    }

    func hide() {
        window?.orderOut(nil)
    }

    func close() {
        saveWindowedFrame()
        hostingView?.releaseCursor()
        window?.delegate = nil
        window?.orderOut(nil)
        window = nil
        hostingView = nil
    }

    func saveWindowedFrame() {
        if let w = window, model.windowed {
            onFrameSaved?(NSStringFromRect(w.frame))
        }
    }

    private func makeWindow(windowed: Bool, transparent: Bool) -> OutputWindow {
        if let existing = window {
            saveWindowedFrame()
            existing.delegate = nil
            existing.orderOut(nil)
            hostingView?.releaseCursor()
        }
        let style: NSWindow.StyleMask = windowed
            ? [.titled, .resizable, .fullSizeContentView]
            : [.borderless]
        let w = OutputWindow(contentRect: NSRect(x: 0, y: 0, width: 640, height: 360), styleMask: style, backing: .buffered, defer: false)
        w.title = L10n.t("MAC_COUNTDOWN_TITLE")
        w.isReleasedWhenClosed = false
        w.delegate = self
        if transparent {
            w.isOpaque = false
            w.backgroundColor = .clear
        } else {
            w.backgroundColor = .black
        }
        if windowed {
            w.titlebarAppearsTransparent = true
            w.titleVisibility = .hidden
            w.isMovableByWindowBackground = true
            w.level = .floating
            w.minSize = NSSize(width: 200, height: 100)
            w.standardWindowButton(.closeButton)?.isHidden = true
        } else {
            w.level = NSWindow.Level(rawValue: fullScreenDisplayLevel.rawValue + 1)
            w.collectionBehavior = [.canJoinAllSpaces, .stationary, .ignoresCycle, .fullScreenAuxiliary]
            w.hasShadow = false
        }
        let host = CursorHidingContainer(content: unconstrainedHostingView(CountdownOutputView(model: model)))
        w.contentView = host
        hostingView = host
        window = w
        return w
    }

    func windowShouldClose(_ sender: NSWindow) -> Bool {
        false
    }

    func windowDidEndLiveResize(_ notification: Notification) {
        saveWindowedFrame()
    }

    func windowDidMove(_ notification: Notification) {
        saveWindowedFrame()
    }
}
