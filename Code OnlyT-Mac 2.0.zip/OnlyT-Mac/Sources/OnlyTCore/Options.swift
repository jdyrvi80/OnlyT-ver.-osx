import Foundation

// MARK: - Enums

public enum OperatingMode: Int, Codable, CaseIterable, Identifiable {
    case manual = 0
    case scheduleFile = 1
    case automatic = 2

    public var id: Int { rawValue }

    public var title: String {
        switch self {
        case .automatic: return L10n.t("OP_MODE_AUTO")
        case .manual: return L10n.t("OP_MODE_MANUAL")
        case .scheduleFile: return L10n.t("OP_MODE_FILE")
        }
    }
}

public enum MidWeekOrWeekend: Int, Codable, CaseIterable, Identifiable {
    case unknown = 0
    case midWeek = 1
    case weekend = 2

    public var id: Int { rawValue }

    public var title: String {
        switch self {
        case .unknown: return "-"
        case .midWeek: return L10n.t("MIDWEEK")
        case .weekend: return L10n.t("WEEKEND")
        }
    }
}

public enum AdaptiveMode: Int, Codable, CaseIterable, Identifiable {
    case none = 0
    case oneWay = 1
    case twoWay = 2

    public var id: Int { rawValue }

    public var title: String {
        switch self {
        case .none: return L10n.t("ADAPTIVE_MODE_NONE")
        case .oneWay: return L10n.t("ADAPTIVE_MODE_ONE_WAY")
        case .twoWay: return L10n.t("ADAPTIVE_MODE_TWO_WAY")
        }
    }
}

public enum ClockHourFormat: Int, Codable, CaseIterable, Identifiable {
    case format12 = 0
    case format12LeadingZero = 1
    case format24 = 2
    case format24LeadingZero = 3
    case format12AMPM = 4
    case format12LeadingZeroAMPM = 5

    public var id: Int { rawValue }

    public var title: String {
        switch self {
        case .format12: return L10n.t("CLOCK_FORMAT_12")
        case .format12LeadingZero: return L10n.t("CLOCK_FORMAT_12Z")
        case .format24: return L10n.t("CLOCK_FORMAT_24")
        case .format24LeadingZero: return L10n.t("CLOCK_FORMAT_24Z")
        case .format12AMPM: return L10n.t("CLOCK_FORMAT_12AMPM")
        case .format12LeadingZeroAMPM: return L10n.t("CLOCK_FORMAT_12ZAMPM")
        }
    }

    public var is24Hour: Bool { self == .format24 || self == .format24LeadingZero }

    public var leadingZero: Bool {
        self == .format12LeadingZero || self == .format24LeadingZero || self == .format12LeadingZeroAMPM
    }

    public var showsAMPM: Bool { self == .format12AMPM || self == .format12LeadingZeroAMPM }

    /// Default format according to the user's locale (as the original does).
    public static func defaultForLocale(_ locale: Locale = .current) -> ClockHourFormat {
        let pattern = DateFormatter.dateFormat(fromTemplate: "jms", options: 0, locale: locale) ?? "HH:mm:ss"
        let clock24 = pattern.contains("H")
        let leadingZero = pattern.contains("HH") || pattern.contains("hh")
        if clock24 {
            return leadingZero ? .format24LeadingZero : .format24
        }
        let ampm = pattern.contains("a")
        if leadingZero {
            return ampm ? .format12LeadingZeroAMPM : .format12LeadingZero
        }
        return ampm ? .format12AMPM : .format12
    }

    /// Formats the time of day ("hours:minutes" + optional am/pm) as the analogue clock control does.
    public func formatHoursMinutes(_ date: Date, calendar: Calendar = .current) -> String {
        let c = calendar.dateComponents([.hour, .minute], from: date)
        let hour = c.hour ?? 0
        let minute = c.minute ?? 0
        let twelve = hour > 12 ? hour - 12 : hour
        let hours = is24Hour ? hour : twelve
        var suffix = ""
        if showsAMPM {
            suffix = " " + (hour < 12 ? (calendar.amSymbol) : (calendar.pmSymbol))
        }
        if leadingZero {
            return String(format: "%02d:%02d", hours, minute) + suffix
        }
        return "\(hours):" + String(format: "%02d", minute) + suffix
    }

    /// Seconds string ("" when using am/pm, like the original).
    public func formatSeconds(_ date: Date, calendar: Calendar = .current) -> String {
        if showsAMPM {
            return ""
        }
        return String(format: "%02d", calendar.component(.second, from: date))
    }
}

public enum FullScreenClockMode: Int, Codable, CaseIterable, Identifiable {
    case analogue = 0
    case digital = 1
    case analogueAndDigital = 2

    public var id: Int { rawValue }

    public var title: String {
        switch self {
        case .analogue: return L10n.t("FULL_SCREEN_ANALOGUE")
        case .digital: return L10n.t("FULL_SCREEN_DIGITAL")
        case .analogueAndDigital: return L10n.t("FULL_SCREEN_BOTH")
        }
    }
}

public enum ScreenLocation: Int, Codable, CaseIterable, Identifiable {
    case centre = 0
    case left, top, right, bottom, topLeft, topRight, bottomLeft, bottomRight

    public var id: Int { rawValue }

    public var title: String {
        switch self {
        case .centre: return L10n.t("SCREEN_LOCATION_CENTRE")
        case .left: return L10n.t("SCREEN_LOCATION_LEFT")
        case .top: return L10n.t("SCREEN_LOCATION_TOP")
        case .right: return L10n.t("SCREEN_LOCATION_RIGHT")
        case .bottom: return L10n.t("SCREEN_LOCATION_BOTTOM")
        case .topLeft: return L10n.t("SCREEN_LOCATION_TOP_LEFT")
        case .topRight: return L10n.t("SCREEN_LOCATION_TOP_RIGHT")
        case .bottomLeft: return L10n.t("SCREEN_LOCATION_BOTTOM_LEFT")
        case .bottomRight: return L10n.t("SCREEN_LOCATION_BOTTOM_RIGHT")
        }
    }

    /// -1 = left, 0 = centre, 1 = right
    public var horizontal: Int {
        switch self {
        case .left, .topLeft, .bottomLeft: return -1
        case .right, .topRight, .bottomRight: return 1
        default: return 0
        }
    }

    /// -1 = top, 0 = centre, 1 = bottom
    public var vertical: Int {
        switch self {
        case .top, .topLeft, .topRight: return -1
        case .bottom, .bottomLeft, .bottomRight: return 1
        default: return 0
        }
    }
}

public enum CountdownElements: Int, Codable, CaseIterable, Identifiable {
    case dialAndDigital = 0
    case dial = 1
    case digital = 2

    public var id: Int { rawValue }

    public var title: String {
        switch self {
        case .dialAndDigital: return L10n.t("DIAL_AND_DIGITAL")
        case .dial: return L10n.t("DIAL")
        case .digital: return L10n.t("DIGITAL")
        }
    }
}

// MARK: - Meeting start times

public struct MeetingStartTime: Codable, Equatable {
    /// Calendar weekday (1 = Sunday ... 7 = Saturday) or nil for "every day".
    public var dayOfWeek: Int?
    /// Minutes after midnight.
    public var startMinutes: Int

    public init(dayOfWeek: Int?, startMinutes: Int) {
        self.dayOfWeek = dayOfWeek
        self.startMinutes = startMinutes
    }

    public mutating func sanitize() {
        if startMinutes > 24 * 60 {
            startMinutes = 24 * 60
        }
        if startMinutes < 0 {
            startMinutes = 0
        }
    }

    public func asText(locale: Locale = .current) -> String {
        let time = String(format: "%02d:%02d", startMinutes / 60, startMinutes % 60)
        if let dow = dayOfWeek {
            var cal = Calendar(identifier: .gregorian)
            cal.locale = locale
            let names = cal.shortWeekdaySymbols
            if dow >= 1 && dow <= names.count {
                return "\(names[dow - 1]) \(time)"
            }
        }
        return time
    }

    /// Parses lines such as "19:15", "Thu 19:15", "giovedì 7.15pm", "1915".
    public static func fromText(_ input: String, locale: Locale = .current) -> MeetingStartTime? {
        var text = input
        var dow: Int?
        if let found = findDayOfWeek(text, locale: locale) {
            dow = found.weekday
            if let range = text.range(of: found.name, options: .caseInsensitive) {
                text.removeSubrange(range)
            }
        }
        guard let minutes = timeOfDay(text, locale: locale) else {
            return nil
        }
        return MeetingStartTime(dayOfWeek: dow, startMinutes: minutes)
    }

    private static func timeOfDay(_ text: String, locale: Locale) -> Int? {
        let digits = text.filter { $0.isASCII && $0.isNumber }.compactMap { Int(String($0)) }
        guard !digits.isEmpty && digits.count < 5 else {
            return nil
        }
        var hour: Int
        var mins: Int
        switch digits.count {
        case 1:
            hour = digits[0]
            mins = 0
        case 2:
            hour = digits[0] * 10 + digits[1]
            mins = 0
        case 3:
            hour = digits[0]
            mins = digits[1] * 10 + digits[2]
        default:
            hour = digits[0] * 10 + digits[1]
            mins = digits[2] * 10 + digits[3]
        }
        if hour < 12 && hasPM(text, locale: locale) {
            hour += 12
        }
        if hour >= 0 && mins >= 0 && mins < 60 && hour <= 24 {
            return hour * 60 + mins
        }
        return nil
    }

    private static func hasPM(_ text: String, locale: Locale) -> Bool {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        var cal = Calendar(identifier: .gregorian)
        cal.locale = locale
        let candidates = [cal.pmSymbol.lowercased(), "pm", "p.m."]
        return candidates.contains { !$0.isEmpty && trimmed.hasSuffix($0) }
    }

    private static func findDayOfWeek(_ text: String, locale: Locale) -> (weekday: Int, name: String)? {
        var current = Calendar(identifier: .gregorian)
        current.locale = locale
        var invariant = Calendar(identifier: .gregorian)
        invariant.locale = Locale(identifier: "en_US_POSIX")

        let lists: [[String]] = [
            current.weekdaySymbols,
            invariant.weekdaySymbols,
            current.shortWeekdaySymbols.map { $0.replacingOccurrences(of: ".", with: "") },
            invariant.shortWeekdaySymbols,
            current.weekdaySymbols.map { String($0.prefix(2)) },
            invariant.weekdaySymbols.map { String($0.prefix(2)) },
        ]

        for list in lists {
            for (index, name) in list.enumerated() where !name.isEmpty {
                if text.range(of: name, options: .caseInsensitive) != nil {
                    return (index + 1, name)
                }
            }
        }
        return nil
    }
}

public enum MeetingStartTimes {
    public static func parse(_ text: String, locale: Locale = .current) -> [MeetingStartTime] {
        text.components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
            .compactMap { MeetingStartTime.fromText($0, locale: locale) }
    }

    public static func asText(_ times: [MeetingStartTime], locale: Locale = .current) -> String {
        times.map { $0.asText(locale: locale) }.joined(separator: "\n")
    }
}

// MARK: - Options

/// All program options, persisted as JSON (like the original options.json).
public struct Options: Codable, Equatable {
    public static let defaultPort = 8096
    public static let maxPossiblePorts = 0x80
    public static let defaultCountdownDurationMins = 5
    public static let defaultFeedUri = "https://soundbox.blob.core.windows.net/meeting-feeds/feed.json"

    // displays
    public var timerMonitorId: String?
    public var countdownMonitorId: String?
    public var mainMonitorIsWindowed = false
    public var countdownMonitorIsWindowed = false
    public var timerWindowFrame: String?
    public var countdownWindowFrame: String?

    // countdown
    public var countdownFrame = true
    public var countdownElementsToShow: CountdownElements = .dialAndDigital
    public var countdownScreenLocation: ScreenLocation = .centre
    public var countdownZoomPercent = 100
    public var countdownDurationMins = Options.defaultCountdownDurationMins
    public var isCountdownWindowTransparent = false
    public var meetingStartTimes: [MeetingStartTime] = []

    // timer window
    public var showBackgroundOnTimer = false
    public var showBackgroundOnClock = true
    public var timerFrame = true
    public var clockTimerFrame = false
    public var fullScreenClockMode: FullScreenClockMode = .analogueAndDigital
    public var analogueClockWidthPercent = 50
    public var showTimeOfDayUnderTimer = false
    public var showDurationSector = true
    public var showMousePointerInTimerDisplay = false
    public var clockIsFlat = false
    public var clockHourFormat: ClockHourFormat = ClockHourFormat.defaultForLocale()
    public var showDigitalSeconds = true
    public var persistDurationSecs = 90
    public var countUp = false

    // operating mode
    public var operatingMode: OperatingMode = .automatic
    public var scheduleFile: String?
    public var midWeekOrWeekend: MidWeekOrWeekend = .unknown
    public var isCircuitVisit = false
    public var showCircuitVisitToggle = false
    public var persistStudentTime = true
    public var showPersistCountdown = false
    public var midWeekAdaptiveMode: AdaptiveMode = .none
    public var weekendAdaptiveMode: AdaptiveMode = .none
    public var weekendIncludesFriday = false
    public var generateTimingReports = false
    public var feedUri: String = Options.defaultFeedUri

    // bell
    public var isBellEnabled = true
    public var autoBell = true
    public var bellVolumePercent = 70

    // web
    public var httpServerPort = Options.defaultPort
    public var isWebClockEnabled = false
    public var webClockShowTimeOfDaySeconds = false
    public var isApiEnabled = false
    public var apiCode: String?
    public var isApiThrottled = true

    // misc
    public var alwaysOnTop = true
    public var shrinkOnMinimise = true
    public var timerReminder = true
    public var overrunNotifications = false
    public var darkModeToggle = false
    public var allowCountUpToggle = false
    public var showPauseButton = false
    public var allowMouseWheelTimerAdjust = false
    public var culture: String?

    public init() {}

    // Tolerant decoding: every missing key falls back to its default value.
    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        let d = Options()

        func v<T: Decodable>(_ key: CodingKeys, _ def: T) -> T {
            (try? c.decodeIfPresent(T.self, forKey: key)) .flatMap { $0 } ?? def
        }

        timerMonitorId = v(.timerMonitorId, d.timerMonitorId)
        countdownMonitorId = v(.countdownMonitorId, d.countdownMonitorId)
        mainMonitorIsWindowed = v(.mainMonitorIsWindowed, d.mainMonitorIsWindowed)
        countdownMonitorIsWindowed = v(.countdownMonitorIsWindowed, d.countdownMonitorIsWindowed)
        timerWindowFrame = v(.timerWindowFrame, d.timerWindowFrame)
        countdownWindowFrame = v(.countdownWindowFrame, d.countdownWindowFrame)

        countdownFrame = v(.countdownFrame, d.countdownFrame)
        countdownElementsToShow = v(.countdownElementsToShow, d.countdownElementsToShow)
        countdownScreenLocation = v(.countdownScreenLocation, d.countdownScreenLocation)
        countdownZoomPercent = v(.countdownZoomPercent, d.countdownZoomPercent)
        countdownDurationMins = v(.countdownDurationMins, d.countdownDurationMins)
        isCountdownWindowTransparent = v(.isCountdownWindowTransparent, d.isCountdownWindowTransparent)
        meetingStartTimes = v(.meetingStartTimes, d.meetingStartTimes)

        showBackgroundOnTimer = v(.showBackgroundOnTimer, d.showBackgroundOnTimer)
        showBackgroundOnClock = v(.showBackgroundOnClock, d.showBackgroundOnClock)
        timerFrame = v(.timerFrame, d.timerFrame)
        clockTimerFrame = v(.clockTimerFrame, d.clockTimerFrame)
        fullScreenClockMode = v(.fullScreenClockMode, d.fullScreenClockMode)
        analogueClockWidthPercent = v(.analogueClockWidthPercent, d.analogueClockWidthPercent)
        showTimeOfDayUnderTimer = v(.showTimeOfDayUnderTimer, d.showTimeOfDayUnderTimer)
        showDurationSector = v(.showDurationSector, d.showDurationSector)
        showMousePointerInTimerDisplay = v(.showMousePointerInTimerDisplay, d.showMousePointerInTimerDisplay)
        clockIsFlat = v(.clockIsFlat, d.clockIsFlat)
        clockHourFormat = v(.clockHourFormat, d.clockHourFormat)
        showDigitalSeconds = v(.showDigitalSeconds, d.showDigitalSeconds)
        persistDurationSecs = v(.persistDurationSecs, d.persistDurationSecs)
        countUp = v(.countUp, d.countUp)

        operatingMode = v(.operatingMode, d.operatingMode)
        scheduleFile = v(.scheduleFile, d.scheduleFile)
        midWeekOrWeekend = v(.midWeekOrWeekend, d.midWeekOrWeekend)
        isCircuitVisit = v(.isCircuitVisit, d.isCircuitVisit)
        showCircuitVisitToggle = v(.showCircuitVisitToggle, d.showCircuitVisitToggle)
        persistStudentTime = v(.persistStudentTime, d.persistStudentTime)
        showPersistCountdown = v(.showPersistCountdown, d.showPersistCountdown)
        midWeekAdaptiveMode = v(.midWeekAdaptiveMode, d.midWeekAdaptiveMode)
        weekendAdaptiveMode = v(.weekendAdaptiveMode, d.weekendAdaptiveMode)
        weekendIncludesFriday = v(.weekendIncludesFriday, d.weekendIncludesFriday)
        generateTimingReports = v(.generateTimingReports, d.generateTimingReports)
        feedUri = v(.feedUri, d.feedUri)

        isBellEnabled = v(.isBellEnabled, d.isBellEnabled)
        autoBell = v(.autoBell, d.autoBell)
        bellVolumePercent = v(.bellVolumePercent, d.bellVolumePercent)

        httpServerPort = v(.httpServerPort, d.httpServerPort)
        isWebClockEnabled = v(.isWebClockEnabled, d.isWebClockEnabled)
        webClockShowTimeOfDaySeconds = v(.webClockShowTimeOfDaySeconds, d.webClockShowTimeOfDaySeconds)
        isApiEnabled = v(.isApiEnabled, d.isApiEnabled)
        apiCode = v(.apiCode, d.apiCode)
        isApiThrottled = v(.isApiThrottled, d.isApiThrottled)

        alwaysOnTop = v(.alwaysOnTop, d.alwaysOnTop)
        shrinkOnMinimise = v(.shrinkOnMinimise, d.shrinkOnMinimise)
        timerReminder = v(.timerReminder, d.timerReminder)
        overrunNotifications = v(.overrunNotifications, d.overrunNotifications)
        darkModeToggle = v(.darkModeToggle, d.darkModeToggle)
        allowCountUpToggle = v(.allowCountUpToggle, d.allowCountUpToggle)
        showPauseButton = v(.showPauseButton, d.showPauseButton)
        allowMouseWheelTimerAdjust = v(.allowMouseWheelTimerAdjust, d.allowMouseWheelTimerAdjust)
        culture = v(.culture, d.culture)

        sanitize()
    }

    // MARK: helpers

    public static let countdownDurationItems: [Int] = Array(1...30) + [45, 60]

    public static let persistDurationItems: [Int] = (1...11).map { $0 * 15 }

    public static var portItems: [Int] {
        Array(defaultPort...(defaultPort + maxPossiblePorts))
    }

    /// Validates the data, correcting automatically as required.
    public mutating func sanitize() {
        bellVolumePercent = min(max(bellVolumePercent, 0), 100)
        if analogueClockWidthPercent < 0 || analogueClockWidthPercent > 100 {
            analogueClockWidthPercent = 50
        }
        countdownZoomPercent = min(max(countdownZoomPercent, 10), 100)
        if !Options.countdownDurationItems.contains(countdownDurationMins) {
            countdownDurationMins = Options.defaultCountdownDurationMins
        }
        if httpServerPort < Options.defaultPort || httpServerPort > Options.defaultPort + Options.maxPossiblePorts {
            httpServerPort = Options.defaultPort
        }
        if !Options.persistDurationItems.contains(persistDurationSecs) {
            persistDurationSecs = Options.persistDurationItems[Options.persistDurationItems.count / 2]
        }
        for i in meetingStartTimes.indices {
            meetingStartTimes[i].sanitize()
        }
        if feedUri.trimmingCharacters(in: .whitespaces).isEmpty || URL(string: feedUri)?.scheme == nil {
            feedUri = Options.defaultFeedUri
        }
    }

    /// The adaptive mode in force (only in Automatic mode).
    public var effectiveAdaptiveMode: AdaptiveMode {
        guard operatingMode == .automatic else {
            return .none
        }
        switch midWeekOrWeekend {
        case .midWeek: return midWeekAdaptiveMode
        case .weekend: return weekendAdaptiveMode
        case .unknown: return .none
        }
    }

    public var use24HourClock: Bool {
        clockHourFormat.is24Hour
    }

    public var canDisplayTimerWindow: Bool {
        mainMonitorIsWindowed || !(timerMonitorId ?? "").isEmpty
    }

    public var canDisplayCountdownWindow: Bool {
        countdownMonitorIsWindowed || !(countdownMonitorId ?? "").isEmpty
    }
}

// MARK: - Persistence

public final class OptionsStore {
    public let fileURL: URL
    public private(set) var options: Options

    public init(fileURL: URL) {
        self.fileURL = fileURL
        if let data = try? Data(contentsOf: fileURL),
           let decoded = try? JSONDecoder().decode(Options.self, from: data) {
            options = decoded
        } else {
            options = Options()
        }
    }

    public func update(_ newOptions: Options) {
        options = newOptions
        save()
    }

    public func save() {
        do {
            try FileManager.default.createDirectory(at: fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            let enc = JSONEncoder()
            enc.outputFormatting = [.prettyPrinted, .sortedKeys]
            let data = try enc.encode(options)
            try data.write(to: fileURL, options: .atomic)
        } catch {
            NSLog("OnlyT: could not save options: \(error)")
        }
    }
}
