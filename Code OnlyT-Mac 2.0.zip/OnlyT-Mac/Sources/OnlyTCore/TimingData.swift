import Foundation

/// A timed item of a meeting (for the timing reports).
public struct MeetingTimedItem: Codable, Equatable {
    public var description: String
    /// Seconds after midnight.
    public var start: Int
    /// Seconds after midnight (nil while still running).
    public var end: Int?
    public var isSongSegment: Bool
    public var plannedDuration: Int
    public var adaptedDuration: Int
    public var isStudentTalk: Bool
}

/// Timing data of one meeting (port of OnlyT.Report MeetingTimes).
public struct MeetingTimes: Codable, Equatable {
    public var session: UUID
    /// Start of day of the meeting.
    public var meetingDate: Date?
    public var meetingStart: Int?
    public var meetingActualEnd: Int?
    public var meetingPlannedEnd: Int?
    public var items: [MeetingTimedItem]
    public var lastTimerStop: Date?

    public init() {
        session = UUID()
        items = []
    }

    public var meetingOvertime: TimeInterval? {
        guard let actual = meetingActualEnd, let planned = meetingPlannedEnd else {
            return nil
        }
        return TimeInterval(actual - planned)
    }

    mutating func initMeetingDate(_ now: Date, _ calendar: Calendar) {
        if meetingDate == nil {
            meetingDate = calendar.startOfDay(for: now)
        }
    }

    public mutating func insertPlannedMeetingEnd(_ date: Date, calendar: Calendar = .current) {
        meetingPlannedEnd = DateUtils.secondsIntoDay(date, calendar: calendar)
    }

    public mutating func insertMeetingStart(_ date: Date, calendar: Calendar = .current) {
        initMeetingDate(date, calendar)
        meetingStart = DateUtils.secondsIntoDay(date, calendar: calendar)
    }

    public mutating func insertActualMeetingEnd(_ date: Date, calendar: Calendar = .current) {
        initMeetingDate(date, calendar)
        meetingActualEnd = DateUtils.secondsIntoDay(date, calendar: calendar)
    }

    public mutating func insertSongSegment(start: Date, description: String, duration: TimeInterval, now: Date, calendar: Calendar = .current) {
        insertSongTime(start: start, description: description, duration: duration, now: now, calendar: calendar)
        insertTimerStop(description: description, isStudentTalk: false, at: now, calendar: calendar)
    }

    public mutating func insertConcludingSongSegment(start: Date, end: Date, description: String, duration: TimeInterval, calendar: Calendar = .current) {
        insertSongTime(start: start, description: description, duration: duration, now: start, calendar: calendar)
        insertTimerStop(description: description, isStudentTalk: false, at: end, calendar: calendar)
    }

    public mutating func insertTimerStart(description: String, isSongSegment: Bool, isStudentTalk: Bool,
                                          plannedDuration: TimeInterval, adaptedDuration: TimeInterval,
                                          now: Date, calendar: Calendar = .current) {
        initMeetingDate(now, calendar)
        items.append(MeetingTimedItem(
            description: description,
            start: DateUtils.secondsIntoDay(now, calendar: calendar),
            end: nil,
            isSongSegment: isSongSegment,
            plannedDuration: Int(plannedDuration.rounded()),
            adaptedDuration: Int(adaptedDuration.rounded()),
            isStudentTalk: isStudentTalk))
    }

    public mutating func insertTimerStop(description: String?, isStudentTalk: Bool, at date: Date, calendar: Calendar = .current) {
        initMeetingDate(date, calendar)
        guard let description = description,
              let index = items.firstIndex(where: { $0.description == description && $0.isStudentTalk == isStudentTalk && $0.end == nil }) else {
            return
        }
        let end = DateUtils.secondsIntoDay(date, calendar: calendar)
        items[index].end = end
        if let day = meetingDate {
            lastTimerStop = day.addingTimeInterval(TimeInterval(end))
        }
    }

    public mutating func purge() {
        meetingDate = nil
        meetingStart = nil
        meetingActualEnd = nil
        meetingPlannedEnd = nil
        items.removeAll()
    }

    private mutating func insertSongTime(start: Date, description: String, duration: TimeInterval, now: Date, calendar: Calendar) {
        initMeetingDate(now, calendar)
        items.append(MeetingTimedItem(
            description: description,
            start: DateUtils.secondsIntoDay(start, calendar: calendar),
            end: nil,
            isSongSegment: true,
            plannedDuration: Int(duration.rounded()),
            adaptedDuration: Int(duration.rounded()),
            isStudentTalk: false))
    }
}

public struct MeetingTimeSummary: Equatable {
    public var meetingDate: Date
    public var overtime: TimeInterval
}

/// Stores the timing data of meetings in a JSON file (replaces LiteDB).
public final class TimingDataStore {
    static let meetingMinsOutOfRange: Double = 20
    static let historicalMonths = 6

    public let fileURL: URL
    public private(set) var current = MeetingTimes()
    private var currentPartDescription: String?
    private var currentPartIsStudentTalk = false
    private let calendar: Calendar

    public init(fileURL: URL, calendar: Calendar = .current) {
        self.fileURL = fileURL
        self.calendar = calendar
    }

    public var lastTimerStop: Date {
        current.lastTimerStop ?? .distantPast
    }

    public func insertMeetingStart(_ d: Date) { current.insertMeetingStart(d, calendar: calendar) }

    public func insertPlannedMeetingEnd(_ d: Date) { current.insertPlannedMeetingEnd(d, calendar: calendar) }

    public func insertActualMeetingEnd(_ d: Date) { current.insertActualMeetingEnd(d, calendar: calendar) }

    public func insertSongSegment(start: Date, description: String, duration: TimeInterval, now: Date) {
        current.insertSongSegment(start: start, description: description, duration: duration, now: now, calendar: calendar)
    }

    public func insertConcludingSongSegment(start: Date, end: Date, description: String, duration: TimeInterval) {
        current.insertConcludingSongSegment(start: start, end: end, description: description, duration: duration, calendar: calendar)
    }

    public func insertTimerStart(description: String, isSongSegment: Bool, isStudentTalk: Bool,
                                 plannedDuration: TimeInterval, adaptedDuration: TimeInterval, now: Date) {
        currentPartDescription = description
        currentPartIsStudentTalk = isStudentTalk
        current.insertTimerStart(description: description, isSongSegment: isSongSegment, isStudentTalk: isStudentTalk,
                                 plannedDuration: plannedDuration, adaptedDuration: adaptedDuration, now: now, calendar: calendar)
    }

    public func insertTimerStop(now: Date) {
        current.insertTimerStop(description: currentPartDescription, isStudentTalk: currentPartIsStudentTalk, at: now, calendar: calendar)
        currentPartDescription = nil
        currentPartIsStudentTalk = false
    }

    public func validCurrentMeetingTimes() -> Bool {
        guard current.meetingStart != nil, current.meetingActualEnd != nil, let overtime = current.meetingOvertime else {
            return false
        }
        return abs(overtime / 60) < TimingDataStore.meetingMinsOutOfRange
    }

    public func purgeCurrent() {
        current.purge()
    }

    /// Starts a new meeting session (after the report of the previous one).
    public func startNewSession() {
        current = MeetingTimes()
        currentPartDescription = nil
        currentPartIsStudentTalk = false
    }

    // MARK: persistence

    public func loadAll() -> [MeetingTimes] {
        guard let data = try? Data(contentsOf: fileURL) else {
            return []
        }
        let dec = JSONDecoder()
        dec.dateDecodingStrategy = .iso8601
        return (try? dec.decode([MeetingTimes].self, from: data)) ?? []
    }

    public func save() {
        var all = loadAll()
        if let i = all.firstIndex(where: { $0.session == current.session }) {
            all[i] = current
        } else {
            all.append(current)
        }
        write(all)
    }

    public func deleteAll() {
        write([])
    }

    private func write(_ all: [MeetingTimes]) {
        do {
            try FileManager.default.createDirectory(at: fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            let enc = JSONEncoder()
            enc.dateEncodingStrategy = .iso8601
            enc.outputFormatting = [.prettyPrinted]
            try enc.encode(all).write(to: fileURL, options: .atomic)
        } catch {
            NSLog("OnlyT: could not save timing data: \(error)")
        }
    }

    /// Summaries of the last 6 months (for the historical chart of the report).
    public func historicalSummaries(upTo date: Date) -> [MeetingTimeSummary] {
        let end = calendar.startOfDay(for: date).addingTimeInterval(86_400)
        let start = calendar.date(byAdding: .month, value: -TimingDataStore.historicalMonths, to: calendar.startOfDay(for: date)) ?? date
        return loadAll()
            .compactMap { m -> MeetingTimeSummary? in
                guard let d = m.meetingDate, d >= start, d < end, let o = m.meetingOvertime else {
                    return nil
                }
                return MeetingTimeSummary(meetingDate: d, overtime: o)
            }
            .sorted { $0.meetingDate < $1.meetingDate }
    }
}
