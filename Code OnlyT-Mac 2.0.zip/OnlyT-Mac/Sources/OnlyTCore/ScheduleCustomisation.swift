import Foundation

// MARK: - Edited ("custom") schedules
//
// Not in the Windows version: the user can add, edit, delete and reorder the parts
// of the current schedule. The edited schedule replaces the generated one for the
// same context (automatic mode: meeting type + week; file mode: file; manual mode)
// until the user restores the original.

/// A part of an edited schedule, as stored on disk.
public struct CustomTalkItem: Codable, Equatable {
    public var id: Int
    public var name: String
    public var sectionInternal: String
    public var sectionLocalised: String
    public var durationSecs: Int
    public var startOffsetSecs: Int
    public var editable: Bool
    public var bellApplicable: Bool
    public var countUp: Bool?
    public var persistFinalTimerValue: Bool
    public var closingSecs: Int
    public var isStudentTalk: Bool
    public var allowAdaptive: Bool

    public init(_ t: TalkScheduleItem) {
        id = t.id
        name = t.name
        sectionInternal = t.meetingSectionNameInternal
        sectionLocalised = t.meetingSectionNameLocalised
        durationSecs = Int(t.originalDuration)
        startOffsetSecs = Int(t.startOffsetIntoMeeting)
        editable = t.editable
        bellApplicable = t.bellApplicable
        countUp = t.countUp
        persistFinalTimerValue = t.persistFinalTimerValue
        closingSecs = t.closingSecs
        isStudentTalk = t.isStudentTalk
        allowAdaptive = t.allowAdaptive
    }

    public func makeItem(autoBell: Bool) -> TalkScheduleItem {
        let t = TalkScheduleItem(id: id, name: name, sectionInternal: sectionInternal, sectionLocalised: sectionLocalised)
        t.originalDuration = TimeInterval(durationSecs)
        t.startOffsetIntoMeeting = TimeInterval(startOffsetSecs)
        t.editable = editable
        t.bellApplicable = bellApplicable
        t.autoBell = autoBell
        t.countUp = countUp
        t.persistFinalTimerValue = persistFinalTimerValue
        t.closingSecs = closingSecs
        t.isStudentTalk = isStudentTalk
        t.allowAdaptive = allowAdaptive
        return t
    }
}

/// Stores the edited schedules (JSON file), keyed by schedule context.
public final class CustomScheduleStore {
    public struct Entry: Codable {
        public var saved: Date
        public var items: [CustomTalkItem]
    }

    /// Edited automatic-mode schedules are forgotten after this many days.
    static let autoEntryMaxAgeDays: Double = 60

    public let fileURL: URL
    private var entries: [String: Entry] = [:]

    public init(fileURL: URL) {
        self.fileURL = fileURL
        if let data = try? Data(contentsOf: fileURL),
           let decoded = try? JSONDecoder().decode([String: Entry].self, from: data) {
            entries = decoded
        }
    }

    public func items(for key: String) -> [CustomTalkItem]? {
        entries[key]?.items
    }

    /// Saves (or, with nil, removes) the edited schedule of a context.
    public func set(_ items: [CustomTalkItem]?, for key: String, now: Date = Date()) {
        if let items = items, !items.isEmpty {
            entries[key] = Entry(saved: now, items: items)
        } else {
            entries.removeValue(forKey: key)
        }
        entries = entries.filter { key, entry in
            !key.hasPrefix("auto|") || now.timeIntervalSince(entry.saved) / 86_400 <= CustomScheduleStore.autoEntryMaxAgeDays
        }
        save()
    }

    private func save() {
        do {
            try FileManager.default.createDirectory(at: fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            let enc = JSONEncoder()
            enc.outputFormatting = [.prettyPrinted, .sortedKeys]
            try enc.encode(entries).write(to: fileURL, options: .atomic)
        } catch {
            NSLog("OnlyT: could not save the edited schedules: \(error)")
        }
    }
}

// MARK: - Layout of an edited schedule

public enum ScheduleEditing {
    /// Ids given to parts added by the user (well away from the automatic, file and manual ids).
    public static let firstCustomId = 20_000

    /// Pause after each part (song, counsel, changeover), from the schedule as it is now.
    /// Call it before changing the parts' durations.
    public static func gapsAfter(_ items: [TalkScheduleItem]) -> [Int: TimeInterval] {
        var gaps: [Int: TimeInterval] = [:]
        for n in items.indices where n + 1 < items.count {
            let a = items[n]
            let b = items[n + 1]
            gaps[a.id] = max(0, b.startOffsetIntoMeeting - (a.startOffsetIntoMeeting + a.originalDuration))
        }
        return gaps
    }

    /// Recomputes the start offsets (used by the adaptive timer) of an edited schedule:
    /// each part keeps the pause that followed it; new parts get 20 s (80 s for student
    /// parts, to allow for counsel). An unedited schedule gets back its original offsets.
    public static func layOut(_ items: [TalkScheduleItem], gaps: [Int: TimeInterval], firstOffset: TimeInterval) {
        var offset = firstOffset
        for (n, item) in items.enumerated() {
            item.startOffsetIntoMeeting = offset
            if n + 1 < items.count {
                let gap = gaps[item.id] ?? (item.isStudentTalk ? 80 : 20)
                offset += item.originalDuration + gap
            }
        }
    }
}

// MARK: - XML export (same format read by OnlyT on Windows and Mac)

public enum ScheduleXMLWriter {
    public static func xml(_ items: [TalkScheduleItem]) -> String {
        var s = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<meeting>\n  <items>\n"
        for t in items {
            var attrs: [(String, String)] = [("name", t.name)]
            if !t.meetingSectionNameLocalised.isEmpty {
                attrs.append(("section", t.meetingSectionNameLocalised))
            }
            let d = max(0, Int(t.originalDuration))
            attrs.append(("duration", String(format: "%02d:%02d:%02d", d / 3600, (d % 3600) / 60, d % 60)))
            attrs.append(("editable", t.editable ? "true" : "false"))
            attrs.append(("bell", t.bellApplicable ? "true" : "false"))
            if let up = t.countUp {
                attrs.append(("countup", up ? "true" : "false"))
            }
            attrs.append(("persist", t.persistFinalTimerValue ? "true" : "false"))
            attrs.append(("closingSecs", String(t.closingSecs)))
            s += "    <item " + attrs.map { "\($0.0)=\"\(escape($0.1))\"" }.joined(separator: " ") + " />\n"
        }
        s += "  </items>\n</meeting>\n"
        return s
    }

    static func escape(_ s: String) -> String {
        s.replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
            .replacingOccurrences(of: "'", with: "&apos;")
    }
}

// MARK: - Durations typed by the user

public enum DurationParser {
    /// Parses "mm:ss", "mm", "m.ss" or "mm ss" (0...maxMinutes minutes).
    public static func parse(_ value: String, maxMinutes: Int = 99) -> Int? {
        let parts = value.trimmingCharacters(in: .whitespaces)
            .split(whereSeparator: { $0 == ":" || $0 == " " || $0 == "." })
            .map(String.init)
        guard parts.count >= 1 && parts.count <= 2, let mins = Int(parts[0]), mins >= 0, mins <= maxMinutes else {
            return nil
        }
        var secs = 0
        if parts.count == 2 {
            guard let s = Int(parts[1]), s >= 0, s <= 59 else {
                return nil
            }
            secs = s
        }
        let total = mins * 60 + secs
        return total <= maxMinutes * 60 ? total : nil
    }
}
