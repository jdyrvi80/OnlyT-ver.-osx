import Foundation

public struct HTTPRequest {
    public var method: String
    public var path: String
    public var query: [String: String]
    /// Header names are lower-cased.
    public var headers: [String: String]
    public var body: Data
    /// "ip:port" of the client.
    public var remoteEndpoint: String
    public var httpVersion: String

    public init(method: String, path: String, query: [String: String] = [:], headers: [String: String] = [:],
                body: Data = Data(), remoteEndpoint: String = "", httpVersion: String = "HTTP/1.1") {
        self.method = method
        self.path = path
        self.query = query
        self.headers = headers
        self.body = body
        self.remoteEndpoint = remoteEndpoint
        self.httpVersion = httpVersion
    }

    /// Path segments in the style of .NET Uri.Segments: "/api/v4/timers" -> ["/", "api/", "v4/", "timers"].
    public var segments: [String] {
        var result = ["/"]
        var trimmed = path
        if trimmed.hasPrefix("/") {
            trimmed.removeFirst()
        }
        let parts = trimmed.split(separator: "/", omittingEmptySubsequences: false).map(String.init)
        for (i, p) in parts.enumerated() {
            if i < parts.count - 1 {
                result.append(p + "/")
            } else if !p.isEmpty {
                result.append(p)
            }
        }
        return result
    }

    public func header(_ name: String) -> String? {
        headers[name.lowercased()]
    }

    /// Case-insensitive query lookup.
    public func queryValue(_ name: String) -> String? {
        let n = name.lowercased()
        return query.first { $0.key.lowercased() == n }?.value
    }

    public var wantsKeepAlive: Bool {
        let conn = header("connection")?.lowercased() ?? ""
        if httpVersion.uppercased() == "HTTP/1.0" {
            return conn.contains("keep-alive")
        }
        return !conn.contains("close")
    }
}

public struct HTTPResponse {
    public var status: Int
    public var headers: [(String, String)]
    public var body: Data

    public init(status: Int = 200, headers: [(String, String)] = [], body: Data = Data()) {
        self.status = status
        self.headers = headers
        self.body = body
    }

    public static func json(_ object: [String: Any], status: Int = 200, cors: Bool = true, extraHeaders: [(String, String)] = []) -> HTTPResponse {
        let data = (try? JSONSerialization.data(withJSONObject: object, options: [])) ?? Data("{}".utf8)
        var h: [(String, String)] = [("Content-Type", "application/json; charset=utf-8")]
        if cors {
            h.append(("Access-Control-Allow-Origin", "*"))
        }
        h.append(contentsOf: extraHeaders)
        return HTTPResponse(status: status, headers: h, body: data)
    }

    public static func html(_ text: String) -> HTTPResponse {
        HTTPResponse(status: 200, headers: [
            ("Content-Type", "text/html; charset=utf-8"),
            ("Cache-Control", "no-cache, no-store, must-revalidate"),
        ], body: Data(text.utf8))
    }

    public static func empty(_ status: Int = 200) -> HTTPResponse {
        HTTPResponse(status: status)
    }

    public static func reason(_ status: Int) -> String {
        switch status {
        case 200: return "OK"
        case 204: return "No Content"
        case 400: return "Bad Request"
        case 401: return "Unauthorized"
        case 403: return "Forbidden"
        case 404: return "Not Found"
        case 405: return "Method Not Allowed"
        case 413: return "Payload Too Large"
        case 500: return "Internal Server Error"
        case 503: return "Service Unavailable"
        default: return "Status"
        }
    }

    public func serialized(keepAlive: Bool) -> Data {
        var head = "HTTP/1.1 \(status) \(HTTPResponse.reason(status))\r\n"
        for (k, v) in headers {
            head += "\(k): \(v)\r\n"
        }
        head += "Content-Length: \(body.count)\r\n"
        head += "Connection: \(keepAlive ? "keep-alive" : "close")\r\n"
        head += "\r\n"
        var out = Data(head.utf8)
        out.append(body)
        return out
    }
}

public enum HTTPParseError: Error {
    case malformed
    case tooLarge
}

public enum HTTPParser {
    public static let maxHeaderBytes = 32 * 1024
    public static let maxBodyBytes = 1024 * 1024

    /// Parses one request from the start of `buffer`. Returns nil if more data is needed.
    public static func parse(_ buffer: Data, remoteEndpoint: String) throws -> (HTTPRequest, Int)? {
        let separator = Data("\r\n\r\n".utf8)
        guard let headerEnd = buffer.range(of: separator) else {
            if buffer.count > maxHeaderBytes {
                throw HTTPParseError.tooLarge
            }
            return nil
        }
        let headerData = buffer.subdata(in: buffer.startIndex..<headerEnd.lowerBound)
        guard let headerText = String(data: headerData, encoding: .utf8) ?? String(data: headerData, encoding: .isoLatin1) else {
            throw HTTPParseError.malformed
        }
        var lines = headerText.components(separatedBy: "\r\n")
        guard !lines.isEmpty else {
            throw HTTPParseError.malformed
        }
        let requestLine = lines.removeFirst().split(separator: " ", omittingEmptySubsequences: true).map(String.init)
        guard requestLine.count >= 2 else {
            throw HTTPParseError.malformed
        }
        let method = requestLine[0].uppercased()
        let target = requestLine[1]
        let version = requestLine.count > 2 ? requestLine[2] : "HTTP/1.0"

        var headers: [String: String] = [:]
        for line in lines {
            guard let colon = line.firstIndex(of: ":") else {
                continue
            }
            let name = line[line.startIndex..<colon].trimmingCharacters(in: .whitespaces).lowercased()
            let value = line[line.index(after: colon)...].trimmingCharacters(in: .whitespaces)
            headers[name] = value
        }

        let contentLength = Int(headers["content-length"] ?? "0") ?? 0
        if contentLength < 0 || contentLength > maxBodyBytes {
            throw HTTPParseError.tooLarge
        }
        let bodyStart = headerEnd.upperBound
        let available = buffer.endIndex - bodyStart
        if available < contentLength {
            return nil
        }
        let body = buffer.subdata(in: bodyStart..<(bodyStart + contentLength))

        var path = target
        var query: [String: String] = [:]
        if let q = target.firstIndex(of: "?") {
            path = String(target[target.startIndex..<q])
            let qs = String(target[target.index(after: q)...])
            for pair in qs.split(separator: "&") {
                let kv = pair.split(separator: "=", maxSplits: 1, omittingEmptySubsequences: false).map(String.init)
                let k = decode(kv[0])
                let v = kv.count > 1 ? decode(kv[1]) : ""
                if !k.isEmpty {
                    query[k] = v
                }
            }
        }
        // absolute-form targets ("http://host/path")
        if let range = path.range(of: "://") {
            let afterScheme = path[range.upperBound...]
            if let slash = afterScheme.firstIndex(of: "/") {
                path = String(afterScheme[slash...])
            } else {
                path = "/"
            }
        }
        path = path.removingPercentEncoding ?? path

        let request = HTTPRequest(method: method, path: path, query: query, headers: headers, body: body,
                                  remoteEndpoint: remoteEndpoint, httpVersion: version)
        let consumed = (bodyStart - buffer.startIndex) + contentLength
        return (request, consumed)
    }

    private static func decode(_ s: String) -> String {
        s.replacingOccurrences(of: "+", with: " ").removingPercentEncoding ?? s
    }
}
