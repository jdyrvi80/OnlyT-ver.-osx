import Foundation

// MARK: - Date / time provider

/// Source of the current date & time (injectable for tests and for the
/// `--datetime` launch argument, like the original OnlyT).
public protocol DateTimeProvider: AnyObject {
    func now() -> Date
}

public final class SystemDateTimeProvider: DateTimeProvider {
    /// Offset applied to the real clock (used to simulate another date/time).
    public var offset: TimeInterval

    public init(offset: TimeInterval = 0) {
        self.offset = offset
    }

    public func now() -> Date {
        Date().addingTimeInterval(offset)
    }
}

public final class MockDateTimeProvider: DateTimeProvider {
    public var current: Date

    public init(_ date: Date) {
        current = date
    }

    public func set(_ date: Date) {
        current = date
    }

    public func now() -> Date {
        current
    }
}

// MARK: - Monotonic clock

/// Monotonic seconds (includes time asleep), used to measure talk durations
/// so that wall-clock adjustments do not disturb a running timer.
public enum Monotonic {
    private static let origin = ContinuousClock.now

    public static func now() -> TimeInterval {
        let comps = origin.duration(to: ContinuousClock.now).components
        return Double(comps.seconds) + Double(comps.attoseconds) / 1e18
    }
}

// MARK: - Formatting

public enum TimeFormatter {
    /// "mm:ss" (absolute value, minutes can exceed 59), as in OnlyT.
    public static func formatTimer(_ totalSeconds: Int) -> String {
        let a = abs(totalSeconds)
        return String(format: "%02d:%02d", a / 60, a % 60)
    }

    /// .NET TimeSpan "c" format: [-][d.]hh:mm:ss[.fffffff]
    public static func dotNetTimeSpan(_ interval: TimeInterval) -> String {
        let negative = interval < 0
        let ticks = Int64((abs(interval) * 10_000_000).rounded())
        let totalSeconds = ticks / 10_000_000
        let fraction = ticks % 10_000_000
        let days = totalSeconds / 86_400
        let hours = (totalSeconds % 86_400) / 3_600
        let mins = (totalSeconds % 3_600) / 60
        let secs = totalSeconds % 60
        var s = negative ? "-" : ""
        if days > 0 {
            s += "\(days)."
        }
        s += String(format: "%02d:%02d:%02d", Int(hours), Int(mins), Int(secs))
        if fraction > 0 {
            s += String(format: ".%07d", Int(fraction))
        }
        return s
    }
}

// MARK: - Date helpers

public enum DateUtils {
    public static func mondayOfWeek(_ date: Date, calendar: Calendar = .current) -> Date {
        let start = calendar.startOfDay(for: date)
        let weekday = calendar.component(.weekday, from: start) // 1 = Sunday ... 7 = Saturday
        let daysToDeduct = (weekday + 5) % 7
        return calendar.date(byAdding: .day, value: -daysToDeduct, to: start) ?? start
    }

    /// Truncates seconds (and fractions).
    public static func nearestMinute(_ date: Date) -> Date {
        let t = date.timeIntervalSinceReferenceDate
        return Date(timeIntervalSinceReferenceDate: (t / 60).rounded(.down) * 60)
    }

    /// Rounds to the nearest quarter of an hour (up to 10 mins past rounds down, otherwise up).
    public static func nearestQuarterOfAnHour(_ date: Date, calendar: Calendar = .current) -> Date {
        let minute = calendar.component(.minute, from: date)
        let remainder = minute % 15
        let adjust = remainder <= 10 ? -remainder : 15 - remainder
        return nearestMinute(date).addingTimeInterval(Double(adjust * 60))
    }

    /// Port of AdaptiveTimerService.GetNearest15MinsBefore (keeps the original behaviour).
    public static func nearest15MinsBefore(_ date: Date, calendar: Calendar = .current) -> Date {
        let minute = calendar.component(.minute, from: date)
        let target: Int
        if minute > 45 {
            target = 45
        } else if minute > 30 {
            target = 30
        } else if minute > 15 {
            target = 15
        } else {
            target = 0
        }
        let hourStart = nearestMinute(date).addingTimeInterval(Double(-minute * 60))
        return hourStart.addingTimeInterval(Double(target * 60))
    }

    public static func isWeekend(_ date: Date, includesFriday: Bool, calendar: Calendar = .current) -> Bool {
        let weekday = calendar.component(.weekday, from: date)
        return weekday == 1 || weekday == 7 || (includesFriday && weekday == 6)
    }

    /// Seconds since local midnight.
    public static func secondsIntoDay(_ date: Date, calendar: Calendar = .current) -> Int {
        let start = calendar.startOfDay(for: date)
        return Int(date.timeIntervalSince(start).rounded())
    }

    /// Angle (degrees) of the minute hand for a date: used for the "duration sector".
    public static func minuteHandAngle(_ date: Date, calendar: Calendar = .current) -> Double {
        let c = calendar.dateComponents([.minute, .second, .nanosecond], from: date)
        let ms = Double(c.nanosecond ?? 0) / 1_000_000
        return Double(c.minute ?? 0) * 6.0 + Double(c.second ?? 0) * 0.1 + ms * (0.1 / 1000)
    }
}
