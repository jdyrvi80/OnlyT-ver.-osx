import Foundation

/// Error codes of the OnlyT web API (same values as the original).
public enum WebServerErrorCode: Int, Error {
    case success = 0
    case timerDoesNotExist = 1129
    case uriTooManySegments = 1130
    case uriTooFewSegments = 1131
    case badPrefix = 1134
    case badHttpVerb = 1135
    case apiVersionNotSupported = 1138
    case notAvailableInApiVersion = 1139
    case badApiCode = 1140
    case apiNotEnabled = 1151
    case subscriptionAddressNotFound = 1155
    case subscriptionPortNotSpecified = 1156
    case throttled = 1157
    case badRequestBody = 1158
    case timerNotEditable = 1159
    case unknownError = 5128

    public var message: String {
        switch self {
        case .success: return "Success"
        case .timerDoesNotExist: return "Timer does not exist"
        case .uriTooManySegments, .uriTooFewSegments, .badPrefix: return "Malformed URI"
        case .badHttpVerb: return "Wrong http method used"
        case .apiVersionNotSupported: return "API version not supported"
        case .notAvailableInApiVersion: return "Not available in selected API version"
        case .badApiCode: return "Invalid API code"
        case .apiNotEnabled: return "API is not enabled"
        case .subscriptionAddressNotFound: return "Subscription address not found"
        case .subscriptionPortNotSpecified: return "Subscription port not found"
        case .badRequestBody: return "Invalid request body"
        case .timerNotEditable: return "Timer is not editable"
        case .throttled: return "Client throttled"
        case .unknownError: return "Unknown error"
        }
    }

    public var httpStatus: Int {
        switch self {
        case .timerDoesNotExist: return 404
        case .uriTooManySegments, .uriTooFewSegments, .badPrefix, .apiVersionNotSupported, .notAvailableInApiVersion,
             .subscriptionAddressNotFound, .subscriptionPortNotSpecified, .badRequestBody: return 400
        case .timerNotEditable: return 403
        case .throttled: return 503
        case .unknownError: return 500
        case .badHttpVerb: return 405
        case .badApiCode, .apiNotEnabled: return 401
        case .success: return 200
        }
    }
}

/// Snapshot of the options relevant to the web server.
public struct WebOptions {
    public var isWebClockEnabled: Bool
    public var isApiEnabled: Bool
    public var isApiThrottled: Bool
    public var apiCode: String?

    public init(isWebClockEnabled: Bool, isApiEnabled: Bool, isApiThrottled: Bool, apiCode: String?) {
        self.isWebClockEnabled = isWebClockEnabled
        self.isApiEnabled = isApiEnabled
        self.isApiThrottled = isApiThrottled
        self.apiCode = apiCode
    }
}

/// What the web server needs from the app. Methods are called on a background
/// queue: implementations must hop to the main thread themselves.
public protocol WebHost: AnyObject {
    func webOptions() -> WebOptions
    /// JSON object for /data (web clock).
    func clockData() -> [String: Any]
    /// JSON object for the timers (all, or the one with `talkId`).
    func timersData(talkId: Int?) throws -> [String: Any]
    func startTimer(talkId: Int) throws -> [String: Any]
    func stopTimer(talkId: Int) throws -> [String: Any]
    func changeDuration(talkId: Int, deltaSeconds: Int) throws -> [String: Any]
    /// Rings the bell; returns false if it was already ringing.
    func ringBell() -> Bool
    func now() -> Date
    func systemData() -> [String: Any]
}

public enum ApiRequestType: Int {
    case unknown, clockPage, clockData, timer, timerControlStart, timerControlStop, version, bell, dateTime, system, timerDurationChange

    var minIntervalMillisecs: Double {
        switch self {
        case .timer: return 2000
        case .timerControlStart, .timerControlStop: return 500
        case .clockData: return 500
        case .timerDurationChange: return 200
        default: return 1000
        }
    }
}

/// Per-client rate limiting (port of ApiThrottler / ApiRequestHistory).
public final class ApiThrottler {
    private let lock = NSLock()
    private var history: [String: Double] = [:]
    private var lastCleanup: Double = 0
    private let clock: () -> TimeInterval

    public init(clock: @escaping () -> TimeInterval = Monotonic.now) {
        self.clock = clock
    }

    public func check(_ type: ApiRequestType, client: String, enabled: Bool) throws {
        guard enabled, !client.isEmpty else {
            return
        }
        let nowMs = clock() * 1000
        lock.lock()
        defer { lock.unlock() }
        let key = "\(client)|\(type.rawValue)"
        if let previous = history[key], nowMs - previous < type.minIntervalMillisecs {
            throw WebServerErrorCode.throttled
        }
        history[key] = nowMs
        if nowMs - lastCleanup > 300_000 {
            lastCleanup = nowMs
            history = history.filter { nowMs - $0.value < 300_000 }
        }
    }
}

/// Routes HTTP requests like the original HttpServer + ApiRouter + controllers.
public final class WebRouter {
    public static let oldestSupportedApiVer = 1
    public static let currentApiVer = 4

    public weak var host: WebHost?
    private let throttler = ApiThrottler()
    private var pageCache: [String: String] = [:]
    private let cacheLock = NSLock()

    public init(host: WebHost?) {
        self.host = host
    }

    /// Clears cached web pages (e.g. after a language change).
    public func clearPageCache() {
        cacheLock.lock()
        pageCache.removeAll()
        cacheLock.unlock()
    }

    public func handle(_ request: HTTPRequest) -> HTTPResponse {
        guard let host = host else {
            return .empty(503)
        }
        do {
            return try route(request, host: host)
        } catch let code as WebServerErrorCode {
            return errorResponse(code)
        } catch {
            return errorResponse(.unknownError)
        }
    }

    public func errorResponse(_ code: WebServerErrorCode) -> HTTPResponse {
        .json(["errorCode": code.rawValue, "errorMessage": code.message], status: code.httpStatus)
    }

    private func route(_ request: HTTPRequest, host: WebHost) throws -> HTTPResponse {
        let segments = request.segments
        guard segments.count > 1 else {
            return .empty(404)
        }
        let options = host.webOptions()
        let first = trim(segments[1]).lowercased()
        switch first {
        case "data":
            guard options.isWebClockEnabled else { return .empty(404) }
            return .json(host.clockData(), cors: false, extraHeaders: [("Cache-Control", "no-cache, no-store, must-revalidate")])
        case "index":
            guard options.isWebClockEnabled else { return .empty(404) }
            return .html(page("ClockHtmlTemplate.html"))
        case "timers":
            guard options.isWebClockEnabled else { return .empty(404) }
            return .html(page("TimersHtmlTemplate.html"))
        case "schedule":
            guard options.isWebClockEnabled else { return .empty(404) }
            return .json(try host.timersData(talkId: nil))
        case "api":
            let isClockTimersGet = options.isWebClockEnabled && request.method == "GET"
                && segments.count >= 4 && trim(segments[3]).lowercased() == "timers"
            guard options.isApiEnabled || isClockTimersGet else {
                return .empty(404)
            }
            return try routeApi(request, segments: segments, host: host, options: options)
        default:
            return .empty(404)
        }
    }

    private func routeApi(_ request: HTTPRequest, segments: [String], host: WebHost, options: WebOptions) throws -> HTTPResponse {
        if request.method == "OPTIONS" {
            var headers: [(String, String)] = [
                ("Access-Control-Allow-Origin", "*"),
                ("Access-Control-Allow-Methods", "GET, PUT, POST, DELETE, OPTIONS"),
            ]
            headers.append(("Access-Control-Allow-Headers", request.header("access-control-request-headers") ?? "Content-Type, x-api-code, ApiCode"))
            return HTTPResponse(status: 200, headers: headers)
        }

        if segments.count < 2 {
            throw WebServerErrorCode.uriTooFewSegments
        }
        let client = request.remoteEndpoint
        let throttled = options.isApiThrottled

        if segments.count == 2 {
            // "/api/": supported API versions
            try checkMethod(request, ["GET"])
            try throttler.check(.version, client: client, enabled: throttled)
            return .json(["lowVersion": WebRouter.oldestSupportedApiVer, "highVersion": WebRouter.currentApiVer])
        }
        guard segments.count > 3 else {
            return .empty()
        }

        let versionString = trim(segments[2]).lowercased()
        guard versionString.count > 1, let ver = Int(versionString.dropFirst()), ver >= 1, ver <= WebRouter.currentApiVer else {
            throw WebServerErrorCode.apiVersionNotSupported
        }

        let segment = trim(segments[3]).lowercased()
        if segment != "system" {
            try checkApiCode(request, apiCode: options.apiCode)
        }

        switch segment {
        case "timers":
            return try timers(request, segments: segments, host: host, client: client, throttled: throttled)
        case "webhooks":
            try checkMethod(request, ["GET", "POST", "DELETE"])
            return .empty()
        case "bell":
            try checkMethod(request, ["POST"])
            try checkSegmentCount(segments, [4])
            try throttler.check(.bell, client: client, enabled: throttled)
            return .json(["success": host.ringBell()])
        case "datetime":
            try checkMethod(request, ["GET"])
            try checkSegmentCount(segments, [4])
            try throttler.check(.dateTime, client: client, enabled: throttled)
            let now = host.now()
            let c = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: now)
            return .json([
                "year": c.year ?? 0, "month": c.month ?? 0, "day": c.day ?? 0,
                "hour": c.hour ?? 0, "min": c.minute ?? 0, "second": c.second ?? 0,
            ], extraHeaders: [("Cache-Control", "no-cache")])
        case "system":
            try checkMethod(request, ["GET"])
            try checkSegmentCount(segments, [4])
            try throttler.check(.system, client: client, enabled: throttled)
            return .json(host.systemData(), extraHeaders: [("Cache-Control", "no-cache")])
        default:
            throw WebServerErrorCode.badPrefix
        }
    }

    private func timers(_ request: HTTPRequest, segments: [String], host: WebHost, client: String, throttled: Bool) throws -> HTTPResponse {
        if segments.count == 6 && trim(segments[5]).lowercased() == "duration" {
            try checkMethod(request, ["POST"])
            try throttler.check(.timerDurationChange, client: client, enabled: throttled)
            guard let talkId = Int(trim(segments[4])) else {
                return .empty()
            }
            guard let body = (try? JSONSerialization.jsonObject(with: request.body)) as? [String: Any] else {
                throw WebServerErrorCode.badRequestBody
            }
            let lower = Dictionary(body.map { ($0.key.lowercased(), $0.value) }, uniquingKeysWith: { a, _ in a })
            guard let delta = (lower["deltaseconds"] as? Int) ?? (lower["deltaseconds"] as? Double).map({ Int($0) }) else {
                throw WebServerErrorCode.badRequestBody
            }
            return .json(try host.changeDuration(talkId: talkId, deltaSeconds: delta))
        }

        try checkMethod(request, ["GET", "POST", "DELETE"])
        switch request.method {
        case "GET":
            try checkSegmentCount(segments, [4, 5])
            try throttler.check(.timer, client: client, enabled: throttled)
            if segments.count == 4 {
                return .json(try host.timersData(talkId: nil))
            }
            guard let talkId = Int(trim(segments[4])) else {
                return .empty()
            }
            return .json(try host.timersData(talkId: talkId))
        case "POST":
            try checkSegmentCount(segments, [5])
            try throttler.check(.timerControlStart, client: client, enabled: throttled)
            guard let talkId = Int(trim(segments[4])) else {
                return .empty()
            }
            return .json(try host.startTimer(talkId: talkId))
        default: // DELETE
            try checkSegmentCount(segments, [5])
            try throttler.check(.timerControlStop, client: client, enabled: throttled)
            guard let talkId = Int(trim(segments[4])) else {
                return .empty()
            }
            return .json(try host.stopTimer(talkId: talkId))
        }
    }

    // MARK: helpers

    private func trim(_ s: String) -> String {
        var r = s
        while r.hasSuffix("/") {
            r.removeLast()
        }
        return r
    }

    private func checkMethod(_ request: HTTPRequest, _ allowed: [String]) throws {
        if !allowed.contains(request.method) {
            throw WebServerErrorCode.badHttpVerb
        }
    }

    private func checkSegmentCount(_ segments: [String], _ allowed: [Int]) throws {
        if !allowed.contains(segments.count) {
            throw WebServerErrorCode.uriTooManySegments
        }
    }

    private func checkApiCode(_ request: HTTPRequest, apiCode: String?) throws {
        let code = request.header("apicode") ?? request.header("x-api-code") ?? request.queryValue("ApiCode")
        let configured = apiCode ?? ""
        if (code ?? "").isEmpty && (configured.isEmpty || request.method == "GET") {
            return
        }
        if let code = code, code == configured {
            return
        }
        throw WebServerErrorCode.badApiCode
    }

    private func page(_ name: String) -> String {
        cacheLock.lock()
        if let cached = pageCache[name] {
            cacheLock.unlock()
            return cached
        }
        cacheLock.unlock()

        var content = ResourceLocator.string("Web/\(name)") ?? "<html><body>OnlyT</body></html>"
        content = content.replacingOccurrences(of: "{SHARED_JS}", with: ResourceLocator.string("Web/SharedClockJsTemplate.html") ?? "")
        content = content.replacingOccurrences(of: "{SNACKBAR}", with: ResourceLocator.string("Web/SharedSnackbarTemplate.html") ?? "")
        for key in ["WEB_OFFLINE", "WEB_LINK_TIMERS", "WEB_LINK_CLOCK"] {
            content = content.replacingOccurrences(of: "{\(key)}", with: L10n.t(key))
        }

        cacheLock.lock()
        pageCache[name] = content
        cacheLock.unlock()
        return content
    }
}

// MARK: - JSON shaping shared with the app

public enum ApiJSON {
    public static func timerInfo(_ talk: TalkScheduleItem, countUpByDefault: Bool) -> [String: Any] {
        func opt(_ v: Int?) -> Any { v.map { $0 as Any } ?? NSNull() }
        return [
            "talkId": talk.id,
            "talkTitle": talk.name,
            "meetingSectionNameInternal": talk.meetingSectionNameInternal,
            "meetingSectionNameLocalised": talk.meetingSectionNameLocalised,
            "originalDurationSecs": Int(talk.originalDuration),
            "modifiedDurationSecs": opt(talk.modifiedDuration.map { Int($0) }),
            "adaptedDurationSecs": opt(talk.adaptedDuration.map { Int($0) }),
            "actualDurationSecs": Int(talk.actualDuration),
            "usesBell": talk.bellApplicable,
            "completedTimeSecs": opt(talk.completedTimeSecs),
            "countUp": talk.countUp ?? countUpByDefault,
            "closingSecs": talk.closingSecs,
            "editable": talk.editable,
        ]
    }

    public static func timersResponse(talks: [TalkScheduleItem], status: TimerStatus, countUpByDefault: Bool) -> [String: Any] {
        [
            "status": status.jsonObject,
            "timerInfo": talks.map { timerInfo($0, countUpByDefault: countUpByDefault) },
        ]
    }

    public static func startStopResponse(talkId: Int, command: StartStopTimerCommand, success: Bool, status: TimerStatus) -> [String: Any] {
        [
            "talkId": talkId,
            "command": command.rawValue,
            "success": success,
            "currentStatus": status.jsonObject,
        ]
    }

    public static func durationChangeResponse(talkId: Int, deltaSeconds: Int, success: Bool, newDurationSecs: Int) -> [String: Any] {
        [
            "talkId": talkId,
            "deltaSeconds": deltaSeconds,
            "success": success,
            "newDurationSecs": newDurationSecs,
        ]
    }
}
