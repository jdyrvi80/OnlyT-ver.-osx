import Foundation

/// Talk ids used in Automatic mode (same numbers as the original OnlyT, so
/// that remote-control apps keep working).
public enum TalkTypesAutoMode: Int, CaseIterable {
    case unknown = 0
    case openingComments = 1000
    case treasuresTalk = 1001
    case diggingTalk = 1002
    case reading = 1003
    case ministryItem1 = 2000
    case ministryItem2 = 2001
    case ministryItem3 = 2002
    case ministryItem4 = 2003
    case livingPart1 = 3000
    case livingPart2 = 3001
    case congBibleStudy = 4000
    case circuitServiceTalk = 5000
    case concludingComments = 6000
    case publicTalk = 7000
    case watchtower = 8000
}

/// A talk (meeting item) in the schedule.
public final class TalkScheduleItem: Identifiable {
    public static let defaultClosingSecs = 30

    public let id: Int
    public var name: String
    public var meetingSectionNameInternal: String
    public var meetingSectionNameLocalised: String

    public var countUp: Bool?
    public var closingSecs: Int = TalkScheduleItem.defaultClosingSecs

    /// Duration for which the timer ran (nil if not yet run).
    public var completedTimeSecs: Int?

    /// Original duration in seconds (before any user modification).
    public var originalDuration: TimeInterval = 0

    private var storedModifiedDuration: TimeInterval?

    /// Manually modified duration (nil when equal to the original).
    public var modifiedDuration: TimeInterval? {
        get { storedModifiedDuration }
        set {
            if let v = newValue, v == originalDuration {
                storedModifiedDuration = nil
            } else {
                storedModifiedDuration = newValue
            }
        }
    }

    /// Duration calculated by the adaptive timer.
    public var adaptedDuration: TimeInterval?

    public var startOffsetIntoMeeting: TimeInterval = 0
    public var allowAdaptive = false
    public var persistFinalTimerValue = false
    public var editable = false
    public var bellApplicable = false
    public var autoBell = false
    public var isStudentTalk = false

    public init(id: Int, name: String, sectionInternal: String, sectionLocalised: String) {
        self.id = id
        self.name = name
        self.meetingSectionNameInternal = sectionInternal
        self.meetingSectionNameLocalised = sectionLocalised
    }

    public convenience init(type: TalkTypesAutoMode, name: String, sectionInternal: String, sectionLocalised: String) {
        self.init(id: type.rawValue, name: name, sectionInternal: sectionInternal, sectionLocalised: sectionLocalised)
    }

    /// Actual duration used: adapted, else modified, else original.
    public var actualDuration: TimeInterval {
        adaptedDuration ?? modifiedDuration ?? originalDuration
    }

    /// Planned duration: modified, else original.
    public var plannedDuration: TimeInterval {
        modifiedDuration ?? originalDuration
    }

    public var plannedDurationSeconds: Int {
        Int(plannedDuration)
    }

    public var originalDurationString: String {
        TimeFormatter.formatTimer(Int(originalDuration))
    }

    public var originalOrModifiedDurationString: String {
        TimeFormatter.formatTimer(Int(modifiedDuration ?? originalDuration))
    }

    /// "-mm:ss" when finished early, "+mm:ss" when overtime, nil if not run.
    public var overtimeString: String? {
        guard let completed = completedTimeSecs, completed != 0 else {
            return nil
        }
        let overtimeSecs = Int(actualDuration - Double(completed))
        let s = TimeFormatter.formatTimer(abs(overtimeSecs))
        return overtimeSecs >= 0 ? "-\(s)" : "+\(s)"
    }

    /// True when the completed time exceeded the allowed duration.
    public var finishedOvertime: Bool {
        guard let completed = completedTimeSecs else {
            return false
        }
        return actualDuration - Double(completed) < 0
    }
}

/// Status of the talk timer (serialised by the web API like the original).
public struct TimerStatus {
    public var talkId: Int?
    public var targetSeconds: Int
    public var isRunning: Bool
    public var isPaused: Bool
    public var timeElapsed: TimeInterval
    public var closingSecs: Int

    public init(talkId: Int?, targetSeconds: Int, isRunning: Bool, isPaused: Bool, timeElapsed: TimeInterval, closingSecs: Int) {
        self.talkId = talkId
        self.targetSeconds = targetSeconds
        self.isRunning = isRunning
        self.isPaused = isPaused
        self.timeElapsed = timeElapsed
        self.closingSecs = closingSecs
    }

    public var jsonObject: [String: Any] {
        [
            "talkId": talkId.map { $0 as Any } ?? NSNull(),
            "targetSeconds": targetSeconds,
            "isRunning": isRunning,
            "isPaused": isPaused,
            "timeElapsed": TimeFormatter.dotNetTimeSpan(timeElapsed),
            "closingSecs": closingSecs,
        ]
    }
}

public enum StartStopTimerCommand: Int {
    case unknown = 0
    case start = 1
    case stop = 2
}

/// Colour of the timer text: green, yellow (closing phase), red (overtime).
public enum TimerColour: Equatable {
    case white
    case green
    case yellow
    case red

    public static func forTimeRemaining(_ secsRemaining: Int, closingSecs: Int) -> TimerColour {
        if secsRemaining <= 0 {
            return .red
        }
        if secsRemaining <= closingSecs {
            return .yellow
        }
        return .green
    }
}

/// The three duration strings shown under the operator timer
/// (original → modified → adapted).
public struct DurationStrings: Equatable {
    public var duration1 = ""
    public var duration2 = ""
    public var duration3 = ""
    public var tooltip1 = ""
    public var tooltip2 = ""
    public var tooltip3 = ""
    /// Index (1...3) of the duration that is in force (drawn brighter).
    public var activeIndex = 1

    public init() {}

    public static func make(adaptiveMode: AdaptiveMode, talk: TalkScheduleItem?) -> DurationStrings {
        var r = DurationStrings()
        if let talk = talk {
            r.duration1 = TimeFormatter.formatTimer(Int(talk.originalDuration))
            r.tooltip1 = L10n.t("DURATION_ORIGINAL")

            if let modified = talk.modifiedDuration {
                r.duration2 = TimeFormatter.formatTimer(Int(modified))
                r.tooltip2 = L10n.t("DURATION_MODIFIED")
                if let adapted = talk.adaptedDuration, adaptiveMode == .twoWay || adapted < modified {
                    r.duration3 = TimeFormatter.formatTimer(Int(adapted))
                    r.tooltip3 = L10n.t("DURATION_ADAPTED")
                }
            } else if let adapted = talk.adaptedDuration {
                r.duration2 = TimeFormatter.formatTimer(Int(adapted))
                r.tooltip2 = L10n.t("DURATION_ADAPTED")
            }
        }

        if !r.duration3.isEmpty {
            r.activeIndex = 3
        } else if !r.duration2.isEmpty {
            r.activeIndex = 2
        } else {
            r.activeIndex = 1
        }
        return r
    }
}
