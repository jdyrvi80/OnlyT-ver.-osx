import Foundation

/// The talk timer (port of TalkTimerService): measures elapsed time with a
/// monotonic clock. The app polls it (10 times per second) to refresh the UI.
public final class TalkTimerEngine {
    public private(set) var isRunning = false
    public private(set) var talkId: Int?
    public private(set) var targetSecs = 600
    public private(set) var closingSecs = TalkScheduleItem.defaultClosingSecs
    public private(set) var isCountingUp = false
    public var isPaused = false

    /// Whole seconds elapsed (changes trigger UI updates).
    public private(set) var currentSecondsElapsed = 0

    private var startTime: TimeInterval?
    private let clock: () -> TimeInterval

    public init(clock: @escaping () -> TimeInterval = Monotonic.now) {
        self.clock = clock
    }

    public func setupTalk(talkId: Int, targetSeconds: Int, closingSecs: Int) {
        self.talkId = talkId
        self.targetSecs = targetSeconds
        self.closingSecs = closingSecs
    }

    public func start(targetSecs: Int, talkId: Int, countUp: Bool) {
        self.targetSecs = targetSecs
        self.talkId = talkId
        self.isCountingUp = countUp
        startTime = clock()
        isRunning = true
        _ = poll()
    }

    /// Stops and resets the timer. Returns true if the elapsed seconds changed.
    @discardableResult
    public func stop() -> Bool {
        isRunning = false
        startTime = nil
        talkId = nil
        return poll()
    }

    /// Elapsed time with sub-second precision.
    public var elapsed: TimeInterval {
        guard isRunning, let s = startTime else {
            return 0
        }
        return max(0, clock() - s)
    }

    /// Refreshes `currentSecondsElapsed`; returns true when it changed.
    @discardableResult
    public func poll() -> Bool {
        let secs = Int(elapsed)
        if secs != currentSecondsElapsed {
            currentSecondsElapsed = secs
            return true
        }
        return false
    }

    public var remainingSecs: Int {
        targetSecs - currentSecondsElapsed
    }

    public func status() -> TimerStatus {
        TimerStatus(talkId: talkId, targetSeconds: targetSecs, isRunning: isRunning, isPaused: isPaused,
                    timeElapsed: elapsed, closingSecs: closingSecs)
    }
}

// MARK: - Countdown trigger

/// Decides when the pre-meeting countdown should be shown (port of CountdownTimerTriggerService).
public enum CountdownTrigger {
    /// Returns the seconds already elapsed in the countdown if `now` is within a
    /// countdown period (and at least 10 seconds remain), otherwise nil.
    public static func secondsIntoCountdown(now: Date, startTimes: [MeetingStartTime], countdownMins: Int,
                                            calendar: Calendar = .current) -> Int? {
        let today = calendar.startOfDay(for: now)
        let weekday = calendar.component(.weekday, from: now)
        for time in startTimes where time.dayOfWeek == nil || time.dayOfWeek == weekday {
            let start = today.addingTimeInterval(Double((time.startMinutes - countdownMins) * 60))
            let end = today.addingTimeInterval(Double(time.startMinutes * 60))
            if start <= now && end > now {
                let offset = Int(now.timeIntervalSince(start))
                let toEnd = end.timeIntervalSince(now)
                return toEnd >= 10 ? offset : nil
            }
        }
        return nil
    }
}

// MARK: - Reminders

/// "Should you have started the timer?" logic (port of ReminderService, minus the UI).
public final class ReminderLogic {
    static let defaultIntervalSeconds: Double = 30
    static let longIntervalSeconds: Double = 60
    static let nonAutoModeIntervalSeconds: Double = 60

    private var lastTalkTimeStopped: Date?
    private var lastTalkStoppedId: Int?
    private var lastTalkStoppedIsStudent = false
    private var nextTalkIdToStart: Int?
    private var lastReminderShown = Date.distantPast
    private var secondsBetweenRepeatedReminders = ReminderLogic.defaultIntervalSeconds
    private var active = false

    public init() {}

    public func timerStarted() {
        active = false
        lastTalkTimeStopped = nil
        lastTalkStoppedId = nil
        nextTalkIdToStart = nil
        lastReminderShown = .distantPast
        secondsBetweenRepeatedReminders = ReminderLogic.defaultIntervalSeconds
    }

    public func timerStopped(talk: TalkScheduleItem?, nextTalkId: Int, now: Date) {
        lastTalkTimeStopped = now
        lastTalkStoppedId = talk?.id
        lastTalkStoppedIsStudent = talk?.isStudentTalk ?? false
        nextTalkIdToStart = nextTalkId
        secondsBetweenRepeatedReminders = ReminderLogic.defaultIntervalSeconds
        active = true
    }

    public func countdownClosed(firstTalkId: Int?, now: Date) {
        lastTalkTimeStopped = now
        lastTalkStoppedId = nil
        nextTalkIdToStart = firstTalkId
        secondsBetweenRepeatedReminders = ReminderLogic.defaultIntervalSeconds
        active = true
    }

    /// The user closed a reminder: wait longer before the next one.
    public func reminderClosedManually() {
        secondsBetweenRepeatedReminders = ReminderLogic.longIntervalSeconds
    }

    public func markShown(_ now: Date) {
        lastReminderShown = now
    }

    public func shouldSendReminder(now: Date, mode: OperatingMode) -> Bool {
        guard active, let stopped = lastTalkTimeStopped else {
            return false
        }
        let tooLong = mode == .automatic
            ? isIntervalTooLongInAutoMode(now: now, stopped: stopped)
            : (nextTalkIdToStart ?? 0) != 0 && now.timeIntervalSince(stopped) > ReminderLogic.nonAutoModeIntervalSeconds
        return tooLong && now.timeIntervalSince(lastReminderShown) >= secondsBetweenRepeatedReminders
    }

    private func isIntervalTooLongInAutoMode(now: Date, stopped: Date) -> Bool {
        guard let next = nextTalkIdToStart, let nextType = TalkTypesAutoMode(rawValue: next) else {
            return false
        }
        let elapsed = now.timeIntervalSince(stopped)
        guard let lastId = lastTalkStoppedId else {
            // after the countdown and before the first talk: allow for intro, song and prayer
            return elapsed > 360
        }
        guard let lastType = TalkTypesAutoMode(rawValue: lastId), lastType != .unknown else {
            return false
        }

        var triggerSeconds: Double = 60
        let withCounsel: Double = 110
        let withoutCounsel: Double = 45

        switch lastType {
        case .concludingComments, .circuitServiceTalk, .watchtower:
            return false
        case .openingComments, .treasuresTalk, .diggingTalk:
            triggerSeconds = withoutCounsel
        case .reading:
            triggerSeconds = withCounsel
        case .ministryItem1, .ministryItem2, .ministryItem3, .ministryItem4:
            if nextType == .livingPart1 {
                triggerSeconds = 300 // include the middle song
            } else {
                triggerSeconds = lastTalkStoppedIsStudent ? withCounsel : withoutCounsel
            }
        case .livingPart1, .livingPart2, .congBibleStudy:
            triggerSeconds = withoutCounsel
        case .publicTalk:
            triggerSeconds = 300 // include the middle song
        case .unknown:
            break
        }
        return elapsed > triggerSeconds
    }
}
