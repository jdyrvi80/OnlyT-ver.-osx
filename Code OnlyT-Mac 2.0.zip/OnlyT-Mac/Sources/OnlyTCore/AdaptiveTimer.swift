import Foundation

/// Used in Automatic mode to adapt talk timings according to the start time of
/// the meeting and the start time of the talk (port of AdaptiveTimerService).
public final class AdaptiveTimerService {
    static let largestDeviationMinutes: Double = 15
    static let smallestDeviationSecs: Double = 15

    private let optionsProvider: () -> Options
    private let itemsProvider: () -> [TalkScheduleItem]
    private let dateTime: DateTimeProvider
    private let calendar: Calendar

    private var meetingStartTime: Date?
    private var meetingStartTimeFromCountdown: Date?

    public init(optionsProvider: @escaping () -> Options,
                itemsProvider: @escaping () -> [TalkScheduleItem],
                dateTime: DateTimeProvider,
                calendar: Calendar = .current) {
        self.optionsProvider = optionsProvider
        self.itemsProvider = itemsProvider
        self.dateTime = dateTime
        self.calendar = calendar
    }

    public func setMeetingStartTimeForTesting(_ date: Date) {
        meetingStartTime = date
    }

    /// Forget the meeting start (e.g. at the end of a meeting).
    public func resetMeetingStart() {
        meetingStartTime = nil
    }

    /// The countdown window opened (showing = true) or closed.
    public func countdownStatusChanged(showing: Bool) {
        meetingStartTimeFromCountdown = showing ? nil : DateUtils.nearestMinute(dateTime.now())
    }

    private func item(_ id: Int) -> TalkScheduleItem? {
        itemsProvider().first { $0.id == id }
    }

    /// Calculates the adapted talk duration (nil if the duration isn't adapted).
    public func calculateAdaptedDuration(_ itemId: Int) -> TimeInterval? {
        guard let talk = item(itemId) else {
            return nil
        }
        ensureMeetingStartTimeIsSet(talk)
        guard meetingStartTime != nil else {
            return nil
        }

        let adaptiveMode = optionsProvider().effectiveAdaptiveMode
        if adaptiveMode == .none || !talk.allowAdaptive {
            return nil
        }

        guard let mtgEnd = plannedMeetingEnd() else {
            return nil
        }
        let totalTimeRemaining = mtgEnd.timeIntervalSince(dateTime.now())
        let remainingProgramTimeRequired = remainingProgramTime(from: talk)
        let deviation = totalTimeRemaining - remainingProgramTimeRequired

        if !isDeviationSignificant(deviation) {
            return nil
        }

        if adaptiveMode != .twoWay && totalTimeRemaining >= remainingProgramTimeRequired {
            // there is time in hand and we don't want to increase talk durations.
            return nil
        }

        let remainingAdaptiveTime = remainingAdaptiveTimerValues(from: talk)
        guard remainingAdaptiveTime > 0 else {
            return nil
        }

        let fraction = Double(talk.plannedDurationSeconds) / remainingAdaptiveTime
        let secondsToApply = deviation * fraction
        return talk.actualDuration + secondsToApply
    }

    /// Meeting over/under-run (negative = overrun), or nil if not significant.
    public func calculateMeetingOverrun(_ talkId: Int) -> TimeInterval? {
        guard let talk = item(talkId) else {
            return nil
        }
        ensureMeetingStartTimeIsSet(talk)
        guard meetingStartTime != nil else {
            return nil
        }
        if optionsProvider().effectiveAdaptiveMode == .none {
            return nil
        }
        guard let mtgEnd = plannedMeetingEnd() else {
            return nil
        }
        let totalTimeRemaining = mtgEnd.timeIntervalSince(dateTime.now())
        var remainingProgramTimeRequired = remainingProgramTime(from: talk)

        switch TalkTypesAutoMode(rawValue: talkId) {
        case .livingPart1?:
            remainingProgramTimeRequired += 3.5 * 60 // "interval" song
        case .watchtower?:
            remainingProgramTimeRequired += 5 * 60   // "interval" song
        default:
            break
        }

        let deviation = totalTimeRemaining - remainingProgramTimeRequired
        let mins = abs(deviation / 60)
        // only report over/underrun if between 2 and 20 mins (anything above 20 is likely an error).
        guard mins >= 2 && mins <= 20 else {
            return nil
        }
        return deviation
    }

    // MARK: private

    private func remainingProgramTime(from talk: TalkScheduleItem) -> TimeInterval {
        let items = itemsProvider()
        guard let last = items.last else {
            return 0
        }
        var result: TimeInterval = 0
        var started = false
        for n in items.indices {
            let item = items[n]
            if item === talk {
                started = true
            }
            if started {
                result += item.plannedDuration
                if item !== last {
                    result += changeover(item, items[n + 1])
                }
            }
        }
        return result
    }

    private func changeover(_ item1: TalkScheduleItem, _ item2: TalkScheduleItem) -> TimeInterval {
        let endItem1 = item1.startOffsetIntoMeeting + item1.originalDuration
        return item2.startOffsetIntoMeeting - endItem1
    }

    private func plannedMeetingEnd() -> Date? {
        guard let start = meetingStartTime, let last = itemsProvider().last else {
            return nil
        }
        return start.addingTimeInterval(last.startOffsetIntoMeeting + last.originalDuration)
    }

    private func ensureMeetingStartTimeIsSet(_ talk: TalkScheduleItem) {
        if let start = meetingStartTime, !calendar.isDate(start, inSameDayAs: dateTime.now()) {
            // stale value from a previous day
            meetingStartTime = nil
        }
        if meetingStartTime == nil {
            setMeetingStart(talk)
        }
    }

    private func setMeetingStart(_ talk: TalkScheduleItem) {
        let options = optionsProvider()
        guard options.operatingMode == .automatic else {
            return
        }

        var start: Date?
        switch options.midWeekOrWeekend {
        case .weekend:
            if talk.id == TalkTypesAutoMode.publicTalk.rawValue {
                start = DateUtils.nearest15MinsBefore(dateTime.now(), calendar: calendar)
            }
        case .midWeek:
            if talk.id == TalkTypesAutoMode.openingComments.rawValue || talk.id == TalkTypesAutoMode.treasuresTalk.rawValue {
                start = DateUtils.nearest15MinsBefore(dateTime.now(), calendar: calendar)
            }
        case .unknown:
            break
        }

        if start == nil {
            meetingStartTime = meetingStartTimeFromCountdown
        } else if let fromCountdown = meetingStartTimeFromCountdown, let s = start {
            // prefer the start time provided by the countdown if within a reasonable time frame
            let diff = fromCountdown.timeIntervalSince(s)
            meetingStartTime = abs(diff) < 10 * 60 ? fromCountdown : s
        } else {
            meetingStartTime = start
        }
    }

    private func isDeviationSignificant(_ deviation: TimeInterval) -> Bool {
        abs(deviation) > AdaptiveTimerService.smallestDeviationSecs
            && abs(deviation / 60) <= AdaptiveTimerService.largestDeviationMinutes
    }

    private func remainingAdaptiveTimerValues(from talk: TalkScheduleItem) -> TimeInterval {
        var result: TimeInterval = 0
        var started = false
        for item in itemsProvider() {
            if item === talk {
                started = true
            }
            if started && item.allowAdaptive {
                result += item.plannedDuration
            }
        }
        return result
    }
}
