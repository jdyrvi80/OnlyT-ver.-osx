import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// Talk types used by the online meeting feed.
public enum FeedTalkType: Int {
    case unknown = 0
    case pre2019Ministry1 = 1
    case pre2019Ministry2 = 2
    case pre2019Ministry3 = 3
    case pre2019Living1 = 4
    case pre2019Living2 = 5
    case ministry1 = 100
    case ministry2 = 101
    case ministry3 = 102
    case ministry4 = 103
    case living1 = 300
    case living2 = 301

    static func parse(_ value: Any?) -> FeedTalkType {
        if let n = value as? Int {
            return FeedTalkType(rawValue: n) ?? .unknown
        }
        if let n = value as? Double {
            return FeedTalkType(rawValue: Int(n)) ?? .unknown
        }
        if let s = value as? String {
            if let n = Int(s) {
                return FeedTalkType(rawValue: n) ?? .unknown
            }
            switch s.lowercased() {
            case "pre2019ministry1": return .pre2019Ministry1
            case "pre2019ministry2": return .pre2019Ministry2
            case "pre2019ministry3": return .pre2019Ministry3
            case "pre2019living1": return .pre2019Living1
            case "pre2019living2": return .pre2019Living2
            case "ministry1": return .ministry1
            case "ministry2": return .ministry2
            case "ministry3": return .ministry3
            case "ministry4": return .ministry4
            case "living1": return .living1
            case "living2": return .living2
            default: return .unknown
            }
        }
        return .unknown
    }

    static func ministry(_ index: Int) -> FeedTalkType {
        switch index {
        case 0: return .ministry1
        case 1: return .ministry2
        case 2: return .ministry3
        case 3: return .ministry4
        default: return .unknown
        }
    }
}

public struct FeedTalkTimer: Equatable {
    public var talkType: FeedTalkType
    public var minutes: Int
    public var isStudentTalk: Bool

    public init(talkType: FeedTalkType, minutes: Int, isStudentTalk: Bool) {
        self.talkType = talkType
        self.minutes = minutes
        self.isStudentTalk = isStudentTalk
    }
}

public struct FeedMeeting: Equatable {
    /// Local date (start of day) of the Monday of the meeting week.
    public var date: Date
    public var talks: [FeedTalkTimer]

    public init(date: Date, talks: [FeedTalkTimer]) {
        self.date = date
        self.talks = talks
    }

    public func talk(_ type: FeedTalkType) -> FeedTalkTimer? {
        talks.first { $0.talkType == type }
    }

    /// Sample data, as used by the original unit tests.
    public static func sampleForTesting(_ date: Date) -> FeedMeeting {
        FeedMeeting(date: date, talks: [
            FeedTalkTimer(talkType: .ministry1, minutes: 4, isStudentTalk: false),
            FeedTalkTimer(talkType: .ministry2, minutes: 2, isStudentTalk: true),
            FeedTalkTimer(talkType: .ministry3, minutes: 3, isStudentTalk: true),
            FeedTalkTimer(talkType: .ministry4, minutes: 3, isStudentTalk: true),
            FeedTalkTimer(talkType: .living1, minutes: 15, isStudentTalk: false),
        ])
    }
}

/// Downloads (and caches) the meeting feed, as OnlyT's TimesFeed does.
public enum TimesFeed {
    public static let tooOldDays: Double = 20

    /// Parses the JSON feed (array of meetings). Field names are matched case-insensitively.
    public static func parse(_ data: Data, calendar: Calendar = .current) -> [FeedMeeting]? {
        guard let array = (try? JSONSerialization.jsonObject(with: data)) as? [Any] else {
            return nil
        }
        var result: [FeedMeeting] = []
        for entry in array {
            guard let dict = lowercasedKeys(entry as? [String: Any]),
                  let date = parseDate(dict["date"], calendar: calendar) else {
                continue
            }
            var talks: [FeedTalkTimer] = []
            for t in (dict["talks"] as? [Any]) ?? [] {
                guard let td = lowercasedKeys(t as? [String: Any]) else {
                    continue
                }
                let type = FeedTalkType.parse(td["talktype"])
                let minutes = (td["minutes"] as? Int) ?? Int((td["minutes"] as? Double) ?? 0)
                let student = (td["isstudenttalk"] as? Bool) ?? false
                talks.append(FeedTalkTimer(talkType: type, minutes: minutes, isStudentTalk: student))
            }
            result.append(FeedMeeting(date: date, talks: talks))
        }
        return result
    }

    public static func meetingForDay(_ meetings: [FeedMeeting]?, day: Date, calendar: Calendar = .current) -> FeedMeeting? {
        let monday = DateUtils.mondayOfWeek(day, calendar: calendar)
        return meetings?.first { calendar.isDate($0.date, inSameDayAs: monday) }
    }

    /// Returns today's meeting data. Uses the cache if recent enough, otherwise downloads.
    /// This is a blocking call: run it off the main thread.
    public static func load(feedURL: URL, cacheURL: URL, today: Date, allowDownload: Bool = true, timeout: TimeInterval = 10) -> FeedMeeting? {
        var meetings: [FeedMeeting]?
        var needRefresh = true

        if let attrs = try? FileManager.default.attributesOfItem(atPath: cacheURL.path),
           let modified = attrs[.modificationDate] as? Date,
           today.timeIntervalSince(modified) / 86_400 <= tooOldDays,
           let data = try? Data(contentsOf: cacheURL),
           let parsed = parse(data), !parsed.isEmpty {
            meetings = parsed
            needRefresh = meetingForDay(parsed, day: today) == nil
        }

        if needRefresh && allowDownload {
            if let data = download(feedURL, timeout: timeout), let parsed = parse(data), !parsed.isEmpty {
                meetings = parsed
                try? FileManager.default.createDirectory(at: cacheURL.deletingLastPathComponent(), withIntermediateDirectories: true)
                try? data.write(to: cacheURL, options: .atomic)
            }
        }
        return meetingForDay(meetings, day: today)
    }

    static func download(_ url: URL, timeout: TimeInterval) -> Data? {
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: timeout)
        request.setValue("OnlyT for Mac (+https://soundboxsoftware.com)", forHTTPHeaderField: "User-Agent")
        let semaphore = DispatchSemaphore(value: 0)
        var result: Data?
        let task = URLSession.shared.dataTask(with: request) { data, response, _ in
            if let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) {
                result = data
            }
            semaphore.signal()
        }
        task.resume()
        _ = semaphore.wait(timeout: .now() + timeout + 2)
        return result
    }

    private static func lowercasedKeys(_ d: [String: Any]?) -> [String: Any]? {
        guard let d = d else {
            return nil
        }
        var r: [String: Any] = [:]
        for (k, v) in d {
            r[k.lowercased()] = v
        }
        return r
    }

    private static func parseDate(_ value: Any?, calendar: Calendar) -> Date? {
        guard let s = value as? String, s.count >= 10 else {
            return nil
        }
        let datePart = String(s.prefix(10)) // yyyy-MM-dd
        let parts = datePart.split(separator: "-").compactMap { Int($0) }
        guard parts.count == 3 else {
            return nil
        }
        var comps = DateComponents()
        comps.year = parts[0]
        comps.month = parts[1]
        comps.day = parts[2]
        return calendar.date(from: comps).map { calendar.startOfDay(for: $0) }
    }
}
