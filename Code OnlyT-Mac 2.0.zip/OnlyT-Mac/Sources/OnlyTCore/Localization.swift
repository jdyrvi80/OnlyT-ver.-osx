import Foundation

/// Locates bundled resources: inside the .app (Contents/Resources), next to the
/// executable, or in the source tree's "Resources" folder when run with `swift run`.
public enum ResourceLocator {
    public static var extraSearchFolders: [URL] = []

    public static func url(_ relativePath: String) -> URL? {
        var candidates: [URL] = []
        candidates.append(contentsOf: extraSearchFolders)
        if let res = Bundle.main.resourceURL {
            candidates.append(res)
        }
        let exe = URL(fileURLWithPath: CommandLine.arguments.first ?? "").deletingLastPathComponent()
        candidates.append(exe)
        candidates.append(exe.appendingPathComponent("Resources"))
        // Sources/OnlyTCore/Localization.swift -> <root>/Resources
        let sourceRoot = URL(fileURLWithPath: #filePath)
            .deletingLastPathComponent()
            .deletingLastPathComponent()
            .deletingLastPathComponent()
        candidates.append(sourceRoot.appendingPathComponent("Resources"))

        for folder in candidates {
            let u = folder.appendingPathComponent(relativePath)
            if FileManager.default.fileExists(atPath: u.path) {
                return u
            }
        }
        return nil
    }

    public static func string(_ relativePath: String) -> String? {
        guard let u = url(relativePath) else {
            return nil
        }
        return try? String(contentsOf: u, encoding: .utf8)
    }
}

/// Simple localisation layer using the translations of the original OnlyT
/// (converted from its .resx files into Localizable.json).
public final class L10n {
    public static let shared = L10n()

    private let lock = NSLock()
    private var tables: [String: [String: String]] = [:]
    private var currentCode = "en"

    private init() {
        if let url = ResourceLocator.url("Localizable.json"),
           let data = try? Data(contentsOf: url),
           let json = try? JSONSerialization.jsonObject(with: data) as? [String: [String: String]] {
            tables = json
        }
        currentCode = L10n.bestMatch(for: Locale.preferredLanguages, available: Array(tables.keys))
    }

    /// Language codes available (e.g. "en", "it-IT", "de-DE").
    public var availableLanguages: [String] {
        lock.lock()
        defer { lock.unlock() }
        return tables.keys.sorted()
    }

    public var languageCode: String {
        lock.lock()
        defer { lock.unlock() }
        return currentCode
    }

    /// Sets the language (nil = system language).
    public func setLanguage(_ code: String?) {
        let available = availableLanguages
        let chosen: String
        if let code = code, available.contains(code) {
            chosen = code
        } else {
            chosen = L10n.bestMatch(for: Locale.preferredLanguages, available: available)
        }
        lock.lock()
        currentCode = chosen
        lock.unlock()
    }

    public func string(_ key: String) -> String {
        lock.lock()
        defer { lock.unlock() }
        if let v = tables[currentCode]?[key], !v.isEmpty {
            return v
        }
        if let v = tables["en"]?[key] {
            return v
        }
        return key
    }

    /// Display name of a language code, in that language.
    public static func displayName(for code: String) -> String {
        let loc = Locale(identifier: code)
        let name = loc.localizedString(forIdentifier: code) ?? code
        return name.prefix(1).uppercased() + name.dropFirst()
    }

    static func bestMatch(for preferred: [String], available: [String]) -> String {
        for pref in preferred {
            let normalised = pref.replacingOccurrences(of: "_", with: "-")
            if available.contains(normalised) {
                return normalised
            }
            let lang = normalised.split(separator: "-").first.map(String.init) ?? normalised
            if lang == "en" {
                return "en"
            }
            if let match = available.first(where: { $0 == lang || $0.hasPrefix(lang + "-") }) {
                return match
            }
        }
        return available.contains("en") ? "en" : (available.first ?? "en")
    }

    // MARK: convenience

    public static func t(_ key: String) -> String {
        shared.string(key)
    }

    /// Replaces .NET style placeholders {0}, {1}...
    public static func f(_ key: String, _ args: CVarArg...) -> String {
        var s = shared.string(key)
        for (i, a) in args.enumerated() {
            s = s.replacingOccurrences(of: "{\(i)}", with: "\(a)")
        }
        return s
    }
}
