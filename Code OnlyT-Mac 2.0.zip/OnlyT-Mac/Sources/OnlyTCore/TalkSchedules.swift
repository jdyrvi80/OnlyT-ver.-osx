import Foundation
#if canImport(FoundationXML)
import FoundationXML
#endif

// MARK: - Automatic mode

/// The talk schedule in "Automatic" operating mode (port of TalkScheduleAuto).
public enum TalkScheduleAuto {
    // midweek meeting sections.
    static let sectionTreasures = "Treasures"
    static let sectionMinistry = "Ministry"
    static let sectionLiving = "Living"
    // weekend sections.
    static let sectionWeekend = "Weekend"

    public static func build(options: Options, feed: FeedMeeting?, isJanuary2020OrLater: Bool = true) -> [TalkScheduleItem] {
        if options.midWeekOrWeekend == .weekend {
            return weekendSchedule(isCircuitVisit: options.isCircuitVisit)
        }
        return midweekSchedule(
            isCircuitVisit: options.isCircuitVisit,
            autoBell: options.isBellEnabled && options.autoBell,
            isJanuary2020OrLater: isJanuary2020OrLater,
            meetingData: feed)
    }

    public static func midweekScheduleForTesting(_ date: Date, isJanuary2020OrLater: Bool = true) -> [TalkScheduleItem] {
        midweekSchedule(isCircuitVisit: false, autoBell: false, isJanuary2020OrLater: isJanuary2020OrLater,
                        meetingData: FeedMeeting.sampleForTesting(date))
    }

    static func minutes(_ m: Double) -> TimeInterval { m * 60 }

    static func hms(_ h: Int, _ m: Int, _ s: Int) -> TimeInterval {
        TimeInterval(h * 3600 + m * 60 + s)
    }

    private static func treasuresItem(_ type: TalkTypesAutoMode, _ name: String, _ start: TimeInterval, _ duration: TimeInterval,
                                      isStudentTalk: Bool, useBell: Bool, autoBell: Bool, persist: Bool) -> TalkScheduleItem {
        let t = TalkScheduleItem(type: type, name: name, sectionInternal: sectionTreasures, sectionLocalised: L10n.t("SECTION_TREASURES"))
        t.startOffsetIntoMeeting = start
        t.originalDuration = duration
        t.bellApplicable = useBell
        t.autoBell = autoBell
        t.isStudentTalk = isStudentTalk
        t.persistFinalTimerValue = persist
        t.editable = true
        return t
    }

    private static func treasuresSchedule(autoBell: Bool, isJanuary2020OrLater: Bool) -> [TalkScheduleItem] {
        if isJanuary2020OrLater {
            return [
                treasuresItem(.openingComments, L10n.t("TALK_OPENING_COMMENTS"), hms(0, 5, 0), minutes(1),
                              isStudentTalk: false, useBell: false, autoBell: autoBell, persist: false),
                treasuresItem(.treasuresTalk, L10n.t("TALK_TREASURES"), hms(0, 6, 20), minutes(10),
                              isStudentTalk: false, useBell: false, autoBell: autoBell, persist: false),
                treasuresItem(.diggingTalk, L10n.t("TALK_DIGGING"), hms(0, 16, 40), minutes(10),
                              isStudentTalk: false, useBell: false, autoBell: autoBell, persist: false),
                treasuresItem(.reading, L10n.t("TALK_READING"), hms(0, 27, 0), minutes(4),
                              isStudentTalk: true, useBell: true, autoBell: autoBell, persist: true),
            ]
        }
        return [
            treasuresItem(.openingComments, L10n.t("TALK_OPENING_COMMENTS"), hms(0, 5, 0), minutes(3),
                          isStudentTalk: false, useBell: false, autoBell: autoBell, persist: false),
            treasuresItem(.treasuresTalk, L10n.t("TALK_TREASURES"), hms(0, 8, 20), minutes(10),
                          isStudentTalk: false, useBell: false, autoBell: autoBell, persist: false),
            treasuresItem(.diggingTalk, L10n.t("TALK_DIGGING"), hms(0, 18, 40), minutes(8),
                          isStudentTalk: false, useBell: false, autoBell: autoBell, persist: false),
            treasuresItem(.reading, L10n.t("TALK_READING"), hms(0, 27, 0), minutes(4),
                          isStudentTalk: true, useBell: true, autoBell: autoBell, persist: true),
        ]
    }

    private static func ministryTitle(_ item: Int) -> String {
        switch item {
        case 1: return L10n.t("MINISTRY1")
        case 2: return L10n.t("MINISTRY2")
        case 3: return L10n.t("MINISTRY3")
        default: return L10n.t("MINISTRY4")
        }
    }

    private static func ministryType(_ index: Int) -> TalkTypesAutoMode {
        switch index {
        case 0: return .ministryItem1
        case 1: return .ministryItem2
        case 2: return .ministryItem3
        case 3: return .ministryItem4
        default: return .unknown
        }
    }

    private static func ministrySchedule(meetingData: FeedMeeting?, autoBell: Bool) -> [TalkScheduleItem] {
        var timers: [FeedTalkTimer] = []
        for n in 0..<4 {
            let type = FeedTalkType.ministry(n)
            if let meeting = meetingData {
                if let item = meeting.talk(type) {
                    timers.append(item)
                }
            } else {
                // failed to download the schedule: 3 mins is as good a guess as any
                timers.append(FeedTalkTimer(talkType: type, minutes: 3, isStudentTalk: true))
            }
        }

        var result: [TalkScheduleItem] = []
        var startOffset = hms(0, 32, 20)
        for (n, timer) in timers.enumerated() {
            let t = TalkScheduleItem(type: ministryType(n), name: ministryTitle(n + 1),
                                     sectionInternal: sectionMinistry, sectionLocalised: L10n.t("SECTION_MINISTRY"))
            t.startOffsetIntoMeeting = startOffset
            t.originalDuration = minutes(Double(timer.minutes))
            t.bellApplicable = timer.isStudentTalk
            t.autoBell = autoBell
            t.persistFinalTimerValue = timer.isStudentTalk
            t.editable = true
            t.isStudentTalk = timer.isStudentTalk
            result.append(t)

            startOffset += minutes(Double(timer.minutes))
            if timer.isStudentTalk {
                startOffset += minutes(1) // counsel
            }
            startOffset += 20
        }
        return result
    }

    private static func livingItem(_ type: TalkTypesAutoMode, _ name: String, _ start: TimeInterval, _ duration: TimeInterval) -> TalkScheduleItem {
        let t = TalkScheduleItem(type: type, name: name, sectionInternal: sectionLiving, sectionLocalised: L10n.t("SECTION_LIVING"))
        t.startOffsetIntoMeeting = start
        t.originalDuration = duration
        t.editable = true
        t.allowAdaptive = true
        return t
    }

    private static func livingSchedule(isCircuitVisit: Bool, meetingData: FeedMeeting?) -> [TalkScheduleItem] {
        let part1Mins = meetingData?.talk(.living1)?.minutes ?? 15
        let part2Mins = meetingData?.talk(.living2)?.minutes ?? 0

        var result: [TalkScheduleItem] = [
            livingItem(.livingPart1, L10n.t("TALK_LIVING1"), hms(0, 51, 40), minutes(Double(part1Mins))),
            livingItem(.livingPart2, L10n.t("TALK_LIVING2"), hms(0, 51, 40) + minutes(Double(part1Mins)), minutes(Double(part2Mins))),
        ]

        if isCircuitVisit {
            result.append(livingItem(.concludingComments, L10n.t("TALK_CONCLUDING_COMMENTS"), hms(1, 7, 0), minutes(3)))
            result.append(livingItem(.circuitServiceTalk, L10n.t("TALK_SERVICE"), hms(1, 10, 0), minutes(30)))
        } else {
            result.append(livingItem(.congBibleStudy, L10n.t("TALK_CONG_STUDY"), hms(1, 7, 0), minutes(30)))
            result.append(livingItem(.concludingComments, L10n.t("TALK_CONCLUDING_COMMENTS"), hms(1, 37, 0), minutes(3)))
        }
        return result
    }

    static func midweekSchedule(isCircuitVisit: Bool, autoBell: Bool, isJanuary2020OrLater: Bool, meetingData: FeedMeeting?) -> [TalkScheduleItem] {
        treasuresSchedule(autoBell: autoBell, isJanuary2020OrLater: isJanuary2020OrLater)
            + ministrySchedule(meetingData: meetingData, autoBell: autoBell)
            + livingSchedule(isCircuitVisit: isCircuitVisit, meetingData: meetingData)
    }

    private static func weekendItem(_ type: TalkTypesAutoMode, _ name: String, _ start: TimeInterval, _ duration: TimeInterval, allowAdaptive: Bool) -> TalkScheduleItem {
        let t = TalkScheduleItem(type: type, name: name, sectionInternal: sectionWeekend, sectionLocalised: L10n.t("SECTION_WEEKEND"))
        t.startOffsetIntoMeeting = start
        t.originalDuration = duration
        t.editable = true
        t.allowAdaptive = allowAdaptive
        return t
    }

    static func weekendSchedule(isCircuitVisit: Bool) -> [TalkScheduleItem] {
        if isCircuitVisit {
            return [
                weekendItem(.publicTalk, L10n.t("TALK_PUBLIC"), hms(0, 5, 0), minutes(30), allowAdaptive: false),
                weekendItem(.watchtower, L10n.t("TALK_WT"), hms(0, 40, 0), minutes(30), allowAdaptive: true),
                weekendItem(.circuitServiceTalk, L10n.t("TALK_CONCLUDING"), hms(0, 70, 0), minutes(30), allowAdaptive: true),
            ]
        }
        return [
            weekendItem(.publicTalk, L10n.t("TALK_PUBLIC"), hms(0, 5, 0), minutes(30), allowAdaptive: false),
            weekendItem(.watchtower, L10n.t("TALK_WT"), hms(0, 40, 0), minutes(60), allowAdaptive: true),
        ]
    }
}

// MARK: - Manual mode

public enum TalkScheduleManual {
    public static let talkId = 10000

    public static func build(options: Options) -> [TalkScheduleItem] {
        let t = TalkScheduleItem(id: talkId, name: L10n.t("MANUAL_MODE"), sectionInternal: "", sectionLocalised: "")
        t.originalDuration = 30 * 60
        t.editable = true
        t.bellApplicable = options.isBellEnabled
        t.autoBell = options.autoBell
        return [t]
    }
}

// MARK: - File-based mode

/// Reads a schedule XML file (same format as the original OnlyT):
/// <meeting><items><item name=".." section=".." duration="hh:mm:ss" editable="true"
/// bell="true" countup="false" persist="true" closing="60" /></items></meeting>
public enum TalkScheduleFileBased {
    public static let startId = 5000

    public static func read(url: URL, autoBell: Bool) -> [TalkScheduleItem] {
        guard let parser = XMLParser(contentsOf: url) else {
            return []
        }
        let delegate = ScheduleXMLDelegate()
        parser.delegate = delegate
        guard parser.parse() else {
            return []
        }

        var result: [TalkScheduleItem] = []
        var talkId = startId
        for attrs in delegate.items {
            let a = Dictionary(attrs.map { ($0.key.lowercased(), $0.value) }, uniquingKeysWith: { first, _ in first })
            let name = a["name"] ?? "Unknown name \(talkId)"
            let section = a["section"] ?? "Unknown section \(talkId)"
            let t = TalkScheduleItem(id: talkId, name: name, sectionInternal: section, sectionLocalised: section)
            t.countUp = nullableBool(a["countup"])
            t.closingSecs = int(a["closingsecs"] ?? a["closing"], TalkScheduleItem.defaultClosingSecs)
            t.originalDuration = duration(a["duration"])
            t.editable = bool(a["editable"], false)
            t.bellApplicable = bool(a["bell"], false)
            t.autoBell = autoBell
            t.persistFinalTimerValue = bool(a["persist"], false)
            result.append(t)
            talkId += 1
        }
        return result
    }

    static func nullableBool(_ s: String?) -> Bool? {
        guard let s = s?.trimmingCharacters(in: .whitespaces), !s.isEmpty else {
            return nil
        }
        switch s.lowercased() {
        case "true", "1", "yes": return true
        case "false", "0", "no": return false
        default: return nil
        }
    }

    static func bool(_ s: String?, _ def: Bool) -> Bool {
        nullableBool(s) ?? def
    }

    static func int(_ s: String?, _ def: Int) -> Int {
        guard let s = s?.trimmingCharacters(in: .whitespaces), !s.isEmpty, let v = Int(s) else {
            return def
        }
        return v
    }

    /// Parses "hh:mm:ss", "hh:mm" (like .NET TimeSpan) or a plain number of minutes.
    static func duration(_ s: String?) -> TimeInterval {
        guard let s = s?.trimmingCharacters(in: .whitespaces), !s.isEmpty else {
            return 0
        }
        let parts = s.split(separator: ":").map { String($0) }
        switch parts.count {
        case 1:
            return (Double(parts[0]) ?? 0) * 60
        case 2:
            return Double((Int(parts[0]) ?? 0) * 3600 + (Int(parts[1]) ?? 0) * 60)
        default:
            var hours = 0.0
            let hourPart = parts[0]
            if hourPart.contains(".") {
                // d.hh
                let dh = hourPart.split(separator: ".")
                hours = (Double(dh.first ?? "0") ?? 0) * 24 + (Double(dh.last ?? "0") ?? 0)
            } else {
                hours = Double(hourPart) ?? 0
            }
            let mins = Double(parts[1]) ?? 0
            let secs = Double(parts[2]) ?? 0
            return hours * 3600 + mins * 60 + secs
        }
    }
}

private final class ScheduleXMLDelegate: NSObject, XMLParserDelegate {
    var items: [[String: String]] = []
    private var path: [String] = []

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?,
                qualifiedName qName: String?, attributes attributeDict: [String: String] = [:]) {
        path.append(elementName.lowercased())
        // root/items/item
        if path.count == 3 && path[1] == "items" && path[2] == "item" {
            items.append(attributeDict)
        }
    }

    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if !path.isEmpty {
            path.removeLast()
        }
    }
}

// MARK: - Schedule service

/// Delivers the talk schedule according to the operating mode (port of TalkScheduleService).
public final class TalkScheduleService {
    public var optionsProvider: () -> Options
    public let schedulesFolder: URL
    public let legacyScheduleFile: URL

    /// Meeting data for the current week (from the online feed).
    public var feedMeeting: FeedMeeting?
    /// True once the online feed has provided this week's midweek data.
    public var feedSucceeded = false

    /// Called when, in file mode, the schedule file can't be found (the app reverts to manual mode).
    public var onScheduleFileNotFound: (() -> Void)?
    /// Called when the service picks a different schedule file automatically.
    public var onScheduleFileAutoSelected: ((String) -> Void)?

    /// Edited schedules (nil = editing not available).
    public var customStore: CustomScheduleStore?
    /// Current date (used to key edited automatic schedules by week).
    public var dateProvider: () -> Date = { Date() }

    private var fileBased: [TalkScheduleItem]?
    private var auto: [TalkScheduleItem]?
    private var manual: [TalkScheduleItem]?
    private var customCache: (key: String, items: [TalkScheduleItem]?)?

    public init(optionsProvider: @escaping () -> Options, schedulesFolder: URL, legacyScheduleFile: URL) {
        self.optionsProvider = optionsProvider
        self.schedulesFolder = schedulesFolder
        self.legacyScheduleFile = legacyScheduleFile
    }

    public func reset() {
        fileBased = nil
        auto = nil
        manual = nil
        customCache = nil
    }

    // MARK: edited schedules

    /// Identifies the schedule being shown: an edit applies to this context only.
    public func contextKey(_ options: Options) -> String {
        switch options.operatingMode {
        case .automatic:
            let monday = DateUtils.mondayOfWeek(dateProvider())
            let c = Calendar.current.dateComponents([.year, .month, .day], from: monday)
            let meeting = options.midWeekOrWeekend == .weekend ? "weekend" : "midweek"
            let week = String(format: "%04d-%02d-%02d", c.year ?? 0, c.month ?? 0, c.day ?? 0)
            return "auto|\(meeting)|co\(options.isCircuitVisit ? 1 : 0)|\(week)"
        case .scheduleFile:
            return "file|\((options.scheduleFile ?? "").lowercased())"
        case .manual:
            return "manual"
        }
    }

    private func customItems(_ options: Options) -> [TalkScheduleItem]? {
        guard let store = customStore else {
            return nil
        }
        let key = contextKey(options)
        if let cached = customCache, cached.key == key {
            return cached.items
        }
        var built: [TalkScheduleItem]?
        if let stored = store.items(for: key), !stored.isEmpty {
            let autoBell = options.operatingMode == .automatic ? (options.isBellEnabled && options.autoBell) : options.autoBell
            built = stored.map { $0.makeItem(autoBell: autoBell) }
        }
        customCache = (key, built)
        return built
    }

    /// True when the current schedule has been edited by the user.
    public var hasCustomSchedule: Bool {
        customItems(optionsProvider()) != nil
    }

    /// Replaces the current schedule with an edited one (nil = back to the original).
    public func setCustom(_ newItems: [TalkScheduleItem]?) {
        let key = contextKey(optionsProvider())
        customStore?.set(newItems?.map { CustomTalkItem($0) }, for: key, now: dateProvider())
        customCache = (key, newItems)
    }

    public var items: [TalkScheduleItem] {
        let options = optionsProvider()
        if let custom = customItems(options) {
            return custom
        }
        switch options.operatingMode {
        case .scheduleFile:
            guard let url = resolveScheduleFile(options: options) else {
                if let cb = onScheduleFileNotFound {
                    DispatchQueue.main.async(execute: cb)
                }
                return manualItems(options)
            }
            if fileBased == nil {
                fileBased = TalkScheduleFileBased.read(url: url, autoBell: options.autoBell)
            }
            return fileBased ?? []
        case .automatic:
            if auto == nil {
                auto = TalkScheduleAuto.build(options: options, feed: feedMeeting)
            }
            return auto ?? []
        case .manual:
            return manualItems(options)
        }
    }

    private func manualItems(_ options: Options) -> [TalkScheduleItem] {
        if manual == nil {
            manual = TalkScheduleManual.build(options: options)
        }
        return manual ?? []
    }

    public func item(_ id: Int) -> TalkScheduleItem? {
        items.first { $0.id == id }
    }

    public func setModifiedDuration(_ id: Int, _ duration: TimeInterval?) {
        item(id)?.modifiedDuration = duration
    }

    /// Id of the next talk (0 if none). Items with zero duration are skipped.
    public func next(after currentId: Int) -> Int {
        let talks = items
        // a single manual timer is reused; an edited manual schedule advances like the others
        if optionsProvider().operatingMode == .manual && talks.count <= 1 {
            return talks.first?.id ?? 0
        }
        var foundCurrent = false
        for n in talks.indices {
            if talks[n].id == currentId {
                foundCurrent = true
            }
            if n != talks.count - 1 && foundCurrent && talks[n + 1].actualDuration != 0 {
                return talks[n + 1].id
            }
        }
        return 0
    }

    public func timerStopped(talkId: Int, elapsedSecs: Int) {
        item(talkId)?.completedTimeSecs = elapsedSecs
    }

    // MARK: schedule files

    public func scheduleFileNames() -> [String] {
        let files = (try? FileManager.default.contentsOfDirectory(atPath: schedulesFolder.path)) ?? []
        return files.filter { $0.lowercased().hasSuffix(".xml") }.sorted { $0.localizedStandardCompare($1) == .orderedAscending }
    }

    public func resolveScheduleFile(options: Options) -> URL? {
        let fm = FileManager.default
        if let name = options.scheduleFile, !name.isEmpty {
            let u = schedulesFolder.appendingPathComponent(name)
            if fm.fileExists(atPath: u.path) {
                return u
            }
        }
        if fm.fileExists(atPath: legacyScheduleFile.path) {
            let name = legacyScheduleFile.lastPathComponent
            if options.scheduleFile?.caseInsensitiveCompare(name) != .orderedSame {
                notifyAutoSelected(name)
            }
            return legacyScheduleFile
        }
        if let first = scheduleFileNames().first {
            if options.scheduleFile?.caseInsensitiveCompare(first) != .orderedSame {
                notifyAutoSelected(first)
            }
            return schedulesFolder.appendingPathComponent(first)
        }
        return nil
    }

    private func notifyAutoSelected(_ name: String) {
        if let cb = onScheduleFileAutoSelected {
            DispatchQueue.main.async {
                cb(name)
            }
        }
    }
}
