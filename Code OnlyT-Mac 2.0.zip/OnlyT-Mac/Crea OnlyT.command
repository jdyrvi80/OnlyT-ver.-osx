#!/bin/bash
# Doppio clic per creare OnlyT.app (si apre il Terminale).
cd "$(dirname "$0")" || exit 1

if ! command -v swift >/dev/null 2>&1; then
    echo "Swift non è installato."
    echo "Installa Xcode dall'App Store oppure esegui:  xcode-select --install"
    read -r -p "Premi Invio per chiudere…"
    exit 1
fi

./Scripts/build_app.sh && open -R "build/OnlyT.app"
echo ""
read -r -p "Premi Invio per chiudere…"
