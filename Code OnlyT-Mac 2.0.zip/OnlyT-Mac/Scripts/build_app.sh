#!/bin/bash
# Builds OnlyT.app (and a zip) from the Swift package.
# Requirements: macOS 13+ and Xcode (or the Xcode Command Line Tools).
#
#   ./Scripts/build_app.sh            -> build/OnlyT.app for this Mac
#   ./Scripts/build_app.sh universal  -> Intel + Apple Silicon (needs full Xcode)
set -euo pipefail

cd "$(dirname "$0")/.."
ROOT="$(pwd)"
APP="$ROOT/build/OnlyT.app"

echo "▸ Compilazione (release)…"
if [[ "${1:-}" == "universal" ]]; then
    swift build -c release --arch arm64 --arch x86_64
    BIN_DIR="$(swift build -c release --arch arm64 --arch x86_64 --show-bin-path)"
else
    swift build -c release
    BIN_DIR="$(swift build -c release --show-bin-path)"
fi

echo "▸ Creazione del pacchetto OnlyT.app…"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$BIN_DIR/OnlyT" "$APP/Contents/MacOS/OnlyT"
cp "$ROOT/Packaging/Info.plist" "$APP/Contents/Info.plist"
cp "$ROOT/Packaging/AppIcon.icns" "$APP/Contents/Resources/AppIcon.icns"
cp -R "$ROOT/Resources/." "$APP/Contents/Resources/"
printf 'APPL????' > "$APP/Contents/PkgInfo"

echo "▸ Firma ad-hoc…"
codesign --force --deep --sign - "$APP"

echo "▸ Archivio zip…"
(cd "$ROOT/build" && rm -f OnlyT-macOS.zip && ditto -c -k --keepParent OnlyT.app OnlyT-macOS.zip)

echo ""
echo "✅ Fatto: $APP"
echo "   Per avviarla: open \"$APP\"  (oppure trascinala in Applicazioni)"
