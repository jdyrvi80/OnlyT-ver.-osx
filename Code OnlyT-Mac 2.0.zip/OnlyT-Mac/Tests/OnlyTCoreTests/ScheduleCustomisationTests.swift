import XCTest
@testable import OnlyTCore

final class ScheduleCustomisationTests: XCTestCase {
    private func midweek() -> [TalkScheduleItem] {
        TalkScheduleAuto.midweekScheduleForTesting(Date(), isJanuary2020OrLater: true)
    }

    func testLayoutOfUneditedScheduleKeepsOriginalOffsets() {
        let items = midweek()
        let original = items.map { $0.startOffsetIntoMeeting }
        let gaps = ScheduleEditing.gapsAfter(items)
        ScheduleEditing.layOut(items, gaps: gaps, firstOffset: items[0].startOffsetIntoMeeting)
        XCTAssertEqual(items.map { $0.startOffsetIntoMeeting }, original)
    }

    func testAddedPartShiftsTheFollowingParts() {
        var items = midweek()
        let gaps = ScheduleEditing.gapsAfter(items)
        let readingIndex = items.firstIndex { $0.id == TalkTypesAutoMode.reading.rawValue }!
        let nextOffsetBefore = items[readingIndex + 1].startOffsetIntoMeeting

        let added = TalkScheduleItem(id: ScheduleEditing.firstCustomId, name: "Extra", sectionInternal: "", sectionLocalised: "")
        added.originalDuration = 120
        items.insert(added, at: readingIndex + 1)
        ScheduleEditing.layOut(items, gaps: gaps, firstOffset: items[0].startOffsetIntoMeeting)

        // the new part starts where the next part used to start...
        XCTAssertEqual(added.startOffsetIntoMeeting, nextOffsetBefore)
        // ...and the next part moves by the new part's duration + 20 s
        XCTAssertEqual(items[readingIndex + 2].startOffsetIntoMeeting, nextOffsetBefore + 120 + 20)
    }

    func testXmlRoundTrip() throws {
        let a = TalkScheduleItem(id: 1, name: "Benvenuto & \"saluti\"", sectionInternal: "Assemblea", sectionLocalised: "Assemblea")
        a.originalDuration = 180
        a.editable = true
        a.countUp = true
        let b = TalkScheduleItem(id: 2, name: "Discorso", sectionInternal: "Assemblea", sectionLocalised: "Assemblea")
        b.originalDuration = 3600
        b.bellApplicable = true
        b.persistFinalTimerValue = true
        b.closingSecs = 60

        let url = FileManager.default.temporaryDirectory.appendingPathComponent("onlyt-test-\(UUID().uuidString).xml")
        try ScheduleXMLWriter.xml([a, b]).write(to: url, atomically: true, encoding: .utf8)
        defer { try? FileManager.default.removeItem(at: url) }

        let read = TalkScheduleFileBased.read(url: url, autoBell: true)
        XCTAssertEqual(read.count, 2)
        XCTAssertEqual(read[0].name, a.name)
        XCTAssertEqual(read[0].meetingSectionNameLocalised, "Assemblea")
        XCTAssertEqual(read[0].originalDuration, 180)
        XCTAssertEqual(read[0].countUp, true)
        XCTAssertTrue(read[0].editable)
        XCTAssertEqual(read[1].originalDuration, 3600)
        XCTAssertTrue(read[1].bellApplicable)
        XCTAssertTrue(read[1].persistFinalTimerValue)
        XCTAssertEqual(read[1].closingSecs, 60)
        XCTAssertNil(read[1].countUp)
    }

    func testEditedScheduleReplacesTheOriginalUntilRestored() {
        var options = Options()
        options.operatingMode = .manual
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("onlyt-test-\(UUID().uuidString)")
        defer { try? FileManager.default.removeItem(at: folder) }

        let service = TalkScheduleService(optionsProvider: { options },
                                          schedulesFolder: folder,
                                          legacyScheduleFile: folder.appendingPathComponent("talk_schedule.xml"))
        service.customStore = CustomScheduleStore(fileURL: folder.appendingPathComponent("custom.json"))
        XCTAssertEqual(service.items.count, 1)
        XCTAssertFalse(service.hasCustomSchedule)

        let p1 = TalkScheduleItem(id: 20_000, name: "Uno", sectionInternal: "", sectionLocalised: "")
        p1.originalDuration = 60
        let p2 = TalkScheduleItem(id: 20_001, name: "Due", sectionInternal: "", sectionLocalised: "")
        p2.originalDuration = 120
        service.setCustom([p1, p2])

        XCTAssertTrue(service.hasCustomSchedule)
        XCTAssertEqual(service.items.map { $0.name }, ["Uno", "Due"])
        // an edited manual schedule advances from part to part
        XCTAssertEqual(service.next(after: 20_000), 20_001)

        // the edit is persisted
        let reloaded = TalkScheduleService(optionsProvider: { options },
                                           schedulesFolder: folder,
                                           legacyScheduleFile: folder.appendingPathComponent("talk_schedule.xml"))
        reloaded.customStore = CustomScheduleStore(fileURL: folder.appendingPathComponent("custom.json"))
        XCTAssertEqual(reloaded.items.map { $0.originalDuration }, [60, 120])

        // another mode is not affected
        options.operatingMode = .automatic
        XCTAssertFalse(service.hasCustomSchedule)
        options.operatingMode = .manual

        service.setCustom(nil)
        service.reset()
        XCTAssertFalse(service.hasCustomSchedule)
        XCTAssertEqual(service.items.count, 1)
    }

    func testDurationParser() {
        XCTAssertEqual(DurationParser.parse("05:00"), 300)
        XCTAssertEqual(DurationParser.parse("5"), 300)
        XCTAssertEqual(DurationParser.parse("4.30"), 270)
        XCTAssertEqual(DurationParser.parse(" 10 15 "), 615)
        XCTAssertNil(DurationParser.parse("5:75"))
        XCTAssertNil(DurationParser.parse("abc"))
        XCTAssertNil(DurationParser.parse("100:00"))
    }
}
