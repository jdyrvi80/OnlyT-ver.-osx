import XCTest
@testable import OnlyTCore

final class TalkItemTests: XCTestCase {
    func testOriginalDuration() {
        let item = TalkScheduleItem(id: 10000, name: "A Name", sectionInternal: "", sectionLocalised: "")
        item.originalDuration = 600
        XCTAssertEqual(item.actualDuration, 600)
        XCTAssertNil(item.modifiedDuration)
        XCTAssertNil(item.adaptedDuration)
        XCTAssertEqual(item.plannedDurationSeconds, 600)

        item.modifiedDuration = 1200
        XCTAssertEqual(item.originalDuration, 600)
        XCTAssertEqual(item.modifiedDuration, 1200)
        XCTAssertEqual(item.plannedDurationSeconds, 1200)

        // setting the modified duration back to the original clears it
        item.modifiedDuration = 600
        XCTAssertNil(item.modifiedDuration)
    }

    func testOvertimeString() {
        let item = TalkScheduleItem(id: 1, name: "x", sectionInternal: "", sectionLocalised: "")
        item.originalDuration = 240
        XCTAssertNil(item.overtimeString)
        item.completedTimeSecs = 250
        XCTAssertEqual(item.overtimeString, "+00:10")
        XCTAssertTrue(item.finishedOvertime)
        item.completedTimeSecs = 200
        XCTAssertEqual(item.overtimeString, "-00:40")
        XCTAssertFalse(item.finishedOvertime)
    }
}

final class DateCalcTests: XCTestCase {
    let cal = Calendar.current

    func testMondayOfWeek() {
        let monday = cal.date(from: DateComponents(year: 2018, month: 2, day: 12))!
        func add(_ d: Int) -> Date { cal.date(byAdding: .day, value: d, to: monday)! }
        XCTAssertEqual(DateUtils.mondayOfWeek(monday), monday)
        XCTAssertEqual(DateUtils.mondayOfWeek(add(-1)), add(-7))
        XCTAssertEqual(DateUtils.mondayOfWeek(add(1)), monday)
        XCTAssertEqual(DateUtils.mondayOfWeek(add(6)), monday)
        XCTAssertEqual(DateUtils.mondayOfWeek(add(7)), add(7))
    }

    func testNearestQuarterOfAnHour() {
        let tenAm = cal.startOfDay(for: Date()).addingTimeInterval(10 * 3600)
        let tenFifteen = tenAm.addingTimeInterval(15 * 60)
        XCTAssertEqual(DateUtils.nearestQuarterOfAnHour(tenAm), tenAm)
        XCTAssertEqual(DateUtils.nearestQuarterOfAnHour(tenAm.addingTimeInterval(5 * 60)), tenAm)
        XCTAssertEqual(DateUtils.nearestQuarterOfAnHour(tenAm.addingTimeInterval(10 * 60)), tenAm)
        XCTAssertEqual(DateUtils.nearestQuarterOfAnHour(tenAm.addingTimeInterval(11 * 60)), tenFifteen)
    }

    func testTimerFormatting() {
        XCTAssertEqual(TimeFormatter.formatTimer(0), "00:00")
        XCTAssertEqual(TimeFormatter.formatTimer(65), "01:05")
        XCTAssertEqual(TimeFormatter.formatTimer(-65), "01:05")
        XCTAssertEqual(TimeFormatter.formatTimer(100 * 60), "100:00")
        XCTAssertEqual(TimeFormatter.dotNetTimeSpan(0), "00:00:00")
        XCTAssertEqual(TimeFormatter.dotNetTimeSpan(65.5), "00:01:05.5000000")
    }
}

final class MeetingStartTimeTests: XCTestCase {
    let en = Locale(identifier: "en_GB")
    let it = Locale(identifier: "it_IT")

    func testParsing() {
        XCTAssertEqual(MeetingStartTime.fromText("19:15", locale: en), MeetingStartTime(dayOfWeek: nil, startMinutes: 19 * 60 + 15))
        XCTAssertEqual(MeetingStartTime.fromText("7.15pm", locale: en)?.startMinutes, 19 * 60 + 15)
        XCTAssertEqual(MeetingStartTime.fromText("Thu 19:15", locale: en), MeetingStartTime(dayOfWeek: 5, startMinutes: 19 * 60 + 15))
        XCTAssertEqual(MeetingStartTime.fromText("Sunday 10", locale: en), MeetingStartTime(dayOfWeek: 1, startMinutes: 10 * 60))
        XCTAssertEqual(MeetingStartTime.fromText("gio 19:15", locale: it), MeetingStartTime(dayOfWeek: 5, startMinutes: 19 * 60 + 15))
        XCTAssertEqual(MeetingStartTime.fromText("domenica 10:00", locale: it), MeetingStartTime(dayOfWeek: 1, startMinutes: 10 * 60))
        XCTAssertNil(MeetingStartTime.fromText("hello", locale: en))
        XCTAssertNil(MeetingStartTime.fromText("19:75", locale: en))
    }

    func testCountdownTrigger() {
        let cal = Calendar.current
        let thursday = cal.date(from: DateComponents(year: 2026, month: 11, day: 12))! // a Thursday
        let times = [MeetingStartTime(dayOfWeek: 5, startMinutes: 19 * 60 + 15)]
        func at(_ h: Int, _ m: Int, _ s: Int = 0) -> Date { thursday.addingTimeInterval(Double(h * 3600 + m * 60 + s)) }

        XCTAssertNil(CountdownTrigger.secondsIntoCountdown(now: at(19, 9), startTimes: times, countdownMins: 5))
        XCTAssertEqual(CountdownTrigger.secondsIntoCountdown(now: at(19, 10), startTimes: times, countdownMins: 5), 0)
        XCTAssertEqual(CountdownTrigger.secondsIntoCountdown(now: at(19, 12), startTimes: times, countdownMins: 5), 120)
        // less than 10 secs to go: don't start
        XCTAssertNil(CountdownTrigger.secondsIntoCountdown(now: at(19, 14, 55), startTimes: times, countdownMins: 5))
        // another day
        let friday = at(19, 12).addingTimeInterval(86_400)
        XCTAssertNil(CountdownTrigger.secondsIntoCountdown(now: friday, startTimes: times, countdownMins: 5))
    }
}

final class ScheduleTests: XCTestCase {
    func testMidweekSchedule() {
        let items = TalkScheduleAuto.midweekScheduleForTesting(Date())
        XCTAssertEqual(items.map { $0.id }, [1000, 1001, 1002, 1003, 2000, 2001, 2002, 2003, 3000, 3001, 4000, 6000])
        let ministry2 = items.first { $0.id == 2001 }!
        // 32:20 + 4m (not a student talk) + 20s
        XCTAssertEqual(ministry2.startOffsetIntoMeeting, 32 * 60 + 20 + 4 * 60 + 20)
        XCTAssertTrue(ministry2.isStudentTalk)
        XCTAssertTrue(ministry2.bellApplicable)
    }

    func testFileBasedSchedule() throws {
        let xml = """
        <meeting><items>
          <item name="Welcome" section="Conference" duration="00:03:00" editable="true" countup="true" />
          <item name="Keynote" section="Conference" duration="01:00:00" editable="true" bell="true" countup="false" persist="true" closing="60" />
          <item name="Concluding" section="Conference" duration="00:03:00" />
        </items></meeting>
        """
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("onlyt-test-\(UUID().uuidString).xml")
        try xml.write(to: url, atomically: true, encoding: .utf8)
        defer { try? FileManager.default.removeItem(at: url) }

        let items = TalkScheduleFileBased.read(url: url, autoBell: true)
        XCTAssertEqual(items.count, 3)
        XCTAssertEqual(items[0].id, 5000)
        XCTAssertEqual(items[0].countUp, true)
        XCTAssertEqual(items[1].originalDuration, 3600)
        XCTAssertEqual(items[1].closingSecs, 60)
        XCTAssertTrue(items[1].bellApplicable)
        XCTAssertTrue(items[1].persistFinalTimerValue)
        XCTAssertNil(items[2].countUp)
        XCTAssertFalse(items[2].editable)
    }

    func testFeedParsing() {
        let json = """
        [{"Date":"2026-11-09T00:00:00","Talks":[{"TalkType":100,"Minutes":3,"IsStudentTalk":false},
          {"TalkType":"Ministry2","Minutes":4,"IsStudentTalk":true},{"TalkType":300,"Minutes":10,"IsStudentTalk":false},
          {"TalkType":301,"Minutes":5,"IsStudentTalk":false}]}]
        """
        let meetings = TimesFeed.parse(Data(json.utf8))
        XCTAssertEqual(meetings?.count, 1)
        let wednesday = Calendar.current.date(from: DateComponents(year: 2026, month: 11, day: 11, hour: 19))!
        let m = TimesFeed.meetingForDay(meetings, day: wednesday)
        XCTAssertNotNil(m)
        XCTAssertEqual(m?.talk(.ministry2)?.minutes, 4)
        XCTAssertEqual(m?.talk(.living2)?.minutes, 5)

        var options = Options()
        options.midWeekOrWeekend = .midWeek
        let items = TalkScheduleAuto.build(options: options, feed: m)
        // only 2 ministry items in the feed
        XCTAssertEqual(items.filter { $0.meetingSectionNameInternal == "Ministry" }.count, 2)
        XCTAssertEqual(items.first { $0.id == TalkTypesAutoMode.livingPart2.rawValue }?.originalDuration, 300)
    }
}

final class WebRouterTests: XCTestCase {
    final class Host: WebHost {
        var options = WebOptions(isWebClockEnabled: true, isApiEnabled: true, isApiThrottled: false, apiCode: "abc")
        var started: Int?
        func webOptions() -> WebOptions { options }
        func clockData() -> [String: Any] { ["mode": "TimeOfDay"] }
        func timersData(talkId: Int?) throws -> [String: Any] {
            if let id = talkId, id != 1000 { throw WebServerErrorCode.timerDoesNotExist }
            return ["timerInfo": [Any]()]
        }
        func startTimer(talkId: Int) throws -> [String: Any] { started = talkId; return ["success": true] }
        func stopTimer(talkId: Int) throws -> [String: Any] { ["success": true] }
        func changeDuration(talkId: Int, deltaSeconds: Int) throws -> [String: Any] { ["newDurationSecs": 60 + deltaSeconds] }
        func ringBell() -> Bool { true }
        func now() -> Date { Date() }
        func systemData() -> [String: Any] { ["machineName": "mac"] }
    }

    func testSegments() {
        XCTAssertEqual(HTTPRequest(method: "GET", path: "/api/v4/timers").segments, ["/", "api/", "v4/", "timers"])
        XCTAssertEqual(HTTPRequest(method: "GET", path: "/api/v4/timers/").segments, ["/", "api/", "v4/", "timers/"])
        XCTAssertEqual(HTTPRequest(method: "GET", path: "/api/").segments, ["/", "api/"])
        XCTAssertEqual(HTTPRequest(method: "GET", path: "/").segments, ["/"])
    }

    func testRouting() throws {
        let host = Host()
        let router = WebRouter(host: host)

        XCTAssertEqual(router.handle(HTTPRequest(method: "GET", path: "/api/")).status, 200)
        XCTAssertEqual(router.handle(HTTPRequest(method: "GET", path: "/api/v4/timers")).status, 200)
        XCTAssertEqual(router.handle(HTTPRequest(method: "GET", path: "/api/v4/timers/999")).status, 404)
        XCTAssertEqual(router.handle(HTTPRequest(method: "GET", path: "/api/v9/timers")).status, 400)
        // wrong verb (with a valid code) and missing code
        XCTAssertEqual(router.handle(HTTPRequest(method: "PUT", path: "/api/v4/timers/1000", headers: ["apicode": "abc"])).status, 405)
        XCTAssertEqual(router.handle(HTTPRequest(method: "PUT", path: "/api/v4/timers/1000")).status, 401)

        // POST needs the api code
        XCTAssertEqual(router.handle(HTTPRequest(method: "POST", path: "/api/v4/timers/1000")).status, 401)
        let ok = router.handle(HTTPRequest(method: "POST", path: "/api/v4/timers/1000", headers: ["apicode": "abc"]))
        XCTAssertEqual(ok.status, 200)
        XCTAssertEqual(host.started, 1000)

        let body = Data(#"{"deltaSeconds": 30}"#.utf8)
        let dur = router.handle(HTTPRequest(method: "POST", path: "/api/v4/timers/1000/duration", query: ["ApiCode": "abc"], body: body))
        XCTAssertEqual(dur.status, 200)
        let obj = try JSONSerialization.jsonObject(with: dur.body) as? [String: Any]
        XCTAssertEqual(obj?["newDurationSecs"] as? Int, 90)

        XCTAssertEqual(router.handle(HTTPRequest(method: "GET", path: "/api/v4/system")).status, 200)
        XCTAssertEqual(router.handle(HTTPRequest(method: "GET", path: "/nothing")).status, 404)
    }

    func testThrottling() {
        let host = Host()
        host.options.isApiThrottled = true
        let router = WebRouter(host: host)
        let req = HTTPRequest(method: "GET", path: "/api/v4/timers", remoteEndpoint: "1.2.3.4:5000")
        XCTAssertEqual(router.handle(req).status, 200)
        XCTAssertEqual(router.handle(req).status, 503)
    }

    func testHTTPParser() throws {
        let raw = "POST /api/v4/timers/1000/duration?ApiCode=a%20b HTTP/1.1\r\nHost: x\r\nContent-Length: 5\r\n\r\nhelloEXTRA"
        let parsed = try HTTPParser.parse(Data(raw.utf8), remoteEndpoint: "1.1.1.1:1")
        XCTAssertNotNil(parsed)
        XCTAssertEqual(parsed?.0.method, "POST")
        XCTAssertEqual(parsed?.0.path, "/api/v4/timers/1000/duration")
        XCTAssertEqual(parsed?.0.queryValue("apicode"), "a b")
        XCTAssertEqual(String(data: parsed!.0.body, encoding: .utf8), "hello")
        XCTAssertEqual(parsed?.1, raw.utf8.count - "EXTRA".utf8.count)

        XCTAssertNil(try HTTPParser.parse(Data("GET / HTTP/1.1\r\nHost: x\r\n".utf8), remoteEndpoint: ""))
    }
}
