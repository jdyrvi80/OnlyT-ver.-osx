import XCTest
@testable import OnlyTCore

/// Port of the original OnlyT TestAdaptiveTimer.
final class AdaptiveTimerTests: XCTestCase {
    private var items: [TalkScheduleItem] = []
    private var dateTime: MockDateTimeProvider!
    private var mtgStart: Date!
    private var service: AdaptiveTimerService!

    override func setUp() {
        super.setUp()
        let cal = Calendar.current
        let theDate = cal.date(from: DateComponents(year: 2020, month: 1, day: 6))!
        mtgStart = theDate.addingTimeInterval(19 * 3600) // 7pm
        dateTime = MockDateTimeProvider(mtgStart)
        items = TalkScheduleAuto.midweekScheduleForTesting(theDate, isJanuary2020OrLater: true)

        var options = Options()
        options.generateTimingReports = false
        options.midWeekAdaptiveMode = .twoWay
        options.midWeekOrWeekend = .midWeek
        options.operatingMode = .automatic

        let capturedItems = items
        service = AdaptiveTimerService(optionsProvider: { options }, itemsProvider: { capturedItems }, dateTime: dateTime)
        service.setMeetingStartTimeForTesting(dateTime.now())

        // complete most of the timers, each item exactly on time
        for item in items {
            if item.id == TalkTypesAutoMode.livingPart1.rawValue {
                break
            }
            item.completedTimeSecs = Int(item.actualDuration)
        }
    }

    private func talk(_ t: TalkTypesAutoMode) -> TalkScheduleItem {
        items.first { $0.id == t.rawValue }!
    }

    private func at(_ offset: TimeInterval) {
        dateTime.set(mtgStart.addingTimeInterval(offset))
    }

    private func assertAboutEqual(_ value: TimeInterval?, _ m: Int, _ s: Int, file: StaticString = #filePath, line: UInt = #line) {
        guard let value = value else {
            XCTFail("nil duration", file: file, line: line)
            return
        }
        XCTAssertLessThan(abs(value - Double(m * 60 + s)), 2, "got \(value)", file: file, line: line)
    }

    func testPerfectSchedule() {
        let living1 = talk(.livingPart1)
        at(living1.startOffsetIntoMeeting)
        XCTAssertNil(service.calculateAdaptedDuration(living1.id))

        let study = talk(.congBibleStudy)
        at(study.startOffsetIntoMeeting)
        XCTAssertNil(service.calculateAdaptedDuration(study.id))

        let concluding = talk(.concludingComments)
        at(concluding.startOffsetIntoMeeting)
        XCTAssertNil(service.calculateAdaptedDuration(concluding.id))
    }

    func testLateSchedule() {
        let living1 = talk(.livingPart1)
        at(living1.startOffsetIntoMeeting + 600)
        let a1 = service.calculateAdaptedDuration(living1.id)
        assertAboutEqual(a1, 11, 52)
        living1.adaptedDuration = a1

        let study = talk(.congBibleStudy)
        at(study.startOffsetIntoMeeting + 300)
        let a2 = service.calculateAdaptedDuration(study.id)
        assertAboutEqual(a2, 25, 27)
        study.adaptedDuration = a2

        let concluding = talk(.concludingComments)
        at(concluding.startOffsetIntoMeeting + 60)
        let a3 = service.calculateAdaptedDuration(concluding.id)
        assertAboutEqual(a3, 2, 0)
    }

    func testLateSchedule2() {
        let living1 = talk(.livingPart1)
        let concluding = talk(.concludingComments)
        let study = talk(.congBibleStudy)

        at(living1.startOffsetIntoMeeting + 600)
        let a1 = service.calculateAdaptedDuration(living1.id)
        assertAboutEqual(a1, 11, 52)
        living1.adaptedDuration = a1

        at(study.startOffsetIntoMeeting + 300)
        study.modifiedDuration = study.originalDuration - 300
        concluding.modifiedDuration = concluding.originalDuration + 300

        let a2 = service.calculateAdaptedDuration(study.id)
        assertAboutEqual(a2, 21, 12)
        study.adaptedDuration = a2

        at(study.startOffsetIntoMeeting + 300 + (study.adaptedDuration ?? 0))
        let a3 = service.calculateAdaptedDuration(concluding.id)
        assertAboutEqual(a3, 6, 47)
    }

    func testEarlySchedule() {
        let living1 = talk(.livingPart1)
        at(living1.startOffsetIntoMeeting - 600)
        let a1 = service.calculateAdaptedDuration(living1.id)
        assertAboutEqual(a1, 18, 7)
        living1.adaptedDuration = a1

        let study = talk(.congBibleStudy)
        at(study.startOffsetIntoMeeting - 300)
        let a2 = service.calculateAdaptedDuration(study.id)
        assertAboutEqual(a2, 34, 32)
        study.adaptedDuration = a2

        let concluding = talk(.concludingComments)
        at(concluding.startOffsetIntoMeeting - 60)
        let a3 = service.calculateAdaptedDuration(concluding.id)
        assertAboutEqual(a3, 4, 0)
    }

    func testManuallyAdjustedSchedule1() {
        let living1 = talk(.livingPart1)
        let study = talk(.congBibleStudy)
        let concluding = talk(.concludingComments)

        concluding.modifiedDuration = concluding.originalDuration + 180
        study.modifiedDuration = study.originalDuration - 180

        at(living1.startOffsetIntoMeeting)
        XCTAssertNil(service.calculateAdaptedDuration(living1.id))

        at(study.startOffsetIntoMeeting)
        XCTAssertNil(service.calculateAdaptedDuration(study.id))

        at(concluding.startOffsetIntoMeeting - 180)
        XCTAssertNil(service.calculateAdaptedDuration(concluding.id))
    }

    func testManuallyAdjustedSchedule2() {
        let living1 = talk(.livingPart1)
        let study = talk(.congBibleStudy)
        let concluding = talk(.concludingComments)

        // (same expressions as the original test)
        study.modifiedDuration = study.originalDuration + 300
        living1.modifiedDuration = study.originalDuration - 180
        concluding.modifiedDuration = study.originalDuration - 120

        at(living1.startOffsetIntoMeeting)
        XCTAssertNil(service.calculateAdaptedDuration(living1.id))

        at(study.startOffsetIntoMeeting - 180)
        XCTAssertNil(service.calculateAdaptedDuration(study.id))

        at(concluding.startOffsetIntoMeeting + 300)
        XCTAssertNil(service.calculateAdaptedDuration(concluding.id))
    }

    func testManuallyAdjustedSchedule3() {
        let living1 = talk(.livingPart1)
        let study = talk(.congBibleStudy)
        let concluding = talk(.concludingComments)

        concluding.modifiedDuration = concluding.originalDuration + 300

        at(living1.startOffsetIntoMeeting)
        let a1 = service.calculateAdaptedDuration(living1.id)
        assertAboutEqual(a1, 13, 35)
        living1.adaptedDuration = a1

        at(living1.startOffsetIntoMeeting + (a1 ?? 0))
        let a2 = service.calculateAdaptedDuration(study.id)
        assertAboutEqual(a2, 27, 25)
        study.adaptedDuration = a2

        at(study.startOffsetIntoMeeting + (a2 ?? 0))
        let a3 = service.calculateAdaptedDuration(concluding.id)
        assertAboutEqual(a3, 5, 34)
    }

    func testManuallyAdjustedSchedule4() {
        let living1 = talk(.livingPart1)
        let study = talk(.congBibleStudy)
        let concluding = talk(.concludingComments)

        study.modifiedDuration = study.originalDuration - 300

        at(living1.startOffsetIntoMeeting)
        let a1 = service.calculateAdaptedDuration(living1.id)
        assertAboutEqual(a1, 16, 44)
        living1.adaptedDuration = a1

        at(living1.startOffsetIntoMeeting + (a1 ?? 0))
        let a2 = service.calculateAdaptedDuration(study.id)
        assertAboutEqual(a2, 28, 12)
        study.adaptedDuration = a2

        at(study.startOffsetIntoMeeting + (a2 ?? 0))
        let a3 = service.calculateAdaptedDuration(concluding.id)
        assertAboutEqual(a3, 4, 47)
    }
}
