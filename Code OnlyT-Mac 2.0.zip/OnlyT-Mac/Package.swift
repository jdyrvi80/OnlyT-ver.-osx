// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "OnlyT",
    platforms: [
        .macOS(.v13),
    ],
    products: [
        .executable(name: "OnlyT", targets: ["OnlyT"]),
    ],
    targets: [
        // Platform-independent logic (schedules, adaptive timer, web API, ...)
        .target(
            name: "OnlyTCore",
            path: "Sources/OnlyTCore"
        ),
        // The macOS app (AppKit + SwiftUI)
        .executableTarget(
            name: "OnlyT",
            dependencies: ["OnlyTCore"],
            path: "Sources/OnlyT"
        ),
        .testTarget(
            name: "OnlyTCoreTests",
            dependencies: ["OnlyTCore"],
            path: "Tests/OnlyTCoreTests"
        ),
    ]
)
